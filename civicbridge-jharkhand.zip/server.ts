/**
 * CivicBridge Jharkhand - Full-Stack Express Server & Vite Host
 * 
 * Problem Statement: SIH26043 - Smart India Hackathon 2026
 * Department of Higher & Technical Education, Government of Jharkhand
 */

import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';
import { router as apiRouter } from './server/routes.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  // JSON Body Parser with reasonable payload limits
  app.use(express.json({ limit: '25mb' }));
  app.use(express.urlencoded({ extended: true, limit: '25mb' }));

  // Request logger for API auditing
  app.use((req, res, next) => {
    if (req.path.startsWith('/api')) {
      console.log(`[API] ${req.method} ${req.path}`);
    }
    next();
  });

  // Health check endpoint
  app.get('/api/health', (req, res) => {
    res.json({
      status: 'healthy',
      platform: 'CivicBridge Jharkhand (SIH 2026 - SIH26043)',
      state: 'Jharkhand',
      timestamp: new Date().toISOString(),
    });
  });

  // Mount primary API routes
  app.use('/api', apiRouter);

  // Vite middleware for development vs static build in production
  if (process.env.NODE_ENV !== 'production') {
    console.log('Mounting Vite dev server middleware on port 3000...');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    console.log('Serving production static assets from dist/ folder...');
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`=======================================================`);
    console.log(`🚀 CivicBridge Jharkhand server active on port ${PORT}`);
    console.log(`   Host: http://0.0.0.0:${PORT}`);
    console.log(`   SIH 2026 Problem Statement ID: SIH26043`);
    console.log(`   Government of Jharkhand - Higher & Technical Education`);
    console.log(`=======================================================`);
  });
}

startServer().catch((err) => {
  console.error('Fatal error starting CivicBridge server:', err);
  process.exit(1);
});
