/**
 * CivicBridge Jharkhand - Persistent Database & Relational Seed Engine
 * 
 * Features:
 * - Atomic JSON file persistence to data/database.json
 * - 20+ Realistic synthetic Jharkhand challenges across all 24 districts
 * - 10+ Universities / HEIs across Jharkhand
 * - 10+ Industry Partners, Startups & CSR Foundations
 * - Active Multidisciplinary Projects with Milestones, Team & Impact Metrics
 * - 14 User Roles with instant switchable personas
 */

import fs from 'fs';
import path from 'path';
import {
  User,
  Challenge,
  University,
  IndustryPartner,
  Project,
  DiscussionMessage,
  AppNotification,
  AuditLog,
  FacultyMentor,
  StudentMember,
  IndustryInterest,
  SolutionProposal,
  ProjectMilestone,
  ProjectImpact,
  ChallengeAIAnalysis,
} from './types.js';
import { aiService } from './aiService.js';

export interface DatabaseSchema {
  users: User[];
  challenges: Challenge[];
  universities: University[];
  faculty: FacultyMentor[];
  students: StudentMember[];
  industryPartners: IndustryPartner[];
  industryInterests: IndustryInterest[];
  projects: Project[];
  proposals: SolutionProposal[];
  milestones: ProjectMilestone[];
  impactRecords: ProjectImpact[];
  messages: DiscussionMessage[];
  notifications: AppNotification[];
  auditLogs: AuditLog[];
}

const DATA_DIR = path.join(process.cwd(), 'data');
const DB_FILE = path.join(DATA_DIR, 'database.json');

// Ensure data directory exists
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

export class DatabaseEngine {
  private data: DatabaseSchema;
  private initialized = false;

  constructor() {
    this.data = this.loadFromDisk();
  }

  private loadFromDisk(): DatabaseSchema {
    try {
      if (fs.existsSync(DB_FILE)) {
        const raw = fs.readFileSync(DB_FILE, 'utf-8');
        const parsed = JSON.parse(raw);
        if (parsed && Array.isArray(parsed.challenges) && parsed.challenges.length > 0) {
          this.initialized = true;
          return parsed;
        }
      }
    } catch (err) {
      console.warn('Could not read existing database.json, generating pristine seed...', err);
    }
    return this.generateSeedData();
  }

  public saveToDisk(): void {
    try {
      fs.writeFileSync(DB_FILE, JSON.stringify(this.data, null, 2), 'utf-8');
    } catch (err) {
      console.error('Failed to persist database to disk:', err);
    }
  }

  public resetToSeed(): DatabaseSchema {
    this.data = this.generateSeedData();
    this.saveToDisk();
    return this.data;
  }

  public getData(): DatabaseSchema {
    return this.data;
  }

  // --- Entity Accessors ---
  public getUsers(): User[] {
    return this.data.users;
  }

  public getUserById(id: string): User | undefined {
    return this.data.users.find((u) => u.id === id);
  }

  public getUserByEmail(email: string): User | undefined {
    return this.data.users.find((u) => u.email.toLowerCase() === email.toLowerCase());
  }

  public addUser(user: User): User {
    this.data.users.push(user);
    this.saveToDisk();
    return user;
  }

  public getChallenges(): Challenge[] {
    return this.data.challenges;
  }

  public getChallengeById(id: string): Challenge | undefined {
    return this.data.challenges.find((c) => c.id === id);
  }

  public addChallenge(challenge: Challenge): Challenge {
    this.data.challenges.unshift(challenge);
    this.saveToDisk();
    return challenge;
  }

  public updateChallenge(id: string, updates: Partial<Challenge>): Challenge | undefined {
    const idx = this.data.challenges.findIndex((c) => c.id === id);
    if (idx === -1) return undefined;
    this.data.challenges[idx] = { ...this.data.challenges[idx], ...updates };
    this.saveToDisk();
    return this.data.challenges[idx];
  }

  public getUniversities(): University[] {
    return this.data.universities;
  }

  public getUniversityById(id: string): University | undefined {
    return this.data.universities.find((u) => u.id === id);
  }

  public getFaculty(): FacultyMentor[] {
    return this.data.faculty;
  }

  public getStudents(): StudentMember[] {
    return this.data.students;
  }

  public getIndustryPartners(): IndustryPartner[] {
    return this.data.industryPartners;
  }

  public getIndustryPartnerById(id: string): IndustryPartner | undefined {
    return this.data.industryPartners.find((ip) => ip.id === id);
  }

  public addIndustryInterest(interest: IndustryInterest): IndustryInterest {
    this.data.industryInterests.push(interest);
    this.saveToDisk();
    return interest;
  }

  public getProjects(): Project[] {
    return this.data.projects;
  }

  public getProjectById(id: string): Project | undefined {
    return this.data.projects.find((p) => p.id === id);
  }

  public addProject(project: Project): Project {
    this.data.projects.unshift(project);
    this.saveToDisk();
    return project;
  }

  public updateProject(id: string, updates: Partial<Project>): Project | undefined {
    const idx = this.data.projects.findIndex((p) => p.id === id);
    if (idx === -1) return undefined;
    this.data.projects[idx] = { ...this.data.projects[idx], ...updates };
    this.saveToDisk();
    return this.data.projects[idx];
  }

  public getMessages(channelType?: string, targetEntityId?: string): DiscussionMessage[] {
    let filtered = this.data.messages;
    if (channelType) {
      filtered = filtered.filter((m) => m.channelType === channelType);
    }
    if (targetEntityId) {
      filtered = filtered.filter((m) => m.targetEntityId === targetEntityId);
    }
    return filtered;
  }

  public addMessage(msg: DiscussionMessage): DiscussionMessage {
    this.data.messages.push(msg);
    this.saveToDisk();
    return msg;
  }

  public getNotifications(userId?: string, role?: string): AppNotification[] {
    return this.data.notifications
      .filter((n) => (!n.userId || n.userId === userId) || (!n.targetRole || n.targetRole === role))
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  public addNotification(n: AppNotification): AppNotification {
    this.data.notifications.unshift(n);
    this.saveToDisk();
    return n;
  }

  public markNotificationRead(id: string): void {
    const notif = this.data.notifications.find((n) => n.id === id);
    if (notif) {
      notif.isRead = true;
      this.saveToDisk();
    }
  }

  public markAllNotificationsRead(userId?: string, role?: string): void {
    for (const n of this.data.notifications) {
      if ((!n.userId || n.userId === userId) || (!n.targetRole || n.targetRole === role)) {
        n.isRead = true;
      }
    }
    this.saveToDisk();
  }

  public getAuditLogs(): AuditLog[] {
    return this.data.auditLogs.sort(
      (a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
    );
  }

  public addAuditLog(entry: Omit<AuditLog, 'id' | 'timestamp'>): AuditLog {
    const log: AuditLog = {
      id: `AUD-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      ...entry,
      timestamp: new Date().toISOString(),
    };
    this.data.auditLogs.unshift(log);
    this.saveToDisk();
    return log;
  }

  // --- SEED GENERATION ---
  private generateSeedData(): DatabaseSchema {
    // 14 Role Personas
    const users: User[] = [
      {
        id: 'usr-citizen-01',
        name: 'Sunita Munda',
        email: 'sunita.munda@jharkhand-citizen.in',
        role: 'Citizen',
        district: 'Ranchi',
        organization: 'Angara Village Development Committee',
        phone: '+91 94311 02841',
        bio: 'Rural community worker and women SHG leader in Angara block, Ranchi.',
        createdAt: '2026-01-10T10:00:00Z',
      },
      {
        id: 'usr-gov-01',
        name: 'Dr. Rajeshwar Sharma, IAS',
        email: 'rajeshwar.sharma@jharkhand.gov.in',
        role: 'Government Department',
        district: 'Ranchi',
        organization: 'Department of Higher & Technical Education, GoJ',
        phone: '+91 651 2400122',
        bio: 'Joint Secretary, Technical Education & Innovation Mission, Government of Jharkhand.',
        createdAt: '2026-01-05T09:00:00Z',
      },
      {
        id: 'usr-uni-admin-01',
        name: 'Prof. Alok Kumar Roy',
        email: 'dean.rnd@bitmesra.ac.in',
        role: 'University Admin',
        district: 'Ranchi',
        organization: 'Birla Institute of Technology (BIT) Mesra',
        phone: '+91 651 2275444',
        bio: 'Dean of Research, Innovation and Academic Collaborations, BIT Mesra.',
        createdAt: '2026-01-06T10:30:00Z',
      },
      {
        id: 'usr-faculty-01',
        name: 'Dr. Priyadarshini Sengupta',
        email: 'p.sengupta@iitism.ac.in',
        role: 'Faculty Mentor',
        district: 'Dhanbad',
        organization: 'IIT (ISM) Dhanbad - Dept of Environmental Engineering',
        phone: '+91 326 2235001',
        bio: 'Associate Professor specializing in Groundwater Contamination & Membrane Technologies.',
        createdAt: '2026-01-08T11:00:00Z',
      },
      {
        id: 'usr-student-01',
        name: 'Abhishek Murmu',
        email: 'abhishek.murmu@student.nitjsr.ac.in',
        role: 'Student',
        district: 'East Singhbhum',
        organization: 'NIT Jamshedpur - Final Year B.Tech IoT & Embedded',
        phone: '+91 87890 12345',
        bio: 'Student lead, Rural IoT & Embedded Telemetry Lab at NIT Jamshedpur.',
        createdAt: '2026-01-12T14:20:00Z',
      },
      {
        id: 'usr-ind-01',
        name: 'Vikramaditya Singhania',
        email: 'vikram.singhania@tatasteel.com',
        role: 'Industry Partner',
        district: 'East Singhbhum',
        organization: 'Tata Steel Rural Development Society (TSRDS)',
        phone: '+91 657 6645000',
        bio: 'Head of Civic Innovation & Sustainable Engineering Partnerships, Tata Steel.',
        createdAt: '2026-01-07T12:00:00Z',
      },
      {
        id: 'usr-startup-01',
        name: 'Neha Soren',
        email: 'neha@jaltech-solutions.in',
        role: 'Startup/MSME',
        district: 'Ranchi',
        organization: 'JalTech Solutions Pvt Ltd (Ranchi Incubated)',
        phone: '+91 70041 98765',
        bio: 'Co-founder of smart rural water telemetry startup recognized by Startup India.',
        createdAt: '2026-01-15T15:00:00Z',
      },
      {
        id: 'usr-csr-01',
        name: 'Anandita Banerjee',
        email: 'anandita.banerjee@sailcsr.co.in',
        role: 'CSR Organization',
        district: 'Bokaro',
        organization: 'SAIL Bokaro Steel Plant CSR Division',
        phone: '+91 6542 240333',
        bio: 'General Manager, Corporate Social Responsibility & Community Health, SAIL.',
        createdAt: '2026-01-16T11:00:00Z',
      },
      {
        id: 'usr-panchayat-01',
        name: 'Birsa Oraon',
        email: 'mukhiya.angara@jharkhandpanchayat.gov.in',
        role: 'Panchayati Raj Institution',
        district: 'Ranchi',
        organization: 'Gram Panchayat Angara, Block Angara',
        phone: '+91 94301 55667',
        bio: 'Mukhiya (Elected Village Council Head), Angara Gram Panchayat.',
        createdAt: '2026-01-18T09:30:00Z',
      },
      {
        id: 'usr-ulb-01',
        name: 'Sanjeev Kumar Verma',
        email: 'commissioner@rmc.jharkhand.gov.in',
        role: 'Urban Local Body',
        district: 'Ranchi',
        organization: 'Ranchi Municipal Corporation (RMC)',
        phone: '+91 651 2211281',
        bio: 'Executive Engineer, Solid Waste & Urban Water Systems, RMC.',
        createdAt: '2026-01-14T10:00:00Z',
      },
      {
        id: 'usr-community-01',
        name: 'Mary Margaret Tirkey',
        email: 'mary@jharkhand-tribalwelfare.org',
        role: 'Community Organization',
        district: 'Khunti',
        organization: 'Chotanagpur Adivasi Sewa Samiti',
        phone: '+91 94701 22334',
        bio: 'General Secretary coordinating rural livelihood & health self-help groups.',
        createdAt: '2026-01-11T13:00:00Z',
      },
      {
        id: 'usr-reslab-01',
        name: 'Dr. Debabrata Chattopadhyay',
        email: 'd.chatto@csir-cimfr.res.in',
        role: 'Research Laboratory',
        district: 'Dhanbad',
        organization: 'CSIR - Central Institute of Mining and Fuel Research (CIMFR)',
        phone: '+91 326 2388000',
        bio: 'Chief Scientist, Environmental Biotechnology and Mine Water Purification.',
        createdAt: '2026-01-09T16:00:00Z',
      },
      {
        id: 'usr-hub-01',
        name: 'Rohit Kujur',
        email: 'ceo@jharkhand-innovationhub.in',
        role: 'Innovation Hub',
        district: 'Ranchi',
        organization: 'Atal Community Innovation Center (ACIC) Jharkhand',
        phone: '+91 651 2911000',
        bio: 'CEO at ACIC Jharkhand facilitating grassroots technology transfers.',
        createdAt: '2026-01-07T14:00:00Z',
      },
      {
        id: 'usr-admin-01',
        name: 'System Administrator (GoJ State Portal)',
        email: 'admin.civicbridge@jharkhand.gov.in',
        role: 'Platform Administrator',
        district: 'Ranchi',
        organization: 'Jharkhand State Information Technology Agency (JAP-IT)',
        phone: '+91 651 2490001',
        bio: 'Master Administrator & Security Auditor for CivicBridge Jharkhand.',
        createdAt: '2026-01-01T00:00:00Z',
      },
    ];

    // 10 Universities & Higher Educational Institutions in Jharkhand
    const universities: University[] = [
      {
        id: 'uni-bit-mesra',
        name: 'Birla Institute of Technology (BIT), Mesra',
        shortName: 'BIT Mesra',
        district: 'Ranchi',
        address: 'Mesra, Ranchi, Jharkhand 835215',
        type: 'Private/Deemed',
        departments: [
          'Civil & Environmental Engineering',
          'Computer Science & Engineering',
          'Electrical & Electronics Engineering',
          'Mechanical Engineering',
          'Remote Sensing & GIS',
          'Bioengineering'
        ],
        facultyExpertise: ['IoT Sensor Networks', 'Hydrology & Water Purification', 'Smart Grid Systems', 'GIS Spatial Modeling'],
        researchAreas: ['Smart Village Technologies', 'Water Quality Telemetry', 'Drone Remote Sensing', 'Renewable Microgrids'],
        innovationCenters: ['BIT TBI Incubation Center', 'Center for Rural Technology', 'Atal Incubation Centre (AIC)'],
        incubationFacilities: ['Rapid Prototyping FabLab', 'Hardware Assembly Line', 'IoT Cloud Gateway'],
        laboratories: ['Water Analysis & Environmental Lab', 'Embedded Systems & Robotics Lab', 'Soil Mechanics Lab'],
        availableEquipment: ['AAS Spectrophotometer', '3D Industrial Printers', 'LoRaWAN Field Gateways', 'Drone Fleet with LiDAR'],
        studentCount: 5200,
        facultyCount: 310,
        activeProjectsCount: 14,
        pastCompletedProjects: 38,
        contactEmail: 'rnd@bitmesra.ac.in',
        contactPhone: '+91 651 2275444',
        website: 'https://www.bitmesra.ac.in',
      },
      {
        id: 'uni-iit-ism-dhanbad',
        name: 'Indian Institute of Technology (ISM) Dhanbad',
        shortName: 'IIT (ISM) Dhanbad',
        district: 'Dhanbad',
        address: 'Sardar Patel Nagar, Dhanbad, Jharkhand 826004',
        type: 'NIT/IIT',
        departments: [
          'Environmental Science & Engineering',
          'Mining Engineering',
          'Civil Engineering',
          'Computer Science & Engineering',
          'Electronics Engineering',
          'Chemical Engineering'
        ],
        facultyExpertise: ['Mine Water Treatment', 'Heavy Metal Bio-Remediation', 'Satellite Subsidence Tracking', 'Deep Learning for Civic Sensing'],
        researchAreas: ['Industrial Effluent Clean-up', 'Groundwater Recharging Models', 'Disaster Early Warning', 'Carbon Capture'],
        innovationCenters: ['TexMiN (Technology Innovation Hub)', 'Center for Water Resource Management', 'IIT Dhanbad Incubation Cell'],
        incubationFacilities: ['TexMiN Mining & IoT Accelerator', 'Central Research Facility', 'Makerspace Studio'],
        laboratories: ['Advanced Hydrogeology Lab', 'Sensor & Microelectronics Lab', 'Chemical Instrumental Analysis Lab'],
        availableEquipment: ['ICP-MS Heavy Metal Analyzer', 'Gas Chromatography-MS', 'Automated Core Drill Soil Analyzers'],
        studentCount: 7800,
        facultyCount: 390,
        activeProjectsCount: 22,
        pastCompletedProjects: 65,
        contactEmail: 'texmin@iitism.ac.in',
        contactPhone: '+91 326 2235001',
        website: 'https://www.iitism.ac.in',
      },
      {
        id: 'uni-nit-jamshedpur',
        name: 'National Institute of Technology (NIT) Jamshedpur',
        shortName: 'NIT Jamshedpur',
        district: 'East Singhbhum',
        address: 'Adityapur, Jamshedpur, Jharkhand 831014',
        type: 'NIT/IIT',
        departments: [
          'Civil Engineering',
          'Computer Science & Engineering',
          'Electrical Engineering',
          'Mechanical Engineering',
          'Metallurgical & Materials Engineering'
        ],
        facultyExpertise: ['Bridge & Road Structural Integrity', 'Smart Energy Microgrids', 'Industrial Slag Material Reuse', 'Autonomous Drones'],
        researchAreas: ['Rural Infrastructure Resiliency', 'Solar Water Pumping', 'Low-Cost Composite Building Materials'],
        innovationCenters: ['Institute Innovation Council (IIC)', 'Advanced Materials Testing Center', 'Rural Automation Hub'],
        incubationFacilities: ['NITJ Maker Space', 'Electronics Hardware Testing Bay'],
        laboratories: ['Concrete & Heavy Structures Lab', 'Smart Power Systems Lab', 'Robotics & Automation Lab'],
        availableEquipment: ['Universal Testing Machine 1000kN', 'PCB CNC Milling Station', 'Solar Simulator Rack'],
        studentCount: 4600,
        facultyCount: 240,
        activeProjectsCount: 16,
        pastCompletedProjects: 42,
        contactEmail: 'director@nitjsr.ac.in',
        contactPhone: '+91 657 2373407',
        website: 'https://www.nitjsr.ac.in',
      },
      {
        id: 'uni-birsa-agri',
        name: 'Birsa Agricultural University (BAU)',
        shortName: 'BAU Kanke',
        district: 'Ranchi',
        address: 'Kanke, Ranchi, Jharkhand 834006',
        type: 'State University',
        departments: [
          'Agronomy',
          'Agricultural Engineering',
          'Soil Science & Agricultural Chemistry',
          'Plant Pathology',
          'Forestry',
          'Biotechnology'
        ],
        facultyExpertise: ['Drought-Resistant Millets', 'Indigenous Soil Health Mapping', 'Tribal Agro-Forestry & Lac Cultivation', 'Solar Cold Storage'],
        researchAreas: ['Rainfed Farming Resilience', 'Pest Bio-Control', 'Post-Harvest Spoilage Reduction'],
        innovationCenters: ['Agri-Business Incubator (ABI)', 'Center for Tribal Agro-Biodiversity', 'Krishi Vigyan Kendra Network'],
        incubationFacilities: ['Agro-Processing Demonstration Plant', 'Tissue Culture Lab'],
        laboratories: ['Soil Testing & Nutrient Analysis Lab', 'Seed Technology Testing Lab', 'Biopesticide Formulation Lab'],
        availableEquipment: ['Atomic Absorption Spectrophotometer', 'Automated Kjeldahl Nitrogen Unit', 'Thermal Seed Germinators'],
        studentCount: 2200,
        facultyCount: 180,
        activeProjectsCount: 18,
        pastCompletedProjects: 51,
        contactEmail: 'vc@bausjharkhand.org',
        contactPhone: '+91 651 2455000',
        website: 'https://www.bauranchi.org',
      },
      {
        id: 'uni-ranchi-university',
        name: 'Ranchi University',
        shortName: 'Ranchi University',
        district: 'Ranchi',
        address: 'Shaheed Chowk, Ranchi, Jharkhand 834001',
        type: 'State University',
        departments: [
          'Botany & Biotechnology',
          'Zoology',
          'Chemistry',
          'Physics',
          'Computer Applications',
          'Tribal & Regional Languages'
        ],
        facultyExpertise: ['Medicinal Plant Extraction', 'Water Microbiology', 'Santhali & Mundari Language NLP', 'Community Health Data'],
        researchAreas: ['Indigenous Knowledge Systems', 'Fluoride Bio-Remediation', 'Vernacular E-Learning'],
        innovationCenters: ['University Research Center', 'Tribal Culture & Digital Archives Center'],
        incubationFacilities: ['Community Innovation Hub', 'Language Technology Cell'],
        laboratories: ['Microbiology & Water Testing Lab', 'Organic Synthesis Lab'],
        availableEquipment: ['High-Performance Liquid Chromatography (HPLC)', 'UV-Vis Spectrophotometer'],
        studentCount: 28000,
        facultyCount: 650,
        activeProjectsCount: 11,
        pastCompletedProjects: 29,
        contactEmail: 'registrar@ranchiuniversity.ac.in',
        contactPhone: '+91 651 2208553',
        website: 'https://www.ranchiuniversity.ac.in',
      },
      {
        id: 'uni-cuj',
        name: 'Central University of Jharkhand (CUJ)',
        shortName: 'CUJ Brambe',
        district: 'Ranchi',
        address: 'Cheri-Manatu Campus, Ranchi, Jharkhand 835222',
        type: 'Central University',
        departments: [
          'Energy Engineering',
          'Water Engineering and Management',
          'Environmental Sciences',
          'Computer Science and Technology',
          'Mass Communication'
        ],
        facultyExpertise: ['Solar Photovoltaic Microgrids', 'Rainwater Harvesting Design', 'Biomass Gasifiers', 'Environmental Law & Policy'],
        researchAreas: ['Rural Electrification in Santhal Parganas', 'Fluoride Contamination Mitigation', 'Sustainable Tribal Habitats'],
        innovationCenters: ['Center for Energy Security', 'Eco-Design Innovation Center'],
        incubationFacilities: ['Renewable Energy Demonstration Park', 'Smart Electronics Prototyping Room'],
        laboratories: ['Solar & Bioenergy Systems Lab', 'Water Treatment Experimental Station'],
        availableEquipment: ['Solar IV Curve Tracer', 'Turbidity & Fluoride Colorimeters', 'Weather Monitoring Station'],
        studentCount: 3400,
        facultyCount: 190,
        activeProjectsCount: 13,
        pastCompletedProjects: 24,
        contactEmail: 'dean.acad@cuj.ac.in',
        contactPhone: '+91 651 2911222',
        website: 'https://www.cuj.ac.in',
      },
      {
        id: 'uni-iiit-ranchi',
        name: 'Indian Institute of Information Technology (IIIT) Ranchi',
        shortName: 'IIIT Ranchi',
        district: 'Ranchi',
        address: 'Namkum, Ranchi, Jharkhand 834010',
        type: 'NIT/IIT',
        departments: [
          'Computer Science & Engineering',
          'Data Science & Artificial Intelligence',
          'Electronics & Communication Engineering'
        ],
        facultyExpertise: ['Computer Vision for Pest & Crop Health', 'Edge AI on Low-Power MCUs', 'Vernacular Speech Recognition', 'Distributed Ledger for PDS'],
        researchAreas: ['Edge Computing in Zero-Connectivity Zones', 'AI for Civic Grievance Triaging', 'Satellite Image Processing for Deforestation'],
        innovationCenters: ['IIITR AI & IoT Innovation Cell', 'Data-Driven Governance Lab'],
        incubationFacilities: ['Cyber-Physical Systems Incubator', 'Cloud Computing Testbed'],
        laboratories: ['High-Performance GPU AI Cluster', 'Embedded Hardware Workbench'],
        availableEquipment: ['NVIDIA A100 GPU Cluster', 'Edge TPU Developer Kits', 'LoRa Node Testbeds'],
        studentCount: 1200,
        facultyCount: 75,
        activeProjectsCount: 15,
        pastCompletedProjects: 21,
        contactEmail: 'director@iiitranchi.ac.in',
        contactPhone: '+91 651 2233005',
        website: 'https://www.iiitranchi.ac.in',
      },
      {
        id: 'uni-vbu-hazaribagh',
        name: 'Vinoba Bhave University (VBU)',
        shortName: 'VBU Hazaribagh',
        district: 'Hazaribagh',
        address: 'Sindoor, Hazaribagh, Jharkhand 825301',
        type: 'State University',
        departments: [
          'Biotechnology',
          'Botany',
          'Physics',
          'Geology',
          'Computer Applications',
          'Commerce & Rural Management'
        ],
        facultyExpertise: ['Coal Belt Groundwater Geochemistry', 'Bio-Fertilizer Formulation', 'Micro-Enterprise Rural Planning'],
        researchAreas: ['Damodar Basin Aquatic Health', 'Fly Ash Land Reclamation', 'Lac Weaver Market Chains'],
        innovationCenters: ['North Chotanagpur Innovation Cell'],
        incubationFacilities: ['Rural Incubation Desk'],
        laboratories: ['Hydro-Geochemistry Lab', 'Bio-Informatics Lab'],
        availableEquipment: ['Water Testing Multiparameter Photometer', 'Stereomicroscopes'],
        studentCount: 18000,
        facultyCount: 410,
        activeProjectsCount: 9,
        pastCompletedProjects: 19,
        contactEmail: 'vc@vbu.ac.in',
        contactPhone: '+91 6546 264212',
        website: 'https://www.vbu.ac.in',
      },
      {
        id: 'uni-kolhan',
        name: 'Kolhan University',
        shortName: 'Kolhan University',
        district: 'West Singhbhum',
        address: 'Chaibasa, West Singhbhum, Jharkhand 833202',
        type: 'State University',
        departments: [
          'Tribal Studies & Languages (Ho/Mundari)',
          'Botany',
          'Chemistry',
          'Computer Science',
          'Sociology'
        ],
        facultyExpertise: ['Saranda Forest Ethnobotany', 'Iron Ore Slurry Water Treatment', 'Tribal Healthcare Surveying'],
        researchAreas: ['Heavy Metal Infiltration in Mining Rivers', 'Nutritional Anemia in Tribal Children', 'Forest Minor Produce Storage'],
        innovationCenters: ['Kolhan Grassroots Innovation Desk'],
        incubationFacilities: ['Chaibasa Rural Technology Demo Center'],
        laboratories: ['Water Chemistry Testing Lab', 'Botanical Extraction Lab'],
        availableEquipment: ['Digital Colorimeter', 'Soxhlet Extraction Units'],
        studentCount: 14000,
        facultyCount: 320,
        activeProjectsCount: 7,
        pastCompletedProjects: 16,
        contactEmail: 'registrar@kolhanuniversity.ac.in',
        contactPhone: '+91 6582 255274',
        website: 'https://www.kolhanuniversity.ac.in',
      },
      {
        id: 'uni-polytechnic-ranchi',
        name: 'Government Polytechnic Ranchi',
        shortName: 'Govt Poly Ranchi',
        district: 'Ranchi',
        address: 'Church Road, Ranchi, Jharkhand 834001',
        type: 'Polytechnic',
        departments: [
          'Civil Engineering',
          'Electrical Engineering',
          'Mechanical Engineering',
          'Computer Science'
        ],
        facultyExpertise: ['Fabrication of Handpump Replacements', 'Solar Panel Maintenance', 'Masonry Water Tanks'],
        researchAreas: ['Low-Cost Community Filtration Units', 'Panchayat Level Electrical Repairs'],
        innovationCenters: ['Polytechnic Community Skill Wing'],
        incubationFacilities: ['Welding & Machine Workshop'],
        laboratories: ['Civil Materials Testing Workshop', 'Electrical Machines Lab'],
        availableEquipment: ['Lathe Machines', 'Concrete Compression Testers', 'Electrical Multimeters'],
        studentCount: 1100,
        facultyCount: 55,
        activeProjectsCount: 5,
        pastCompletedProjects: 14,
        contactEmail: 'gpranchi@rediffmail.com',
        contactPhone: '+91 651 2350123',
        website: 'https://www.gpranchi.ac.in',
      },
    ];

    // Faculty Mentors
    const faculty: FacultyMentor[] = [
      {
        id: 'fac-01',
        universityId: 'uni-bit-mesra',
        universityName: 'Birla Institute of Technology (BIT) Mesra',
        name: 'Dr. Sudip Das',
        department: 'Civil & Environmental Engineering',
        designation: 'Professor & Head',
        specialization: ['Rural Water Treatment', 'Membrane Filtration', 'Fluoride Removal Chemistry'],
        projectsMentored: 12,
        email: 'sdas@bitmesra.ac.in',
      },
      {
        id: 'fac-02',
        universityId: 'uni-bit-mesra',
        universityName: 'Birla Institute of Technology (BIT) Mesra',
        name: 'Dr. Vandana Bhattacharjee',
        department: 'Computer Science & Engineering',
        designation: 'Professor',
        specialization: ['IoT Telemetry', 'Edge Embedded Sensors', 'Smart City Monitoring'],
        projectsMentored: 16,
        email: 'vbhattacharjee@bitmesra.ac.in',
      },
      {
        id: 'fac-03',
        universityId: 'uni-iit-ism-dhanbad',
        universityName: 'IIT (ISM) Dhanbad',
        name: 'Dr. Priyadarshini Sengupta',
        department: 'Environmental Science & Engineering',
        designation: 'Associate Professor',
        specialization: ['Mine Drainage Purification', 'Groundwater Contamination', 'Heavy Metals'],
        projectsMentored: 14,
        email: 'p.sengupta@iitism.ac.in',
      },
      {
        id: 'fac-04',
        universityId: 'uni-nit-jamshedpur',
        universityName: 'NIT Jamshedpur',
        name: 'Dr. Niranjan Kumar',
        department: 'Electrical Engineering',
        designation: 'Professor',
        specialization: ['Decentralized Solar Microgrids', 'Rural Energy Storage', 'Smart Power'],
        projectsMentored: 9,
        email: 'nkumar.ee@nitjsr.ac.in',
      },
      {
        id: 'fac-05',
        universityId: 'uni-birsa-agri',
        universityName: 'Birsa Agricultural University (BAU)',
        name: 'Dr. Ramesh Chandra Jha',
        department: 'Agricultural Engineering',
        designation: 'Senior Scientist',
        specialization: ['Micro-Irrigation Automation', 'Solar Crop Dryers', 'Soil Moisture Sensors'],
        projectsMentored: 11,
        email: 'rcjha@bauranchi.org',
      },
    ];

    // Students
    const students: StudentMember[] = [
      {
        id: 'stu-01',
        name: 'Kunal Kumar',
        universityId: 'uni-bit-mesra',
        universityName: 'BIT Mesra',
        department: 'Civil & Environmental Engineering',
        yearOfStudy: 'Final Year B.Tech',
        skills: ['Water Quality Testing', 'Hydraulic Piping CAD', 'Filter Media Formulation'],
        roleInProject: 'Field Hydraulics & Filter Bed Design',
      },
      {
        id: 'stu-02',
        name: 'Ananya Verma',
        universityId: 'uni-bit-mesra',
        universityName: 'BIT Mesra',
        department: 'Computer Science & Engineering',
        yearOfStudy: '3rd Year B.Tech',
        skills: ['Embedded C/C++', 'ESP32 IoT Firmware', 'MQTT Cloud Messaging', 'React Dashboards'],
        roleInProject: 'Firmware & Telemetry Architect',
      },
      {
        id: 'stu-03',
        name: 'Abhishek Murmu',
        universityId: 'uni-nit-jamshedpur',
        universityName: 'NIT Jamshedpur',
        department: 'Electronics & Communication',
        yearOfStudy: 'Final Year B.Tech',
        skills: ['Low-Power PCB Design', 'Solar Battery Charging ICs', 'LoRaWAN RF Tuning'],
        roleInProject: 'Hardware Power Optimization Lead',
      },
      {
        id: 'stu-04',
        name: 'Pooja Soren',
        universityId: 'uni-birsa-agri',
        universityName: 'Birsa Agricultural University',
        department: 'Soil Science & Agronomy',
        yearOfStudy: 'M.Sc. Agri (2nd Year)',
        skills: ['Field Sampling', 'Microbiological Culturing', 'Community Training in Vernacular'],
        roleInProject: 'Community Adoption & Water Testing Lead',
      },
      {
        id: 'stu-05',
        name: 'Rohit Mandal',
        universityId: 'uni-iit-ism-dhanbad',
        universityName: 'IIT (ISM) Dhanbad',
        department: 'Computer Science',
        yearOfStudy: 'Final Year B.Tech',
        skills: ['Python Data Pipelines', 'GIS Mapping', 'Mobile App Development'],
        roleInProject: 'Mobile Dashboard & Alert System',
      },
    ];

    // 10 Industry Partners & CSR Organizations
    const industryPartners: IndustryPartner[] = [
      {
        id: 'ind-tata-steel',
        companyName: 'Tata Steel Rural Development Society (TSRDS)',
        industrySector: 'Mining, Metals & Rural CSR Foundation',
        partnerType: 'Corporate/Industry',
        district: 'East Singhbhum',
        expertise: ['Community Water Systems', 'Tribal Livelihood Incubation', 'Rural Healthcare Clinics'],
        technologies: ['Water Purification Skids', 'Solar Micro-Utilities', 'Field Telemedicine Vans'],
        csrFocusAreas: ['Drinking Water', 'Maternal Health', 'Education', 'Sustainable Livelihoods'],
        fundingCapacity: '₹50 Lakhs - ₹2.5 Crores per Fiscal',
        mentorshipCapability: ['Senior Project Managers', 'Industrial Chemists', 'Civil Infrastructure Engineers'],
        labFacilities: ['TSRDS Environmental Monitoring Station, Jamshedpur'],
        deploymentCapabilities: ['Direct operational access to 600+ villages in East/West Singhbhum & Saraikela'],
        contactPerson: 'Vikramaditya Singhania',
        email: 'csr.tsrds@tatasteel.com',
        phone: '+91 657 6645000',
        activePledgesCount: 6,
      },
      {
        id: 'ind-sail-bokaro',
        companyName: 'SAIL Bokaro Steel Plant CSR',
        industrySector: 'Steel Manufacturing & Industrial CSR',
        partnerType: 'CSR Foundation',
        district: 'Bokaro',
        expertise: ['Industrial Waste Utilization', 'Fly Ash Concrete', 'Slag Treatment'],
        technologies: ['Industrial Automation', 'Heavy Slurry Pumps', 'Metallurgical Testing'],
        csrFocusAreas: ['Environmental Restoration', 'Vocational Skill Centers', 'Peripheral Village Water'],
        fundingCapacity: '₹40 Lakhs - ₹1.5 Crores',
        mentorshipCapability: ['Senior Metallurgical & Chemical Process Engineers'],
        labFacilities: ['SAIL Quality Assurance & Environmental R&D Lab, Bokaro'],
        deploymentCapabilities: ['Heavy transport & civil construction machinery in Bokaro & Giridih belts'],
        contactPerson: 'Anandita Banerjee',
        email: 'csr@sailbokaro.co.in',
        phone: '+91 6542 240333',
        activePledgesCount: 4,
      },
      {
        id: 'ind-jaltech',
        companyName: 'JalTech Solutions Pvt Ltd',
        industrySector: 'CleanTech / Water IoT Startup',
        partnerType: 'Startup',
        district: 'Ranchi',
        expertise: ['Low-Cost Ultrasonic Water Level Sensors', 'Solar Chlorination Pumps', 'Cellular Telemetry'],
        technologies: ['NB-IoT / GSM Telemetry', 'Capacitive Water Quality Probes', 'Cloud Analytics Engine'],
        csrFocusAreas: ['Piped Water Reliability', 'Fluoride Warning Systems'],
        fundingCapacity: 'Seed Stage / Prototype Co-Sponsorship (up to ₹8 Lakhs)',
        mentorshipCapability: ['IoT Embedded Firmware Engineers', 'Startup Product Managers'],
        labFacilities: ['JalTech Rapid Hardware Prototyping Bench, Namkum Ranchi'],
        deploymentCapabilities: ['Turnkey installation of telemetry boards in rural overhead tanks'],
        contactPerson: 'Neha Soren',
        email: 'contact@jaltech-solutions.in',
        phone: '+91 70041 98765',
        activePledgesCount: 3,
      },
      {
        id: 'ind-bccl',
        companyName: 'Bharat Coking Coal Limited (BCCL) Innovation Cell',
        industrySector: 'Energy & Natural Resources',
        partnerType: 'Corporate/Industry',
        district: 'Dhanbad',
        expertise: ['Mine Water Recycling', 'Subsidence Monitoring', 'Dust Suppression Sprinklers'],
        technologies: ['Heavy Sludge Filtration', 'Borehole Seismic Sensors'],
        csrFocusAreas: ['Mine Water to Potable Drinking Water Conversion for Dhanbad Hamlets'],
        fundingCapacity: '₹30 Lakhs - ₹1.2 Crores',
        mentorshipCapability: ['Hydrogeologists', 'Environmental Scientists'],
        labFacilities: ['BCCL Central Mine Water Testing Station, Koyla Nagar'],
        deploymentCapabilities: ['Large-scale piping and mine void water discharge infrastructure'],
        contactPerson: 'Arun Kumar Mishra',
        email: 'innovation@bccl.gov.in',
        phone: '+91 326 2230190',
        activePledgesCount: 5,
      },
      {
        id: 'ind-hec',
        companyName: 'Heavy Engineering Corporation (HEC) Ltd',
        industrySector: 'Heavy Industrial Machinery & Equipment',
        partnerType: 'Corporate/Industry',
        district: 'Ranchi',
        expertise: ['High-Strength Structural Steel Casting', 'Deep Borewell Casing', 'Heavy Valves'],
        technologies: ['CNC Heavy Machining', 'Fabrication of Sluice Gates'],
        csrFocusAreas: ['Skill Training in Machining', 'Rural Bridge Iron Assemblies'],
        fundingCapacity: 'Equipment & Fabrication Grants (up to ₹25 Lakhs in kind)',
        mentorshipCapability: ['Chief Mechanical Design Engineers'],
        labFacilities: ['HEC Machine Tools & Foundry Testing Division, Dhurwa Ranchi'],
        deploymentCapabilities: ['Heavy fabrication of custom water intake screens and valves'],
        contactPerson: 'B. P. Singh',
        email: 'rnd@hecltd.com',
        phone: '+91 651 2401200',
        activePledgesCount: 2,
      },
      {
        id: 'ind-techeagle',
        companyName: 'TechEagle Innovations (Jharkhand Drone Delivery Partner)',
        industrySector: 'Aerospace / DeepTech Startup',
        partnerType: 'Startup',
        district: 'Ranchi',
        expertise: ['Autonomous Long-Range Cargo Drones', 'Cold Chain Vaccine Transport', 'Aerial GIS Mapping'],
        technologies: ['VTOL Hybrid Drones', 'Onboard Thermal Imagery', 'Beyond Visual Line of Sight (BVLOS)'],
        csrFocusAreas: ['Emergency Medicine Delivery to Cut-Off Hill Villages'],
        fundingCapacity: 'Flight Hours & Pilot Testing Support',
        mentorshipCapability: ['Avionics Engineers', 'GIS Analysts'],
        labFacilities: ['Drone Testing Hangar, Tatisilwai'],
        deploymentCapabilities: ['Air deliveries across Saranda forest and Netarhat plateau'],
        contactPerson: 'Vikram Patel',
        email: 'ops@techeagle.aero',
        phone: '+91 99887 76655',
        activePledgesCount: 2,
      },
      {
        id: 'ind-mecon',
        companyName: 'MECON Limited (A Govt of India Enterprise)',
        industrySector: 'Engineering Consultancy & Infrastructure Design',
        partnerType: 'Corporate/Industry',
        district: 'Ranchi',
        expertise: ['Water Distribution Network Design', 'Structural Civil Engineering', 'Renewable Energy EPC'],
        technologies: ['BIM Architectural Modeling', 'Hydraulic Surge Analysis Software'],
        csrFocusAreas: ['Rural School Infrastructure Upgrades', 'Safe Potable Water'],
        fundingCapacity: '₹20 Lakhs - ₹80 Lakhs',
        mentorshipCapability: ['Senior Engineering Consultants & Structural Architects'],
        labFacilities: ['MECON Engineering Simulation Center, Doranda Ranchi'],
        deploymentCapabilities: ['Detailed project reports (DPR) and municipal certification'],
        contactPerson: 'Rajeev Srivastava',
        email: 'csr@meconlimited.co.in',
        phone: '+91 651 2483000',
        activePledgesCount: 3,
      },
      {
        id: 'ind-jredaltd',
        companyName: 'Jharkhand Renewable Energy Development Agency (JREDA)',
        industrySector: 'State Renewable Energy Nodal Agency',
        partnerType: 'Innovation Hub',
        district: 'Ranchi',
        expertise: ['Solar Microgrids', 'Biomass Plants', 'Solar Water Pumping Schemes'],
        technologies: ['Grid-Interactive Solar Inverters', 'Smart Battery Management'],
        csrFocusAreas: ['Zero-Emission Rural Hamlets', 'Solar-Powered Irrigation'],
        fundingCapacity: 'State Subsidy & Scheme Convergence (up to ₹1 Crore)',
        mentorshipCapability: ['Solar PV System Engineers'],
        labFacilities: ['JREDA Solar Equipment Calibration Bench'],
        deploymentCapabilities: ['Subsidized supply of solar panels and pump controllers'],
        contactPerson: 'K. S. Prasad',
        email: 'director@jreda.com',
        phone: '+91 651 2240111',
        activePledgesCount: 4,
      },
      {
        id: 'ind-ushamartin',
        companyName: 'Usha Martin Foundation',
        industrySector: 'Specialty Steel & Wire Ropes / CSR',
        partnerType: 'CSR Foundation',
        district: 'Ranchi',
        expertise: ['Natural Resource Management', 'Micro-Checkdams', 'Tussar Silk Weaving Cooperatives'],
        technologies: ['Soil & Moisture Conservation Structures', 'Solar Weaving Looms'],
        csrFocusAreas: ['Water Security in Khunti & Ranchi Rural', 'Women SHG Livelihoods'],
        fundingCapacity: '₹25 Lakhs - ₹75 Lakhs',
        mentorshipCapability: ['Agricultural Specialists', 'Social Impact Evaluators'],
        labFacilities: ['Usha Martin Krishi Seva Demonstration Farm, Angara'],
        deploymentCapabilities: ['Field mobilization through 200+ established SHG village networks'],
        contactPerson: 'Shanti Tigga',
        email: 'foundation@ushamartin.com',
        phone: '+91 651 3051400',
        activePledgesCount: 3,
      },
      {
        id: 'ind-acic-jharkhand',
        companyName: 'Atal Community Innovation Center (ACIC) Jharkhand',
        industrySector: 'Grassroots Innovation & Incubation Platform',
        partnerType: 'Innovation Hub',
        district: 'Ranchi',
        expertise: ['Grassroots Prototyping', 'Intellectual Property & Patents', 'Technology Transfer'],
        technologies: ['Maker Spaces', 'Pre-Compliance Testing', 'Product Industrial Design'],
        csrFocusAreas: ['Student Innovator Seed Grants', 'Tribal Artisan Technology Upgrades'],
        fundingCapacity: 'Grants up to ₹15 Lakhs per validated SIH prototype',
        mentorshipCapability: ['Patent Attorneys', 'Hardware Incubation Specialists'],
        labFacilities: ['ACIC Grassroots Innovation Maker Lab, Ranchi'],
        deploymentCapabilities: ['Commercial startup incubation and intellectual property filing'],
        contactPerson: 'Rohit Kujur',
        email: 'ceo@acic-jharkhand.org',
        phone: '+91 651 2911000',
        activePledgesCount: 7,
      },
    ];

    // 20+ Realistic Synthetic Jharkhand Challenges across districts
    const challenges: Challenge[] = [
      {
        id: 'CB-JH-2026-000001',
        title: 'Unreliable Drinking Water Supply and Groundwater Fluoride Contamination in Angara Block',
        detailedDescription: 'In Angara block (villages Nawagarh, Hesal, and child hamlets), over 3,200 villagers face severe drinking water scarcity. Five out of seven government handpumps discharge turbid water containing fluoride levels exceeding 3.8 mg/L (WHO permissible limit is 1.5 mg/L). Children exhibit visible dental mottling and elderly complain of joint stiffness. Existing manual handpump chlorination is irregular with no real-time telemetry or community alert when contamination spikes during monsoon months.',
        domain: 'Water Resources',
        location: {
          state: 'Jharkhand',
          district: 'Ranchi',
          block: 'Angara',
          villageOrCity: 'Nawagarh & Hesal',
          pincode: '835103',
          gpsCoordinates: { latitude: 23.4124, longitude: 85.5218 },
        },
        affectedPopulation: 3200,
        urgency: 'High',
        expectedOutcome: 'A solar-powered IoT automated filtration and telemetry unit deployed at community overhead tanks with automated SMS alerts to the Panchayat and Mukhiya when fluoride or turbidity exceeds safe limits.',
        availableResources: 'Gram Panchayat hall for equipment housing, community borehole with 2HP submersible pump, active women SHG group ready to manage distribution.',
        contactName: 'Sunita Munda',
        contactPhone: '+91 94311 02841',
        contactEmail: 'sunita.munda@jharkhand-citizen.in',
        media: [
          {
            id: 'med-01',
            name: 'angara_handpump_sample.jpg',
            type: 'image',
            url: 'https://images.unsplash.com/photo-1541888946425-d0fbb18f15f0?w=800&auto=format&fit=crop',
            sizeBytes: 1845000,
            uploadedAt: '2026-01-14T09:30:00Z',
          },
          {
            id: 'med-02',
            name: 'district_water_testing_report_2025.pdf',
            type: 'pdf',
            url: 'https://example.gov.in/docs/water_lab_angara.pdf',
            sizeBytes: 420000,
            uploadedAt: '2026-01-14T09:32:00Z',
          },
        ],
        status: 'Project Started',
        submittedByUserId: 'usr-citizen-01',
        submittedByName: 'Sunita Munda (Angara Village Dev Committee)',
        submittedAt: '2026-01-14T09:40:00Z',
        validatedBy: 'Dr. Rajeshwar Sharma, IAS (Joint Secretary)',
        validatedAt: '2026-01-16T11:00:00Z',
        validationNotes: 'Priority verified against district water lab records. Recommended for immediate university-industry co-development with BIT Mesra and JalTech/Tata Steel.',
        assignedUniversityId: 'uni-bit-mesra',
        assignedUniversityName: 'Birla Institute of Technology (BIT) Mesra',
        assignedAt: '2026-01-18T10:00:00Z',
        activeProjectId: 'PRJ-JH-2026-001',
        duplicateCandidates: [],
      },
      {
        id: 'CB-JH-2026-000002',
        title: 'Severe Arsenic and Iron Groundwater Seepage in Rural Borewells of Rajmahal Belt',
        detailedDescription: 'Multiple handpumps in Udhwa and Rajmahal blocks are drawing reddish groundwater with high arsenic and dissolved iron content. Local tribal farmers report recurring gastrointestinal sickness and skin lesions. No low-cost local filtration media is currently available to tribal families.',
        domain: 'Water Resources',
        location: {
          state: 'Jharkhand',
          district: 'Sahibganj',
          block: 'Rajmahal',
          villageOrCity: 'Udhwa & Kankjol',
          pincode: '816108',
          gpsCoordinates: { latitude: 25.0512, longitude: 87.8341 },
        },
        affectedPopulation: 5400,
        urgency: 'Emergency',
        expectedOutcome: 'Indigenous bio-sand and iron-scrap composite adsorbent filters suitable for household retrofitting on handpumps.',
        availableResources: 'Local masonry youth willing to construct filter enclosures, Gram Panchayat support.',
        contactName: 'Rameshwar Hansda',
        contactPhone: '+91 94302 44551',
        contactEmail: 'r.hansda@sahibganj-rural.org',
        media: [],
        status: 'Validated',
        submittedByUserId: 'usr-citizen-01',
        submittedByName: 'Rameshwar Hansda',
        submittedAt: '2026-01-18T14:15:00Z',
        validatedBy: 'Dr. Rajeshwar Sharma, IAS',
        validatedAt: '2026-01-20T10:30:00Z',
        validationNotes: 'Critical health hazard. Route to IIT (ISM) Dhanbad Environmental Engineering.',
        assignedUniversityId: 'uni-iit-ism-dhanbad',
        assignedUniversityName: 'IIT (ISM) Dhanbad',
        assignedAt: '2026-01-22T09:00:00Z',
        duplicateCandidates: [],
      },
      {
        id: 'CB-JH-2026-000003',
        title: 'Post-Harvest Lac and Tussar Cocoon Moisture Spoilage in Khunti Tribal Clusters',
        detailedDescription: 'Over 1,800 Adivasi lac and tussar silkworm cultivators in Murhu and Torpa blocks lose up to 35% of their seasonal harvest due to fungal attack and uncontrolled moisture during storage. Cultivators lack temperature-humidity regulated micro-storage facilities and sell raw produce at distress prices to middlemen.',
        domain: 'Rural Livelihoods',
        location: {
          state: 'Jharkhand',
          district: 'Khunti',
          block: 'Murhu',
          villageOrCity: 'Torpa & Jikilata',
          pincode: '835216',
          gpsCoordinates: { latitude: 23.0721, longitude: 85.2789 },
        },
        affectedPopulation: 1850,
        urgency: 'High',
        expectedOutcome: 'Low-cost solar-powered desiccant-based micro-storage chamber and digital auction aggregation app for self-help groups.',
        availableResources: '12 active Women Self Help Groups (SHGs) under JSLPS, community warehouse shed.',
        contactName: 'Mary Margaret Tirkey',
        contactPhone: '+91 94701 22334',
        contactEmail: 'mary@jharkhand-tribalwelfare.org',
        media: [],
        status: 'Project Started',
        submittedByUserId: 'usr-community-01',
        submittedByName: 'Mary Margaret Tirkey (Chotanagpur Adivasi Sewa Samiti)',
        submittedAt: '2026-01-12T11:00:00Z',
        validatedBy: 'Dr. Rajeshwar Sharma, IAS',
        validatedAt: '2026-01-15T15:00:00Z',
        validationNotes: 'Key tribal economic priority. Convergence with Birsa Agricultural University and Usha Martin Foundation.',
        assignedUniversityId: 'uni-birsa-agri',
        assignedUniversityName: 'Birsa Agricultural University (BAU)',
        assignedAt: '2026-01-17T11:30:00Z',
        activeProjectId: 'PRJ-JH-2026-002',
        duplicateCandidates: [],
      },
      {
        id: 'CB-JH-2026-000004',
        title: 'Lack of Vernacular (Santhali Ol Chiki & Ho) Digital Learning Content in Remote Primary Schools',
        detailedDescription: 'Primary schools in Saranda forest hamlets face an acute problem where children entering Class 1 only speak Ho or Santhali dialects, whereas official textbooks are in Hindi or English. Teacher vacancy has resulted in 42% dropout rates before Class 5. Classrooms have no internet connectivity.',
        domain: 'Education',
        location: {
          state: 'Jharkhand',
          district: 'West Singhbhum',
          block: 'Manoharpur',
          villageOrCity: 'Chiria & Digha',
          pincode: '833106',
          gpsCoordinates: { latitude: 22.3112, longitude: 85.2941 },
        },
        affectedPopulation: 4100,
        urgency: 'High',
        expectedOutcome: 'Offline-first solar tablet audio-visual pedagogy tool with synchronized Ol Chiki/Ho audio and Hindi bridge curriculum.',
        availableResources: '5 primary school buildings with solar rooftop installations, motivated local Shiksha Doots.',
        contactName: 'Sukram Munda',
        contactPhone: '+91 94318 77665',
        contactEmail: 'sukram.munda@westsinghbhum.org',
        media: [],
        status: 'Proposal Under Review',
        submittedByUserId: 'usr-citizen-01',
        submittedByName: 'Sukram Munda',
        submittedAt: '2026-01-20T09:00:00Z',
        validatedBy: 'Dr. Rajeshwar Sharma, IAS',
        validatedAt: '2026-01-22T14:00:00Z',
        validationNotes: 'High pedagogical significance. Match with IIIT Ranchi and Kolhan University Tribal Studies.',
        assignedUniversityId: 'uni-iiit-ranchi',
        assignedUniversityName: 'IIIT Ranchi',
        assignedAt: '2026-01-24T16:00:00Z',
        duplicateCandidates: [],
      },
      {
        id: 'CB-JH-2026-000005',
        title: 'High Infant & Maternal Anemia and Delayed Emergency Transport in Palamu Plateau',
        detailedDescription: 'Pregnant tribal women in remote Daltonganj and Chainpur hamlets suffer from severe anemia (Hb < 8 g/dL). Due to rocky terrain and mobile network blindspots, calling an ambulance during labor often fails, resulting in home deliveries and preventable neonatal complications.',
        domain: 'Healthcare',
        location: {
          state: 'Jharkhand',
          district: 'Palamu',
          block: 'Chainpur',
          villageOrCity: 'Koshiara & Semra',
          pincode: '822110',
          gpsCoordinates: { latitude: 24.0415, longitude: 84.0722 },
        },
        affectedPopulation: 6800,
        urgency: 'Emergency',
        expectedOutcome: 'Solar-powered emergency SOS beacon network with SMS mesh relayed to nearest CHC and digital nutrition monitoring kit for ASHAs.',
        availableResources: '36 active ASHA workers with basic smartphones, Community Health Centre in Chainpur.',
        contactName: 'Dr. Anita Tirkey',
        contactPhone: '+91 94311 88990',
        contactEmail: 'anita.tirkey@palamuhealth.gov.in',
        media: [],
        status: 'Validated',
        submittedByUserId: 'usr-gov-01',
        submittedByName: 'District Health Society, Palamu',
        submittedAt: '2026-01-25T11:00:00Z',
        validatedBy: 'Dr. Rajeshwar Sharma, IAS',
        validatedAt: '2026-01-26T12:00:00Z',
        validationNotes: 'Urgent life-saving intervention. Recommended for tech consortium with BIT Mesra Bioengineering & TechEagle.',
        assignedUniversityId: 'uni-bit-mesra',
        assignedUniversityName: 'BIT Mesra',
        assignedAt: '2026-01-28T10:00:00Z',
        duplicateCandidates: [],
      },
      {
        id: 'CB-JH-2026-000006',
        title: 'Frequent Coal Spoil Dust Dispersion and Respiratory Ailments in Bermo Coalfields',
        detailedDescription: 'High ambient PM2.5 and PM10 particulate levels caused by unpaved coal transportation roads and open-cast overburdens in Bermo block. Residents and schoolchildren suffer from chronic bronchitis and eye irritation. No automated misting or real-time dust monitoring currently exists.',
        domain: 'Environment',
        location: {
          state: 'Jharkhand',
          district: 'Bokaro',
          block: 'Bermo',
          villageOrCity: 'Phusro & Jaridih',
          pincode: '829144',
          gpsCoordinates: { latitude: 23.7712, longitude: 85.8741 },
        },
        affectedPopulation: 8900,
        urgency: 'High',
        expectedOutcome: 'Low-cost ambient optical dust sensor array triggering automated solar-powered misting cannons when PM10 exceeds safety limits.',
        availableResources: 'Local municipal roadside poles, industrial water supply available from nearby mining washery.',
        contactName: 'Sanjay Rawani',
        contactPhone: '+91 94313 11223',
        contactEmail: 'sanjay.rawani@bermo-civic.in',
        media: [],
        status: 'Under Validation',
        submittedByUserId: 'usr-citizen-01',
        submittedByName: 'Sanjay Rawani',
        submittedAt: '2026-01-28T16:00:00Z',
        duplicateCandidates: [],
      },
      {
        id: 'CB-JH-2026-000007',
        title: 'Recurrent Hill Stream Flash Flood Damage to Rural Culverts in Netarhat Plateau',
        detailedDescription: 'Monsoon flash floods routinely wash out traditional stone-masonry pipe culverts on the link roads connecting Latehar villages to the Netarhat marketplace, cutting off 12 villages for up to 3 weeks each year and stranding agricultural trucks.',
        domain: 'Infrastructure',
        location: {
          state: 'Jharkhand',
          district: 'Latehar',
          block: 'Mahuadanr',
          villageOrCity: 'Netarhat Valley',
          pincode: '829202',
          gpsCoordinates: { latitude: 23.4812, longitude: 84.2711 },
        },
        affectedPopulation: 4500,
        urgency: 'High',
        expectedOutcome: 'Modular geocell and bamboo-composite precast culvert design capable of withstanding heavy velocity runoff with rapid assembly.',
        availableResources: 'Abundant native bamboo groves, enthusiastic Gram Rozgar Sevaks for construction.',
        contactName: 'Kameshwar Oraon',
        contactPhone: '+91 94319 66778',
        contactEmail: 'kameshwar.oraon@latehar-panchayat.in',
        media: [],
        status: 'Assigned',
        submittedByUserId: 'usr-citizen-01',
        submittedByName: 'Kameshwar Oraon',
        submittedAt: '2026-01-19T10:00:00Z',
        validatedBy: 'Dr. Rajeshwar Sharma, IAS',
        validatedAt: '2026-01-21T11:00:00Z',
        assignedUniversityId: 'uni-nit-jamshedpur',
        assignedUniversityName: 'NIT Jamshedpur',
        assignedAt: '2026-01-23T14:00:00Z',
        duplicateCandidates: [],
      },
      {
        id: 'CB-JH-2026-000008',
        title: 'Off-Grid Hamlets in Saranda Forest Suffering from Dark Nights and Elephant Conflict',
        detailedDescription: 'Six hamlets deep inside Saranda reserve forest have zero conventional electrical grid access. Wild elephants frequently enter village boundaries at night, damaging mud houses and destroying stored grain. Kerosene lanterns are dangerous fire hazards.',
        domain: 'Energy',
        location: {
          state: 'Jharkhand',
          district: 'West Singhbhum',
          block: 'Noamundi',
          villageOrCity: 'Kumdi & Karampada',
          pincode: '833217',
          gpsCoordinates: { latitude: 22.1524, longitude: 85.3112 },
        },
        affectedPopulation: 2100,
        urgency: 'High',
        expectedOutcome: 'Solar DC microgrids with acoustic elephant-deterrent frequency beacons powered by daytime solar charging.',
        availableResources: 'Community forest protection committee, forest department check-post nearby.',
        contactName: 'Mangal Ho',
        contactPhone: '+91 94317 22110',
        contactEmail: 'mangal.ho@saranda.org',
        media: [],
        status: 'Under AI Analysis',
        submittedByUserId: 'usr-citizen-01',
        submittedByName: 'Mangal Ho',
        submittedAt: '2026-01-30T09:30:00Z',
        duplicateCandidates: [],
      },
      {
        id: 'CB-JH-2026-000009',
        title: 'Untreated Industrial & Municipal Sewage Inflow into Subarnarekha River at Namkum',
        detailedDescription: 'Open stormwater and industrial drains from small manufacturing clusters in Namkum industrial estate dump untreated toxic blackwater directly into the holy Subarnarekha river, destroying freshwater aquatic life and polluting downstream drinking intakes.',
        domain: 'Sanitation',
        location: {
          state: 'Jharkhand',
          district: 'Ranchi',
          block: 'Namkum',
          villageOrCity: 'Namkum & Tupudana',
          pincode: '834010',
          gpsCoordinates: { latitude: 23.3421, longitude: 85.3812 },
        },
        affectedPopulation: 14000,
        urgency: 'High',
        expectedOutcome: 'Constructed wetland bio-treatment channel using local vetiver grass and microbial consortium before river outfall.',
        availableResources: 'Available government wasteland along the drain bank, active student volunteer groups.',
        contactName: 'Abhay Prasad',
        contactPhone: '+91 94311 33445',
        contactEmail: 'abhay.prasad@namkum.org',
        media: [],
        status: 'Validated',
        submittedByUserId: 'usr-citizen-01',
        submittedByName: 'Abhay Prasad',
        submittedAt: '2026-01-22T13:00:00Z',
        validatedBy: 'Dr. Rajeshwar Sharma, IAS',
        validatedAt: '2026-01-24T15:30:00Z',
        assignedUniversityId: 'uni-ranchi-university',
        assignedUniversityName: 'Ranchi University',
        assignedAt: '2026-01-26T11:00:00Z',
        duplicateCandidates: [],
      },
      {
        id: 'CB-JH-2026-000010',
        title: 'Paddy Crop Stem Borer Infestation and Severe Yield Drop in Dumka Santhal Parganas',
        detailedDescription: 'Over 650 marginal tribal farmers in Ranishwar block are facing recurrent yellow stem borer pest attacks on Kharif paddy crops. Farmers are using counterfeit chemical pesticides purchased from local weekly haats which burn crops without eliminating the larvae.',
        domain: 'Agriculture',
        location: {
          state: 'Jharkhand',
          district: 'Dumka',
          block: 'Ranishwar',
          villageOrCity: 'Kumirda & Hansdiha',
          pincode: '814148',
          gpsCoordinates: { latitude: 24.1289, longitude: 87.3512 },
        },
        affectedPopulation: 3800,
        urgency: 'High',
        expectedOutcome: 'Low-cost solar LED pheromone light traps combined with a simple WhatsApp/SMS vernacular diagnostic advisory for organic neem biopesticide spray.',
        availableResources: 'Local farmers club, Krishi Vigyan Kendra Dumka demonstration plots.',
        contactName: 'Hopna Murmu',
        contactPhone: '+91 94303 55667',
        contactEmail: 'hopna.murmu@dumka-farmers.in',
        media: [],
        status: 'Project Started',
        submittedByUserId: 'usr-citizen-01',
        submittedByName: 'Hopna Murmu',
        submittedAt: '2026-01-10T08:30:00Z',
        validatedBy: 'Dr. Rajeshwar Sharma, IAS',
        validatedAt: '2026-01-12T10:00:00Z',
        assignedUniversityId: 'uni-birsa-agri',
        assignedUniversityName: 'Birsa Agricultural University (BAU)',
        assignedAt: '2026-01-14T11:00:00Z',
        activeProjectId: 'PRJ-JH-2026-003',
        duplicateCandidates: [],
      },
      {
        id: 'CB-JH-2026-000011',
        title: 'Severe Fluoride Sickness and Broken Tubewells in Angara Nawagarh Cluster (Candidate Duplicate)',
        detailedDescription: 'Drinking water borewells in Nawagarh village are broken and water has yellow fluoride tint causing severe knee pain among school students.',
        domain: 'Water Resources',
        location: {
          state: 'Jharkhand',
          district: 'Ranchi',
          block: 'Angara',
          villageOrCity: 'Nawagarh',
          pincode: '835103',
          gpsCoordinates: { latitude: 23.4111, longitude: 85.5204 },
        },
        affectedPopulation: 2800,
        urgency: 'High',
        expectedOutcome: 'Fix water wells and install fluoride filters.',
        availableResources: 'Borewell pump in village center.',
        contactName: 'Budhram Bedia',
        contactPhone: '+91 94311 00223',
        contactEmail: 'budhram.bedia@jharkhand-mail.com',
        media: [],
        status: 'Under Validation',
        submittedByUserId: 'usr-citizen-01',
        submittedByName: 'Budhram Bedia',
        submittedAt: '2026-01-29T10:00:00Z',
        duplicateCandidates: [
          {
            existingChallengeId: 'CB-JH-2026-000001',
            existingTitle: 'Unreliable Drinking Water Supply and Groundwater Fluoride Contamination in Angara Block',
            similarityScore: 89,
            domain: 'Water Resources',
            district: 'Ranchi',
            status: 'Project Started',
          },
        ],
      },
      {
        id: 'CB-JH-2026-000012',
        title: 'Severe Soil Erosion and Rain Runoff Loss in Hazaribagh Barhi Sloping Farmlands',
        detailedDescription: 'During heavy monsoon showers, fertile topsoil from hilly undulating tracts in Barhi block is washed into river channels, causing soil infertility and silting up local village ponds.',
        domain: 'Agriculture',
        location: {
          state: 'Jharkhand',
          district: 'Hazaribagh',
          block: 'Barhi',
          villageOrCity: 'Padma & Chouparan',
          pincode: '825405',
          gpsCoordinates: { latitude: 24.2981, longitude: 85.4212 },
        },
        affectedPopulation: 2900,
        urgency: 'Medium',
        expectedOutcome: 'Low-cost continuous contour trenching and vetiver vegetative barriers with farm pond recharge modeling.',
        availableResources: 'MGNREGA labor allocation ready for earthworks.',
        contactName: 'Nandlal Mahto',
        contactPhone: '+91 94305 77889',
        contactEmail: 'nandlal.mahto@hazaribagh-agri.org',
        media: [],
        status: 'Submitted',
        submittedByUserId: 'usr-citizen-01',
        submittedByName: 'Nandlal Mahto',
        submittedAt: '2026-02-01T11:00:00Z',
        duplicateCandidates: [],
      },
      {
        id: 'CB-JH-2026-000013',
        title: 'Lack of Accessible Low-Cost Prosthetic Limbs for Rural Mining Amputees in Giridih',
        detailedDescription: 'Dozens of rural workers who lost limbs in informal mica picking and abandoned quarry accidents in Tisri and Gawan blocks are unable to afford commercial prosthetics (costing ₹40,000+), rendering them bedridden and impoverished.',
        domain: 'Accessibility',
        location: {
          state: 'Jharkhand',
          district: 'Giridih',
          block: 'Tisri',
          villageOrCity: 'Tisri & Lokai',
          pincode: '815317',
          gpsCoordinates: { latitude: 24.5612, longitude: 86.0521 },
        },
        affectedPopulation: 850,
        urgency: 'High',
        expectedOutcome: 'Custom 3D-printed modular mechanical prosthetic hand and below-knee sockets manufactured under ₹3,500 using recycled plastics.',
        availableResources: 'District Red Cross Society center for fitting trials.',
        contactName: 'Dr. Alok Verma',
        contactPhone: '+91 94311 99112',
        contactEmail: 'alok.verma@redcross-giridih.in',
        media: [],
        status: 'Validated',
        submittedByUserId: 'usr-citizen-01',
        submittedByName: 'Dr. Alok Verma',
        submittedAt: '2026-01-16T15:00:00Z',
        validatedBy: 'Dr. Rajeshwar Sharma, IAS',
        validatedAt: '2026-01-18T16:00:00Z',
        assignedUniversityId: 'uni-bit-mesra',
        assignedUniversityName: 'BIT Mesra',
        assignedAt: '2026-01-20T11:00:00Z',
        duplicateCandidates: [],
      },
      {
        id: 'CB-JH-2026-000014',
        title: 'Frequent PDS Biometric Authentication Failures in Remote Deoghar Villages',
        detailedDescription: 'Elderly pensioners and hard-working laborers with worn fingerprints in Mohanpur block face recurring biometric rejection at PDS ration shops. In intermittent cellular connectivity zones, PoS machines lock out, causing families to miss monthly subsidized grain quotas.',
        domain: 'Public Administration',
        location: {
          state: 'Jharkhand',
          district: 'Deoghar',
          block: 'Mohanpur',
          villageOrCity: 'Sarwan & Ghormara',
          pincode: '814143',
          gpsCoordinates: { latitude: 24.4812, longitude: 86.7212 },
        },
        affectedPopulation: 5200,
        urgency: 'High',
        expectedOutcome: 'Offline cryptographic token verification with two-party OTP backup and local store-and-forward transaction sync.',
        availableResources: '18 Fair Price Shops equipped with Android PoS terminals.',
        contactName: 'Pradeep Jha',
        contactPhone: '+91 94301 22998',
        contactEmail: 'pradeep.jha@deoghar-pds.gov.in',
        media: [],
        status: 'Under Validation',
        submittedByUserId: 'usr-citizen-01',
        submittedByName: 'Pradeep Jha',
        submittedAt: '2026-01-27T10:30:00Z',
        duplicateCandidates: [],
      },
      {
        id: 'CB-JH-2026-000015',
        title: 'Severe Waterlogging and Chronic Drainage Stagnation in Dhanbad Railway Colony',
        detailedDescription: 'Old British-era masonry storm drains in Dhanbad city are choked with plastic debris and silt. Even 20 minutes of rain causes knee-deep inundation, spreading dengue and damaging small retail shops.',
        domain: 'Urban Development',
        location: {
          state: 'Jharkhand',
          district: 'Dhanbad',
          block: 'Dhanbad Urban',
          villageOrCity: 'Bank More & Purana Bazar',
          pincode: '826001',
          gpsCoordinates: { latitude: 23.7951, longitude: 86.4304 },
        },
        affectedPopulation: 16500,
        urgency: 'High',
        expectedOutcome: 'Automated solar-powered trash-rack screen with ultrasonic water level warning telemetry and municipal SMS alerts.',
        availableResources: 'Dhanbad Municipal Corporation maintenance crews.',
        contactName: 'Kishore Agarwal',
        contactPhone: '+91 94311 77334',
        contactEmail: 'kishore@dhanbad-trade.org',
        media: [],
        status: 'Validated',
        submittedByUserId: 'usr-ulb-01',
        submittedByName: 'Kishore Agarwal (Dhanbad Traders Welfare)',
        submittedAt: '2026-01-21T12:00:00Z',
        validatedBy: 'Dr. Rajeshwar Sharma, IAS',
        validatedAt: '2026-01-23T14:30:00Z',
        assignedUniversityId: 'uni-iit-ism-dhanbad',
        assignedUniversityName: 'IIT (ISM) Dhanbad',
        assignedAt: '2026-01-25T15:00:00Z',
        duplicateCandidates: [],
      },
      {
        id: 'CB-JH-2026-000016',
        title: 'High Arsenic Contamination in Drinking Water across Udhwa Ganga Basin (Candidate Duplicate)',
        detailedDescription: 'People drinking water from government handpumps in Udhwa near Ganga river have skin spots and liver illness. Tube well water turns yellow after 10 minutes.',
        domain: 'Water Resources',
        location: {
          state: 'Jharkhand',
          district: 'Sahibganj',
          block: 'Udhwa',
          villageOrCity: 'Udhwa Village',
          pincode: '816108',
          gpsCoordinates: { latitude: 25.0491, longitude: 87.8312 },
        },
        affectedPopulation: 4900,
        urgency: 'Emergency',
        expectedOutcome: 'Provide clean drinking water and filters for arsenic.',
        availableResources: 'Handpumps present in every tola.',
        contactName: 'Mantu Mandal',
        contactPhone: '+91 94301 88221',
        contactEmail: 'mantu.mandal@mail.in',
        media: [],
        status: 'Under Validation',
        submittedByUserId: 'usr-citizen-01',
        submittedByName: 'Mantu Mandal',
        submittedAt: '2026-01-31T11:00:00Z',
        duplicateCandidates: [
          {
            existingChallengeId: 'CB-JH-2026-000002',
            existingTitle: 'Severe Arsenic and Iron Groundwater Seepage in Rural Borewells of Rajmahal Belt',
            similarityScore: 84,
            domain: 'Water Resources',
            district: 'Sahibganj',
            status: 'Validated',
          },
        ],
      },
      {
        id: 'CB-JH-2026-000017',
        title: 'Lack of Cold Chain Storage Causing 40% Spoilage of Organic Tomatoes in Ormanjhi',
        detailedDescription: 'Farmers in Ormanjhi block harvest bumper winter crops of high-grade tomatoes and cauliflower, but due to lack of local pre-cooling sheds, produce rots on highways before reaching urban markets.',
        domain: 'Agriculture',
        location: {
          state: 'Jharkhand',
          district: 'Ranchi',
          block: 'Ormanjhi',
          villageOrCity: 'Dugdug & Irba',
          pincode: '835219',
          gpsCoordinates: { latitude: 23.4721, longitude: 85.4891 },
        },
        affectedPopulation: 3100,
        urgency: 'Medium',
        expectedOutcome: 'Decentralized phase-change material (PCM) solar mini cold storage unit operating without grid power.',
        availableResources: 'Farmers producer company with land available alongside the Ranchi-Patna highway.',
        contactName: 'Ganesh Mahto',
        contactPhone: '+91 94313 88441',
        contactEmail: 'ganesh.mahto@ormanjhi-fpo.org',
        media: [],
        status: 'Submitted',
        submittedByUserId: 'usr-citizen-01',
        submittedByName: 'Ganesh Mahto',
        submittedAt: '2026-02-02T09:00:00Z',
        duplicateCandidates: [],
      },
      {
        id: 'CB-JH-2026-000018',
        title: 'Fly Ash Leaching into Groundwater Near Bokaro Thermal Power Environs',
        detailedDescription: 'Fly ash ponds from older thermal units leach alkaline slurry during monsoon rain into nearby well systems of Jaridih block. Water pH reads 8.9 and tests positive for heavy metals.',
        domain: 'Environment',
        location: {
          state: 'Jharkhand',
          district: 'Bokaro',
          block: 'Jaridih',
          villageOrCity: 'Bhandaridah & Telo',
          pincode: '829132',
          gpsCoordinates: { latitude: 23.7512, longitude: 86.0211 },
        },
        affectedPopulation: 7300,
        urgency: 'High',
        expectedOutcome: 'Permeable reactive geo-synthetic barriers to immobilize fly ash heavy metals and convert ash slurry into geo-polymer paving blocks.',
        availableResources: 'Direct access to fly ash disposal dykes.',
        contactName: 'Sunil Karmakar',
        contactPhone: '+91 94311 66554',
        contactEmail: 'sunil.k@bokaro-env.org',
        media: [],
        status: 'Validated',
        submittedByUserId: 'usr-citizen-01',
        submittedByName: 'Sunil Karmakar',
        submittedAt: '2026-01-23T10:00:00Z',
        validatedBy: 'Dr. Rajeshwar Sharma, IAS',
        validatedAt: '2026-01-25T12:00:00Z',
        assignedUniversityId: 'uni-nit-jamshedpur',
        assignedUniversityName: 'NIT Jamshedpur',
        assignedAt: '2026-01-27T14:00:00Z',
        duplicateCandidates: [],
      },
      {
        id: 'CB-JH-2026-000019',
        title: 'Acute Iron Deficient Well Water in Chaibasa Mining Periphery (Candidate Duplicate)',
        detailedDescription: 'Villagers in Chaibasa rural hamlets complain of red murky iron water from deep tube wells that causes stomach aches and stains clothing.',
        domain: 'Water Resources',
        location: {
          state: 'Jharkhand',
          district: 'West Singhbhum',
          block: 'Chaibasa Sadar',
          villageOrCity: 'Gutuhatu',
          pincode: '833201',
          gpsCoordinates: { latitude: 22.5512, longitude: 85.8112 },
        },
        affectedPopulation: 3400,
        urgency: 'High',
        expectedOutcome: 'Iron removal filters for community tube wells.',
        availableResources: 'Community tubewell structure.',
        contactName: 'Shalini Sinku',
        contactPhone: '+91 94301 99334',
        contactEmail: 'shalini.sinku@mail.com',
        media: [],
        status: 'Under Validation',
        submittedByUserId: 'usr-citizen-01',
        submittedByName: 'Shalini Sinku',
        submittedAt: '2026-02-03T11:30:00Z',
        duplicateCandidates: [],
      },
      {
        id: 'CB-JH-2026-000020',
        title: 'Completed Deployment: Smart Solar Water Micro-Purification in Bero Block',
        detailedDescription: 'Bero block had 2,200 villagers affected by bacteriological contamination and high coliform counts in open wells. A collaborative project between BIT Mesra and Tata Steel CSR deployed 3 solar UV-microfiltration kiosks.',
        domain: 'Water Resources',
        location: {
          state: 'Jharkhand',
          district: 'Ranchi',
          block: 'Bero',
          villageOrCity: 'Bero Central & Karkatta',
          pincode: '835202',
          gpsCoordinates: { latitude: 23.2912, longitude: 85.0412 },
        },
        affectedPopulation: 2200,
        urgency: 'High',
        expectedOutcome: 'Zero coliform water delivered to 480 households with smart RFID card metering.',
        availableResources: 'Community center, village water committee.',
        contactName: 'Sita Devi',
        contactPhone: '+91 94311 55443',
        contactEmail: 'sita.devi@bero-panchayat.org',
        media: [],
        status: 'Completed',
        submittedByUserId: 'usr-citizen-01',
        submittedByName: 'Sita Devi',
        submittedAt: '2025-08-10T10:00:00Z',
        validatedBy: 'Dr. Rajeshwar Sharma, IAS',
        validatedAt: '2025-08-15T11:00:00Z',
        assignedUniversityId: 'uni-bit-mesra',
        assignedUniversityName: 'BIT Mesra',
        assignedAt: '2025-08-20T10:00:00Z',
        activeProjectId: 'PRJ-JH-2025-099',
        duplicateCandidates: [],
      },
    ];

    // Compute AI Analysis for each seeded challenge so all fields exist
    for (const c of challenges) {
      const analysis = aiService.calculatePriority({
        affectedPopulation: c.affectedPopulation,
        urgency: c.urgency,
        title: c.title,
        description: c.detailedDescription,
        domain: c.domain,
      });

      const classification = aiService.classifyDomain(c.title, c.detailedDescription, c.domain);
      const recommendedUnis = aiService.matchUniversities(c.domain, classification.skills, c.location.district, universities);

      const topDup = c.duplicateCandidates[0];

      c.aiAnalysis = {
        domain: c.domain,
        subDomain: classification.subDomain,
        priorityScore: analysis.priorityScore,
        priorityLevel: analysis.priorityLevel,
        urgency: analysis.urgency,
        priorityReasoning: analysis.reasoning,
        duplicateProbability: topDup ? topDup.similarityScore : 8,
        possibleDuplicateId: topDup?.existingChallengeId,
        duplicateTitle: topDup?.existingTitle,
        recommendedUniversities: recommendedUnis,
        requiredSkills: classification.skills,
        suggestedSDG: classification.sdg,
        suggestedProjectType: classification.projectType,
        confidenceScore: classification.confidence,
        analyzedAt: c.submittedAt,
        modelEngine: 'Deterministic Rule & NLP Vector Space',
      };
    }

    // Projects: 4 Active Projects showing the entire 12-stage lifecycle
    const projects: Project[] = [
      {
        id: 'PRJ-JH-2026-001',
        challengeId: 'CB-JH-2026-000001',
        challengeTitle: 'Unreliable Drinking Water Supply and Groundwater Fluoride Contamination in Angara Block',
        title: 'Smart Rural Water IoT Telemetry & Solar Defluoridation System (Angara Pilot)',
        domain: 'Water Resources',
        district: 'Ranchi',
        stage: 'Testing',
        currentMilestoneIndex: 6,
        overallProgress: 68,
        universityId: 'uni-bit-mesra',
        universityName: 'Birla Institute of Technology (BIT) Mesra',
        leadFaculty: faculty[0], // Dr. Sudip Das
        studentTeam: [students[0], students[1], students[3]], // Civil, CS/IoT, Agri
        industryPartners: [
          {
            id: 'pld-01',
            industryId: 'ind-jaltech',
            companyName: 'JalTech Solutions Pvt Ltd',
            challengeId: 'CB-JH-2026-000001',
            projectId: 'PRJ-JH-2026-001',
            offeredSupport: ['Mentorship', 'Equipment', 'Technical Support', 'Prototype Sponsorship'],
            financialPledgeAmountInRupees: 350000,
            equipmentDetails: '3x Industrial Grade Ultrasonic Depth Probes + NB-IoT Telemetry Gateways',
            mentorNominated: 'Neha Soren (Founder, JalTech)',
            status: 'Active',
            createdAt: '2026-01-20T10:00:00Z',
          },
          {
            id: 'pld-02',
            industryId: 'ind-tata-steel',
            companyName: 'Tata Steel Rural Development Society (TSRDS)',
            challengeId: 'CB-JH-2026-000001',
            projectId: 'PRJ-JH-2026-001',
            offeredSupport: ['Funding', 'Deployment Support', 'Pilot Hosting'],
            financialPledgeAmountInRupees: 850000,
            equipmentDetails: 'Skid mounted solar filtration frame and battery enclosure',
            mentorNominated: 'Vikramaditya Singhania',
            status: 'Active',
            createdAt: '2026-01-22T14:00:00Z',
          },
        ],
        governmentDepartment: 'Department of Higher & Technical Education & Drinking Water & Sanitation Dept (DWSD)',
        budgetInRupees: 1450000,
        timelineStartDate: '2026-01-20',
        targetCompletionDate: '2026-05-30',
        proposal: {
          id: 'prop-001',
          projectId: 'PRJ-JH-2026-001',
          submittedByUniversityId: 'uni-bit-mesra',
          problemUnderstanding: 'Angara block has chronic fluoride levels exceeding 3.8 mg/L due to granite gneiss bedrocks. Villagers have high dental and skeletal fluorosis incidence. The existing Jal Jeevan Mission overhead tanks lack real-time water quality feedback and solar pumps frequently run dry without automatic cutoff.',
          proposedSolution: 'A twin-column Activated Alumina and bone-char defluoridation skid retrofitted with an ESP32 microcontroller, solar-charged LiFePO4 battery, fluoride ion-selective electrode, and ultrasonic level sensor. Real-time telemetry is pushed via 4G/GSM to a cloud portal and an SMS siren warns the Mukhiya and village jal sahiyas if fluoride exceeds 1.5 mg/L.',
          innovationHighlights: [
            'Locally sourced regenerative activated alumina adsorbent lowering replacement costs by 70%',
            'Zero-grid solar operation with battery backup during monsoons',
            'Automated valve cutoff when turbidity or fluoride spikes above safe limits',
            'Two-way vernacular Hindi/Mundari SMS notifications to Panchayat heads'
          ],
          technologyStack: [
            'ESP32 Low-Power MCU',
            'LoRaWAN / GSM Cellular Uplink',
            'Activated Alumina Filter Beds',
            'Solar MPPT Battery Charger',
            'React / Node.js Monitoring Dashboard'
          ],
          implementationPlan: 'Phase 1: Lab water testing and bed kinetics. Phase 2: Microcontroller firmware and cloud telemetry bench test. Phase 3: Hardware fabrication at BIT FabLab. Phase 4: Field installation at Angara Nawagarh overhead tank. Phase 5: 60-day trial with village jal sahiyas.',
          estimatedBudgetInRupees: 1450000,
          timelineMonths: 4,
          expectedSocialImpact: '3,200 villagers provided with daily safe drinking water below 1.0 mg/L fluoride, reducing water-borne pediatric morbidity by over 80%.',
          scalabilityPlan: 'Template can be replicated across 140 fluoride-endemic villages across Ranchi, Palamu and Garhwa districts under State Jal Jeevan convergence.',
          risksAndMitigation: 'Filter clogging from raw silt mitigated by incorporating a cleanable quartz sand pre-filter.',
          sustainabilityStrategy: 'Village water committee (Jal Samiti) collects ₹30/month per household to cover alumina regeneration and salt chemicals.',
          status: 'Government Approved',
          submittedAt: '2026-01-22T10:00:00Z',
          reviewedAt: '2026-01-24T12:00:00Z',
          reviewRemarks: 'Excellent technical and social design. Approved with joint grant from Technical Education Innovation Fund and Tata Steel CSR.',
        },
        milestones: [
          {
            id: 'ms-01',
            title: 'Water Chemistry Profiling & Filter Media Kinetics',
            description: 'Sample water from 10 Angara borewells and establish break-through curves for activated alumina in BIT Environmental Lab.',
            owner: 'Dr. Sudip Das & Kunal Kumar',
            startDate: '2026-01-20',
            dueDate: '2026-02-05',
            status: 'Completed',
            progressPercent: 100,
            evidenceNotes: 'Lab report shows 96.2% fluoride absorption down to 0.6 mg/L.',
            completedAt: '2026-02-04T18:00:00Z',
          },
          {
            id: 'ms-02',
            title: 'IoT Sensor Telemetry Hardware & Firmware Prototyping',
            description: 'Design ESP32 sensor board with ultrasonic depth measurement and GSM module with solar power regulation.',
            owner: 'Ananya Verma (Student Lead) & Neha Soren (Industry Mentor)',
            startDate: '2026-02-01',
            dueDate: '2026-02-18',
            status: 'Completed',
            progressPercent: 100,
            evidenceNotes: 'Firmware bench-tested with 99.8% GSM packet delivery over 72 hours.',
            completedAt: '2026-02-17T17:00:00Z',
          },
          {
            id: 'ms-03',
            title: 'Mechanical Skid Fabrication & Solar Enclosure Assembly',
            description: 'Fabricate weather-proof stainless-steel filtration skid and solar panel mount at BIT Mesra FabLab.',
            owner: 'BIT Mesra Workshop & TSRDS Engineering',
            startDate: '2026-02-15',
            dueDate: '2026-02-28',
            status: 'Completed',
            progressPercent: 100,
            evidenceNotes: 'Skid delivered and pressure tested up to 4.5 bar.',
            completedAt: '2026-02-27T16:00:00Z',
          },
          {
            id: 'ms-04',
            title: 'Field Installation at Angara Nawagarh Community Tank',
            description: 'Integrate the filtration skid and solar electronics with the 10,000L Gram Panchayat overhead tank.',
            owner: 'Multidisciplinary Team & Angara Mukhiya',
            startDate: '2026-03-01',
            dueDate: '2026-03-15',
            status: 'In Progress',
            progressPercent: 80,
            evidenceNotes: 'Piping and solar arrays installed. Awaiting final flow-meter calibration.',
          },
          {
            id: 'ms-05',
            title: 'Community Training & Jal Sahiya Water Testing Handover',
            description: 'Train 12 women SHG members in checking filter backwash and reading SMS alerts in Hindi.',
            owner: 'Pooja Soren & Sunita Munda',
            startDate: '2026-03-16',
            dueDate: '2026-03-30',
            status: 'Not Started',
            progressPercent: 0,
          },
          {
            id: 'ms-06',
            title: '60-Day Field Pilot & Quantified Impact Measurement',
            description: 'Collect continuous water health metrics and verify household benefit and cost savings.',
            owner: 'Joint Academic-Industry Evaluation Panel',
            startDate: '2026-04-01',
            dueDate: '2026-05-30',
            status: 'Not Started',
            progressPercent: 0,
          },
        ],
        createdAt: '2026-01-20T10:00:00Z',
        updatedAt: '2026-03-02T11:00:00Z',
      },
      {
        id: 'PRJ-JH-2026-002',
        challengeId: 'CB-JH-2026-000003',
        challengeTitle: 'Post-Harvest Lac and Tussar Cocoon Moisture Spoilage in Khunti Tribal Clusters',
        title: 'Solar Desiccant Chamber & Vernacular Value-Addition Mobile Hub for Lac & Tussar Cultivators',
        domain: 'Rural Livelihoods',
        district: 'Khunti',
        stage: 'Prototype',
        currentMilestoneIndex: 3,
        overallProgress: 45,
        universityId: 'uni-birsa-agri',
        universityName: 'Birsa Agricultural University (BAU)',
        leadFaculty: faculty[4], // Dr. Ramesh Chandra Jha
        studentTeam: [students[3]],
        industryPartners: [
          {
            id: 'pld-03',
            industryId: 'ind-ushamartin',
            companyName: 'Usha Martin Foundation',
            challengeId: 'CB-JH-2026-000003',
            projectId: 'PRJ-JH-2026-002',
            offeredSupport: ['Funding', 'Mentorship', 'Deployment Support'],
            financialPledgeAmountInRupees: 600000,
            status: 'Active',
            createdAt: '2026-01-22T11:00:00Z',
          },
        ],
        governmentDepartment: 'Dept of Higher & Technical Education & Dept of Industries, GoJ',
        budgetInRupees: 980000,
        timelineStartDate: '2026-01-25',
        targetCompletionDate: '2026-06-30',
        milestones: [
          {
            id: 'ms-201',
            title: 'Tribal Lac Moisture Sorption & Fungal Kinetics Study',
            description: 'Evaluate temperature and relative humidity thresholds for kusmi and rangeeni lac strains.',
            owner: 'Dr. Ramesh Chandra Jha (BAU)',
            startDate: '2026-01-25',
            dueDate: '2026-02-15',
            status: 'Completed',
            progressPercent: 100,
            completedAt: '2026-02-14T15:00:00Z',
          },
          {
            id: 'ms-202',
            title: 'Solar PCM Desiccant Dryer Engineering',
            description: 'Build phase-change material heat sink chamber maintaining 38°C and <12% relative humidity.',
            owner: 'BAU Agricultural Engineering Workshop',
            startDate: '2026-02-16',
            dueDate: '2026-03-10',
            status: 'In Progress',
            progressPercent: 75,
          },
          {
            id: 'ms-203',
            title: 'Vernacular Fair-Price Mobile Aggregator App',
            description: 'Develop offline Mundari/Hindi voice app for SHG cocoon weighing and fair market price indexing.',
            owner: 'IIIT Ranchi Software Incubator',
            startDate: '2026-03-01',
            dueDate: '2026-03-31',
            status: 'Not Started',
            progressPercent: 0,
          },
        ],
        createdAt: '2026-01-25T11:00:00Z',
        updatedAt: '2026-02-28T09:00:00Z',
      },
      {
        id: 'PRJ-JH-2026-003',
        challengeId: 'CB-JH-2026-000010',
        challengeTitle: 'Paddy Crop Stem Borer Infestation and Severe Yield Drop in Dumka Santhal Parganas',
        title: 'Solar Automated Pheromone Trap & AI Crop Pest Diagnostic App (Dumka)',
        domain: 'Agriculture',
        district: 'Dumka',
        stage: 'Team Formation',
        currentMilestoneIndex: 1,
        overallProgress: 20,
        universityId: 'uni-birsa-agri',
        universityName: 'Birsa Agricultural University (BAU)',
        leadFaculty: faculty[4],
        studentTeam: [students[3]],
        industryPartners: [],
        governmentDepartment: 'Dept of Agriculture, Animal Husbandry & Co-operative, GoJ',
        budgetInRupees: 650000,
        timelineStartDate: '2026-02-01',
        targetCompletionDate: '2026-07-15',
        milestones: [
          {
            id: 'ms-301',
            title: 'Pheromone Formulation & Field Pest Trapping Trial',
            description: 'Deploy 40 prototype solar light traps across Ranishwar paddy fields.',
            owner: 'BAU Entomology Wing',
            startDate: '2026-02-01',
            dueDate: '2026-02-28',
            status: 'Completed',
            progressPercent: 100,
            completedAt: '2026-02-26T14:00:00Z',
          },
          {
            id: 'ms-302',
            title: 'Mobile Leaf Photo AI Pest Detector',
            description: 'Train edge computer vision model on rice leaf borer damage.',
            owner: 'Student Team',
            startDate: '2026-03-01',
            dueDate: '2026-03-25',
            status: 'In Progress',
            progressPercent: 25,
          },
        ],
        createdAt: '2026-02-01T10:00:00Z',
        updatedAt: '2026-02-26T14:00:00Z',
      },
      {
        id: 'PRJ-JH-2025-099',
        challengeId: 'CB-JH-2026-000020',
        challengeTitle: 'Completed Deployment: Smart Solar Water Micro-Purification in Bero Block',
        title: 'Bero Solar UV-Microfiltration Kiosk Network & Sustainable Community Water Hub',
        domain: 'Water Resources',
        district: 'Ranchi',
        stage: 'Completed',
        currentMilestoneIndex: 6,
        overallProgress: 100,
        universityId: 'uni-bit-mesra',
        universityName: 'BIT Mesra',
        leadFaculty: faculty[0],
        studentTeam: [students[0], students[1]],
        industryPartners: [
          {
            id: 'pld-99',
            industryId: 'ind-tata-steel',
            companyName: 'Tata Steel Rural Development Society (TSRDS)',
            challengeId: 'CB-JH-2026-000020',
            projectId: 'PRJ-JH-2025-099',
            offeredSupport: ['Funding', 'Equipment', 'Deployment Support'],
            financialPledgeAmountInRupees: 1200000,
            status: 'Delivered',
            createdAt: '2025-08-25T10:00:00Z',
          },
        ],
        governmentDepartment: 'Drinking Water & Sanitation Dept, GoJ',
        budgetInRupees: 1800000,
        timelineStartDate: '2025-08-20',
        targetCompletionDate: '2025-12-15',
        milestones: [
          {
            id: 'ms-901',
            title: 'Project Inception & Water Sampling',
            description: 'Lab testing and community water mapping in Bero.',
            owner: 'BIT Mesra',
            startDate: '2025-08-20',
            dueDate: '2025-09-05',
            status: 'Completed',
            progressPercent: 100,
            completedAt: '2025-09-04T12:00:00Z',
          },
          {
            id: 'ms-902',
            title: 'Kiosk Fabrication & Solar UV Skid',
            description: 'Manufacturing 3x 500LPH solar water kiosks.',
            owner: 'TSRDS & BIT Mesra',
            startDate: '2025-09-06',
            dueDate: '2025-10-15',
            status: 'Completed',
            progressPercent: 100,
            completedAt: '2025-10-14T15:00:00Z',
          },
          {
            id: 'ms-903',
            title: 'Full Deployment, Handover & Impact Audit',
            description: 'Handover to Bero Gram Panchayat with verified health audit.',
            owner: 'Joint Verification Committee',
            startDate: '2025-10-16',
            dueDate: '2025-12-15',
            status: 'Completed',
            progressPercent: 100,
            completedAt: '2025-12-12T16:00:00Z',
          },
        ],
        impactRecord: {
          id: 'imp-001',
          projectId: 'PRJ-JH-2025-099',
          challengeId: 'CB-JH-2026-000020',
          householdsAffectedBefore: 1200,
          householdsBenefitedAfter: 950,
          percentageImprovement: 79.2,
          villagesCovered: 4,
          costSavedPerAnnumInRupees: 1840000,
          timeSavedMetric: '2.5 hours per day saved per household previously spent walking to distant wells',
          environmentalImpact: 'Zero diesel generator emissions; eliminated 14,000 single-use plastic water bottles/year',
          educationOrHealthImprovement: '87% drop in water-borne diarrheal episodes in children under 10 (verified by PHC Bero records)',
          livelihoodOrIncomeGenerated: 'Women SHG earned ₹42,000/month by operating clean water dispensary and ice packs',
          technologyDeployedSummary: '3x Solar Powered 500LPH Automated UV-Ultrafiltration Kiosks with RFID Card Metering',
          patentsFiledCount: 1,
          researchPapersCount: 2,
          startupsCreatedCount: 1,
          recordedAt: '2025-12-20T10:00:00Z',
          verifiedByGovernmentDepartment: 'Department of Higher & Technical Education & District Health Office, Ranchi',
        },
        createdAt: '2025-08-20T10:00:00Z',
        updatedAt: '2025-12-20T10:00:00Z',
      },
    ];

    // Seed Messages
    const messages: DiscussionMessage[] = [
      {
        id: 'msg-01',
        channelType: 'project',
        targetEntityId: 'PRJ-JH-2026-001',
        senderId: 'usr-faculty-01',
        senderName: 'Dr. Sudip Das',
        senderRole: 'Faculty Mentor',
        content: 'Activated alumina regeneration test results are in: 96.2% fluoride capture efficiency achieved with 1% caustic soda rinse. Ready for skid assembly.',
        timestamp: '2026-02-04T18:30:00Z',
      },
      {
        id: 'msg-02',
        channelType: 'project',
        targetEntityId: 'PRJ-JH-2026-001',
        senderId: 'usr-student-01',
        senderName: 'Ananya Verma',
        senderRole: 'Student',
        content: 'The ESP32 firmware is updated with deep sleep intervals. Battery draw is under 45mA in standby, easily sustained by our 50W solar panel even on cloudy monsoon days.',
        timestamp: '2026-02-17T18:00:00Z',
      },
      {
        id: 'msg-03',
        channelType: 'project',
        targetEntityId: 'PRJ-JH-2026-001',
        senderId: 'usr-startup-01',
        senderName: 'Neha Soren',
        senderRole: 'Startup/MSME',
        content: 'JalTech has dispatched 3 pre-calibrated ultrasonic telemetry nodes to BIT Mesra lab today. We will be on site with the student team for field mounting.',
        timestamp: '2026-02-28T10:00:00Z',
      },
      {
        id: 'msg-04',
        channelType: 'project',
        targetEntityId: 'PRJ-JH-2026-001',
        senderId: 'usr-citizen-01',
        senderName: 'Sunita Munda',
        senderRole: 'Citizen',
        content: 'Johar Sir! The Angara Gram Panchayat has cleaned the water pump shed and the women SHG members are excited for the training session next week.',
        timestamp: '2026-03-01T14:10:00Z',
      },
      {
        id: 'msg-05',
        channelType: 'challenge',
        targetEntityId: 'CB-JH-2026-000001',
        senderId: 'usr-gov-01',
        senderName: 'Dr. Rajeshwar Sharma, IAS',
        senderRole: 'Government Department',
        content: 'This challenge has been prioritized as a Flagship SIH-2026 Smart Education Demonstration Project for the Government of Jharkhand.',
        timestamp: '2026-01-16T11:15:00Z',
      },
    ];

    // Seed Notifications
    const notifications: AppNotification[] = [
      {
        id: 'notif-01',
        title: 'New High Priority Challenge Validated',
        message: 'Challenge CB-JH-2026-000001 (Angara Fluoride Water) validated by Department of Higher & Technical Education.',
        type: 'validation',
        relatedEntityId: 'CB-JH-2026-000001',
        isRead: false,
        createdAt: '2026-01-16T11:05:00Z',
      },
      {
        id: 'notif-02',
        title: 'University Assigned to Challenge',
        message: 'BIT Mesra has accepted challenge CB-JH-2026-000001 and formed a multidisciplinary project team.',
        type: 'university',
        relatedEntityId: 'PRJ-JH-2026-001',
        isRead: false,
        createdAt: '2026-01-18T10:05:00Z',
      },
      {
        id: 'notif-03',
        title: 'Industry CSR Pledge Received',
        message: 'Tata Steel Rural Development Society pledged ₹8.5 Lakhs funding & equipment for Angara Water Project.',
        type: 'industry',
        relatedEntityId: 'PRJ-JH-2026-001',
        isRead: false,
        createdAt: '2026-01-22T14:05:00Z',
      },
      {
        id: 'notif-04',
        title: 'Milestone 3 Completed on Schedule',
        message: 'Mechanical Skid Fabrication & Solar Enclosure Assembly completed and pressure tested at BIT Mesra FabLab.',
        type: 'milestone',
        relatedEntityId: 'PRJ-JH-2026-001',
        isRead: true,
        createdAt: '2026-02-27T16:05:00Z',
      },
    ];

    // Audit Logs
    const auditLogs: AuditLog[] = [
      {
        id: 'aud-01',
        userId: 'usr-citizen-01',
        userName: 'Sunita Munda',
        userRole: 'Citizen',
        action: 'Challenge Submitted',
        entityType: 'Challenge',
        entityId: 'CB-JH-2026-000001',
        newState: 'Submitted',
        reason: 'Citizen reported acute fluoride contamination in Angara block',
        timestamp: '2026-01-14T09:40:00Z',
      },
      {
        id: 'aud-02',
        userId: 'system-ai',
        userName: 'CivicBridge AI Pipeline',
        userRole: 'Platform Administrator',
        action: 'AI Intelligence Analysis Executed',
        entityType: 'AI Analysis',
        entityId: 'CB-JH-2026-000001',
        newState: 'Under Validation',
        reason: 'Domain: Water Resources (94%), Priority: High (88 pts), Urgency: Short-Term',
        timestamp: '2026-01-14T09:42:00Z',
      },
      {
        id: 'aud-03',
        userId: 'usr-gov-01',
        userName: 'Dr. Rajeshwar Sharma, IAS',
        userRole: 'Government Department',
        action: 'Challenge Validated & Dispatched',
        entityType: 'Challenge',
        entityId: 'CB-JH-2026-000001',
        previousState: 'Under Validation',
        newState: 'Validated',
        reason: 'Verified against district water lab records. Priority confirmed.',
        timestamp: '2026-01-16T11:00:00Z',
      },
      {
        id: 'aud-04',
        userId: 'usr-uni-admin-01',
        userName: 'Prof. Alok Kumar Roy',
        userRole: 'University Admin',
        action: 'University Accepted Challenge & Created Project',
        entityType: 'Project',
        entityId: 'PRJ-JH-2026-001',
        newState: 'Team Formation',
        reason: 'Matched expertise in Civil/Environmental and Embedded Systems at BIT Mesra',
        timestamp: '2026-01-18T10:00:00Z',
      },
      {
        id: 'aud-05',
        userId: 'usr-ind-01',
        userName: 'Vikramaditya Singhania',
        userRole: 'Industry Partner',
        action: 'CSR Funding & Mentorship Pledged',
        entityType: 'Industry',
        entityId: 'PRJ-JH-2026-001',
        newState: 'Partner Joined',
        reason: 'Tata Steel TSRDS pledged ₹8.5 Lakhs and field engineering support',
        timestamp: '2026-01-22T14:00:00Z',
      },
      {
        id: 'aud-06',
        userId: 'usr-faculty-01',
        userName: 'Dr. Sudip Das',
        userRole: 'Faculty Mentor',
        action: 'Milestone 1 Completed',
        entityType: 'Milestone',
        entityId: 'ms-01',
        newState: 'Completed',
        reason: 'Adsorption kinetics verified: 96.2% fluoride reduction',
        timestamp: '2026-02-04T18:00:00Z',
      },
    ];

    const generated: DatabaseSchema = {
      users,
      challenges,
      universities,
      faculty,
      students,
      industryPartners,
      industryInterests: [],
      projects,
      proposals: [],
      milestones: [],
      impactRecords: [],
      messages,
      notifications,
      auditLogs,
    };

    return generated;
  }
}

export const db = new DatabaseEngine();
