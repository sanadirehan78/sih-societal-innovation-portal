/**
 * CivicBridge Jharkhand - REST API Controller & Router
 * 
 * Endpoints for Auth, Challenges, AI Analysis, Universities, Industry,
 * Projects, Milestones, Discussions, Notifications, Analytics, and Audit Logs.
 */

import express, { Request, Response } from 'express';
import { db } from './db.js';
import { aiService } from './aiService.js';
import {
  Challenge,
  ChallengeDomain,
  PriorityLevel,
  ChallengeStatus,
  Project,
  ProjectStage,
  ProjectMilestone,
  SolutionProposal,
  ProjectImpact,
  IndustryInterest,
  UserRole,
  DiscussionMessage,
  AppNotification,
} from './types.js';

export const router = express.Router();

// ----------------------------------------------------
// 1. AUTH & PERSONA SWITCHING
// ----------------------------------------------------

let currentSessionUser = db.getUsers().find((u) => u.role === 'Government Department') || db.getUsers()[0];

router.get('/auth/me', (req: Request, res: Response) => {
  res.json({ user: currentSessionUser });
});

router.get('/auth/personas', (req: Request, res: Response) => {
  const users = db.getUsers();
  res.json({ users });
});

router.post('/auth/switch-role', (req: Request, res: Response) => {
  const { role, userId } = req.body;
  let target = db.getUsers().find((u) => u.id === userId);
  if (!target && role) {
    target = db.getUsers().find((u) => u.role === role);
  }
  if (target) {
    currentSessionUser = target;
    return res.json({ success: true, user: target });
  }
  return res.status(404).json({ error: 'User persona not found' });
});

router.post('/auth/register', (req: Request, res: Response) => {
  const { name, email, role, district, organization, phone, bio } = req.body;
  if (!name || !email || !role) {
    return res.status(400).json({ error: 'Name, email and role are required' });
  }

  const existing = db.getUserByEmail(email);
  if (existing) {
    return res.status(409).json({ error: 'Email already registered' });
  }

  const newUser = db.addUser({
    id: `usr-${Date.now()}`,
    name,
    email,
    role: role as UserRole,
    district: district || 'Ranchi',
    organization: organization || 'Civic Participant',
    phone: phone || '',
    bio: bio || '',
    createdAt: new Date().toISOString(),
  });

  currentSessionUser = newUser;

  db.addAuditLog({
    userId: newUser.id,
    userName: newUser.name,
    userRole: newUser.role,
    action: 'User Registered',
    entityType: 'Challenge',
    entityId: newUser.id,
    newState: 'Active',
    reason: `New registration with role ${newUser.role}`,
  });

  res.status(201).json({ success: true, user: newUser });
});

router.post('/auth/login', (req: Request, res: Response) => {
  const { email } = req.body;
  const user = db.getUserByEmail(email);
  if (!user) {
    return res.status(404).json({ error: 'User not found with this email' });
  }
  currentSessionUser = user;
  res.json({ success: true, user });
});

// ----------------------------------------------------
// 2. CHALLENGES API
// ----------------------------------------------------

router.get('/challenges', (req: Request, res: Response) => {
  const { district, domain, priority, status, search, submittedBy } = req.query;
  let list = db.getChallenges();

  if (district && typeof district === 'string' && district !== 'All') {
    list = list.filter((c) => c.location.district.toLowerCase() === district.toLowerCase());
  }
  if (domain && typeof domain === 'string' && domain !== 'All') {
    list = list.filter((c) => c.domain === domain);
  }
  if (priority && typeof priority === 'string' && priority !== 'All') {
    list = list.filter((c) => c.aiAnalysis?.priorityLevel === priority);
  }
  if (status && typeof status === 'string' && status !== 'All') {
    list = list.filter((c) => c.status === status);
  }
  if (submittedBy && typeof submittedBy === 'string') {
    list = list.filter((c) => c.submittedByUserId === submittedBy);
  }
  if (search && typeof search === 'string' && search.trim().length > 0) {
    const q = search.toLowerCase();
    list = list.filter(
      (c) =>
        c.title.toLowerCase().includes(q) ||
        c.detailedDescription.toLowerCase().includes(q) ||
        c.location.district.toLowerCase().includes(q) ||
        c.location.block.toLowerCase().includes(q) ||
        c.id.toLowerCase().includes(q)
    );
  }

  res.json({ challenges: list, total: list.length });
});

router.get('/challenges/:id', (req: Request, res: Response) => {
  const challenge = db.getChallengeById(req.params.id);
  if (!challenge) {
    return res.status(404).json({ error: 'Challenge not found' });
  }
  res.json({ challenge });
});

router.post('/challenges', async (req: Request, res: Response) => {
  try {
    const {
      title,
      detailedDescription,
      domain,
      district,
      block,
      villageOrCity,
      affectedPopulation,
      urgency,
      expectedOutcome,
      availableResources,
      contactName,
      contactPhone,
      contactEmail,
      media,
      gpsCoordinates,
    } = req.body;

    if (!title || !detailedDescription || !district || !block) {
      return res.status(400).json({ error: 'Missing mandatory fields for challenge submission' });
    }

    // Generate unique sequential-style ID
    const count = db.getChallenges().length + 1;
    const challengeId = `CB-JH-2026-${String(count).padStart(6, '0')}`;

    // Execute AI Intelligence Pipeline
    const existing = db.getChallenges();
    const universities = db.getUniversities();

    const analysis = await aiService.analyzeChallenge({
      title,
      description: detailedDescription,
      district,
      affectedPopulation: Number(affectedPopulation) || 100,
      urgency: urgency || 'Medium',
      providedDomain: domain as ChallengeDomain,
      existingChallenges: existing,
      universities,
      currentChallengeId: challengeId,
    });

    const duplicates = aiService.checkDuplicates(
      title,
      detailedDescription,
      district,
      analysis.domain,
      existing,
      challengeId
    );

    const newChallenge: Challenge = {
      id: challengeId,
      title,
      detailedDescription,
      domain: analysis.domain,
      location: {
        state: 'Jharkhand',
        district: district || 'Ranchi',
        block: block || 'Sadar',
        villageOrCity: villageOrCity || 'Local Ward/Village',
        gpsCoordinates: gpsCoordinates || { latitude: 23.3441, longitude: 85.3096 },
      },
      affectedPopulation: Number(affectedPopulation) || 250,
      urgency: urgency || 'Medium',
      expectedOutcome: expectedOutcome || 'Effective collaborative technological solution',
      availableResources: availableResources || 'Community participation and local site access',
      contactName: contactName || currentSessionUser.name,
      contactPhone: contactPhone || currentSessionUser.phone || '',
      contactEmail: contactEmail || currentSessionUser.email,
      media: Array.isArray(media) ? media : [],
      status: 'Under Validation',
      submittedByUserId: currentSessionUser.id,
      submittedByName: currentSessionUser.name,
      submittedAt: new Date().toISOString(),
      aiAnalysis: analysis,
      duplicateCandidates: duplicates.duplicateCandidates,
    };

    db.addChallenge(newChallenge);

    // Audit log
    db.addAuditLog({
      userId: currentSessionUser.id,
      userName: currentSessionUser.name,
      userRole: currentSessionUser.role,
      action: 'Challenge Submitted',
      entityType: 'Challenge',
      entityId: challengeId,
      newState: 'Under Validation',
      reason: `Citizen submitted problem. AI assigned domain '${analysis.domain}', priority '${analysis.priorityLevel}' (${analysis.priorityScore} pts)`,
    });

    // Broadcast notification to Government Department
    db.addNotification({
      id: `notif-${Date.now()}`,
      targetRole: 'Government Department',
      title: `New Challenge: ${title.slice(0, 50)}...`,
      message: `Submitted from ${district} (${analysis.domain}). Priority calculated: ${analysis.priorityLevel} (${analysis.priorityScore} pts). Validation required.`,
      type: 'challenge',
      relatedEntityId: challengeId,
      isRead: false,
      createdAt: new Date().toISOString(),
    });

    res.status(201).json({ success: true, challenge: newChallenge });
  } catch (err: any) {
    console.error('Error submitting challenge:', err);
    res.status(500).json({ error: 'Failed to process challenge submission', details: err.message });
  }
});

router.post('/challenges/:id/validate', (req: Request, res: Response) => {
  const { decision, overrideDomain, overridePriority, notes, assignedUniversityId } = req.body;
  const challenge = db.getChallengeById(req.params.id);
  if (!challenge) {
    return res.status(404).json({ error: 'Challenge not found' });
  }

  let newStatus: ChallengeStatus = 'Validated';
  if (decision === 'reject') newStatus = 'Rejected';
  if (decision === 'needs_info') newStatus = 'Needs Clarification';
  if (decision === 'assigned' || assignedUniversityId) newStatus = 'Assigned';

  const updates: Partial<Challenge> = {
    status: newStatus,
    validatedBy: currentSessionUser.name,
    validatedAt: new Date().toISOString(),
    validationNotes: notes || 'Validated by Department of Higher & Technical Education, GoJ',
  };

  if (overrideDomain && challenge.aiAnalysis) {
    updates.domain = overrideDomain;
    updates.humanOverrides = {
      originalDomain: challenge.domain,
      originalPriority: challenge.aiAnalysis.priorityLevel,
      overrideReason: notes || 'Administrative override based on department purview',
      overriddenBy: currentSessionUser.name,
      overriddenAt: new Date().toISOString(),
    };
    challenge.aiAnalysis.domain = overrideDomain;
  }

  if (overridePriority && challenge.aiAnalysis) {
    challenge.aiAnalysis.priorityLevel = overridePriority;
    updates.humanOverrides = {
      ...challenge.humanOverrides,
      originalPriority: challenge.aiAnalysis.priorityLevel,
      overrideReason: notes || 'Administrative priority calibration',
      overriddenBy: currentSessionUser.name,
      overriddenAt: new Date().toISOString(),
    };
  }

  if (assignedUniversityId) {
    const uni = db.getUniversityById(assignedUniversityId);
    if (uni) {
      updates.assignedUniversityId = uni.id;
      updates.assignedUniversityName = uni.name;
      updates.assignedAt = new Date().toISOString();
      updates.status = 'Assigned';

      // Notify University Admin
      db.addNotification({
        id: `notif-${Date.now()}`,
        targetRole: 'University Admin',
        title: `Challenge Assigned: ${challenge.title.slice(0, 45)}...`,
        message: `Government has assigned this problem to ${uni.shortName}. Review problem and form a multidisciplinary project team.`,
        type: 'university',
        relatedEntityId: challenge.id,
        isRead: false,
        createdAt: new Date().toISOString(),
      });
    }
  }

  const updated = db.updateChallenge(req.params.id, updates);

  db.addAuditLog({
    userId: currentSessionUser.id,
    userName: currentSessionUser.name,
    userRole: currentSessionUser.role,
    action: `Challenge ${decision ? decision.toUpperCase() : 'VALIDATED'}`,
    entityType: 'Challenge',
    entityId: challenge.id,
    previousState: challenge.status,
    newState: newStatus,
    reason: notes || `Government official decision: ${decision}`,
  });

  res.json({ success: true, challenge: updated });
});

router.post('/challenges/:id/merge', (req: Request, res: Response) => {
  const { canonicalChallengeId, reason } = req.body;
  const duplicate = db.getChallengeById(req.params.id);
  const canonical = db.getChallengeById(canonicalChallengeId);

  if (!duplicate || !canonical) {
    return res.status(404).json({ error: 'Target or canonical challenge not found' });
  }

  db.updateChallenge(duplicate.id, {
    isMerged: true,
    mergedIntoId: canonical.id,
    status: 'Needs Clarification',
  });

  db.addAuditLog({
    userId: currentSessionUser.id,
    userName: currentSessionUser.name,
    userRole: currentSessionUser.role,
    action: 'Duplicate Merged',
    entityType: 'Challenge',
    entityId: duplicate.id,
    previousState: duplicate.status,
    newState: `Merged into ${canonical.id}`,
    reason: reason || 'Identified as duplicate civic challenge during administrative review',
  });

  res.json({ success: true, message: `Challenge ${duplicate.id} merged into ${canonical.id}` });
});

// ----------------------------------------------------
// 3. UNIVERSITIES & FACULTY / STUDENTS
// ----------------------------------------------------

router.get('/universities', (req: Request, res: Response) => {
  res.json({ universities: db.getUniversities() });
});

router.get('/universities/:id', (req: Request, res: Response) => {
  const uni = db.getUniversityById(req.params.id);
  if (!uni) return res.status(404).json({ error: 'University not found' });
  res.json({ university: uni });
});

router.get('/faculty', (req: Request, res: Response) => {
  res.json({ faculty: db.getFaculty() });
});

router.get('/students', (req: Request, res: Response) => {
  res.json({ students: db.getStudents() });
});

// ----------------------------------------------------
// 4. INDUSTRY & CSR
// ----------------------------------------------------

router.get('/industry', (req: Request, res: Response) => {
  res.json({ industryPartners: db.getIndustryPartners() });
});

router.post('/industry/pledge', (req: Request, res: Response) => {
  const {
    industryId,
    challengeId,
    projectId,
    offeredSupport,
    financialPledgeAmountInRupees,
    equipmentDetails,
    mentorNominated,
  } = req.body;

  const partner = db.getIndustryPartnerById(industryId);
  const companyName = partner ? partner.companyName : currentSessionUser.organization || currentSessionUser.name;

  const interest: IndustryInterest = {
    id: `pld-${Date.now()}`,
    industryId: industryId || currentSessionUser.id,
    companyName,
    challengeId,
    projectId,
    offeredSupport: offeredSupport || ['Mentorship', 'Technical Support'],
    financialPledgeAmountInRupees: Number(financialPledgeAmountInRupees) || 0,
    equipmentDetails: equipmentDetails || '',
    mentorNominated: mentorNominated || currentSessionUser.name,
    status: 'Active',
    createdAt: new Date().toISOString(),
  };

  db.addIndustryInterest(interest);

  // If connected to a project, push to project's industry partner list
  if (projectId) {
    const proj = db.getProjectById(projectId);
    if (proj) {
      proj.industryPartners.push(interest);
      db.updateProject(projectId, { industryPartners: proj.industryPartners });
    }
  }

  db.addAuditLog({
    userId: currentSessionUser.id,
    userName: currentSessionUser.name,
    userRole: currentSessionUser.role,
    action: 'Industry Partnership Pledge Formed',
    entityType: 'Industry',
    entityId: interest.id,
    newState: 'Active',
    reason: `${companyName} pledged ${interest.offeredSupport.join(', ')} (${interest.financialPledgeAmountInRupees ? '₹' + interest.financialPledgeAmountInRupees.toLocaleString() : 'In-Kind'})`,
  });

  db.addNotification({
    id: `notif-${Date.now()}`,
    targetRole: 'University Admin',
    title: `Industry Partner Joined Project!`,
    message: `${companyName} has pledged support for challenge ${challengeId}.`,
    type: 'industry',
    relatedEntityId: projectId || challengeId,
    isRead: false,
    createdAt: new Date().toISOString(),
  });

  res.status(201).json({ success: true, interest });
});

// ----------------------------------------------------
// 5. PROJECTS & MULTIDISCIPLINARY TEAMS
// ----------------------------------------------------

router.get('/projects', (req: Request, res: Response) => {
  const { stage, district, domain, universityId } = req.query;
  let list = db.getProjects();

  if (stage && typeof stage === 'string' && stage !== 'All') {
    list = list.filter((p) => p.stage === stage);
  }
  if (district && typeof district === 'string' && district !== 'All') {
    list = list.filter((p) => p.district.toLowerCase() === district.toLowerCase());
  }
  if (domain && typeof domain === 'string' && domain !== 'All') {
    list = list.filter((p) => p.domain === domain);
  }
  if (universityId && typeof universityId === 'string') {
    list = list.filter((p) => p.universityId === universityId);
  }

  res.json({ projects: list, total: list.length });
});

router.get('/projects/:id', (req: Request, res: Response) => {
  const project = db.getProjectById(req.params.id);
  if (!project) return res.status(404).json({ error: 'Project not found' });
  res.json({ project });
});

router.post('/projects', (req: Request, res: Response) => {
  const {
    challengeId,
    title,
    universityId,
    leadFacultyId,
    studentIds,
    budgetInRupees,
    timelineStartDate,
    targetCompletionDate,
  } = req.body;

  const challenge = db.getChallengeById(challengeId);
  if (!challenge) {
    return res.status(404).json({ error: 'Associated challenge not found' });
  }

  const uni = db.getUniversityById(universityId) || db.getUniversities()[0];
  const allFaculty = db.getFaculty();
  const allStudents = db.getStudents();

  const facultyLead = allFaculty.find((f) => f.id === leadFacultyId) || allFaculty[0];
  const teamStudents = allStudents.filter((s) => Array.isArray(studentIds) && studentIds.includes(s.id));
  const finalStudents = teamStudents.length > 0 ? teamStudents : [allStudents[0], allStudents[1]];

  const projectId = `PRJ-JH-2026-${String(db.getProjects().length + 1).padStart(3, '0')}`;

  const defaultMilestones: ProjectMilestone[] = [
    {
      id: `ms-${Date.now()}-1`,
      title: 'Problem Ground Validation & Field Feasibility Study',
      description: 'Site inspection, baseline community surveys, and engineering constraints analysis.',
      owner: facultyLead.name,
      startDate: timelineStartDate || new Date().toISOString().split('T')[0],
      dueDate: '2026-03-15',
      status: 'In Progress',
      progressPercent: 30,
    },
    {
      id: `ms-${Date.now()}-2`,
      title: 'Multidisciplinary System Architecture & Prototyping',
      description: 'Hardware circuit simulation, CAD structure design, and software telemetry layout.',
      owner: finalStudents[0]?.name || 'Student Engineering Team',
      startDate: '2026-03-16',
      dueDate: '2026-04-10',
      status: 'Not Started',
      progressPercent: 0,
    },
    {
      id: `ms-${Date.now()}-3`,
      title: 'Fabrication, Lab Testing & Industry Mentorship Review',
      description: 'Assembly at university fablab and testing with industry sponsor.',
      owner: 'Joint Academic-Industry Panel',
      startDate: '2026-04-11',
      dueDate: '2026-05-05',
      status: 'Not Started',
      progressPercent: 0,
    },
    {
      id: `ms-${Date.now()}-4`,
      title: 'On-Site Field Pilot & Citizen Feedback Recording',
      description: 'Live field deployment at Gram Panchayat site with telemetry tracking.',
      owner: 'Panchayat & Field Team',
      startDate: '2026-05-06',
      dueDate: '2026-05-30',
      status: 'Not Started',
      progressPercent: 0,
    },
  ];

  const newProject: Project = {
    id: projectId,
    challengeId: challenge.id,
    challengeTitle: challenge.title,
    title: title || `Collaborative Innovation: ${challenge.title.slice(0, 60)}`,
    domain: challenge.domain,
    district: challenge.location.district,
    stage: 'Team Formation',
    currentMilestoneIndex: 0,
    overallProgress: 15,
    universityId: uni.id,
    universityName: uni.name,
    leadFaculty: facultyLead,
    studentTeam: finalStudents,
    industryPartners: [],
    governmentDepartment: 'Department of Higher & Technical Education, GoJ',
    budgetInRupees: Number(budgetInRupees) || 750000,
    timelineStartDate: timelineStartDate || new Date().toISOString().split('T')[0],
    targetCompletionDate: targetCompletionDate || '2026-06-30',
    milestones: defaultMilestones,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };

  db.addProject(newProject);
  db.updateChallenge(challenge.id, {
    status: 'Project Started',
    activeProjectId: projectId,
    assignedUniversityId: uni.id,
    assignedUniversityName: uni.name,
  });

  db.addAuditLog({
    userId: currentSessionUser.id,
    userName: currentSessionUser.name,
    userRole: currentSessionUser.role,
    action: 'Project Created from Challenge',
    entityType: 'Project',
    entityId: projectId,
    newState: 'Team Formation',
    reason: `Multidisciplinary project created by ${uni.name} for challenge ${challenge.id}`,
  });

  res.status(201).json({ success: true, project: newProject });
});

router.post('/projects/:id/proposal', (req: Request, res: Response) => {
  const {
    problemUnderstanding,
    proposedSolution,
    innovationHighlights,
    technologyStack,
    implementationPlan,
    estimatedBudgetInRupees,
    timelineMonths,
    expectedSocialImpact,
    scalabilityPlan,
    risksAndMitigation,
    sustainabilityStrategy,
  } = req.body;

  const project = db.getProjectById(req.params.id);
  if (!project) return res.status(404).json({ error: 'Project not found' });

  const proposal: SolutionProposal = {
    id: `prop-${Date.now()}`,
    projectId: project.id,
    submittedByUniversityId: project.universityId,
    problemUnderstanding: problemUnderstanding || 'Detailed root-cause analysis based on field investigation.',
    proposedSolution: proposedSolution || 'Integrated engineering and community co-management design.',
    innovationHighlights: Array.isArray(innovationHighlights) ? innovationHighlights : ['Indigenous low-cost design', 'Zero-grid solar operation'],
    technologyStack: Array.isArray(technologyStack) ? technologyStack : ['IoT Hardware', 'Embedded Sensors', 'Cloud Telemetry'],
    implementationPlan: implementationPlan || 'Phased pilot deployment over 4 calendar months.',
    estimatedBudgetInRupees: Number(estimatedBudgetInRupees) || project.budgetInRupees,
    timelineMonths: Number(timelineMonths) || 4,
    expectedSocialImpact: expectedSocialImpact || 'Substantial improvement in community welfare and public resource efficiency.',
    scalabilityPlan: scalabilityPlan || 'Can be extended across all matching blocks in the district.',
    risksAndMitigation: risksAndMitigation || 'Seasonal weather constraints mitigated through precast modular components.',
    sustainabilityStrategy: sustainabilityStrategy || 'Handover to Gram Panchayat with recurring SHG user fee model.',
    status: 'Submitted',
    submittedAt: new Date().toISOString(),
  };

  project.proposal = proposal;
  project.stage = 'Proposal';
  db.updateProject(project.id, { proposal, stage: 'Proposal' });

  db.addNotification({
    id: `notif-${Date.now()}`,
    targetRole: 'Government Department',
    title: `Solution Proposal Submitted for ${project.id}`,
    message: `${project.universityName} submitted their solution proposal for administrative approval.`,
    type: 'proposal',
    relatedEntityId: project.id,
    isRead: false,
    createdAt: new Date().toISOString(),
  });

  db.addAuditLog({
    userId: currentSessionUser.id,
    userName: currentSessionUser.name,
    userRole: currentSessionUser.role,
    action: 'Proposal Submitted',
    entityType: 'Proposal',
    entityId: proposal.id,
    newState: 'Submitted',
    reason: 'University submitted formal solution proposal for state appraisal',
  });

  res.json({ success: true, proposal });
});

router.post('/projects/:id/proposal/review', (req: Request, res: Response) => {
  const { decision, remarks } = req.body;
  const project = db.getProjectById(req.params.id);
  if (!project || !project.proposal) {
    return res.status(404).json({ error: 'Project or proposal not found' });
  }

  const isApproved = decision === 'approve';
  project.proposal.status = isApproved ? 'Government Approved' : 'Revision Requested';
  project.proposal.reviewedAt = new Date().toISOString();
  project.proposal.reviewRemarks = remarks || (isApproved ? 'Approved by Technical Review Committee' : 'Revision requested');

  if (isApproved) {
    project.stage = 'Prototype';
  }

  db.updateProject(project.id, {
    proposal: project.proposal,
    stage: project.stage,
  });

  db.addAuditLog({
    userId: currentSessionUser.id,
    userName: currentSessionUser.name,
    userRole: currentSessionUser.role,
    action: isApproved ? 'Proposal Approved' : 'Proposal Revision Requested',
    entityType: 'Proposal',
    entityId: project.proposal.id,
    newState: project.proposal.status,
    reason: remarks || 'Government review completed',
  });

  res.json({ success: true, proposal: project.proposal });
});

router.put('/projects/:id/milestones/:mId', (req: Request, res: Response) => {
  const { status, progressPercent, evidenceNotes } = req.body;
  const project = db.getProjectById(req.params.id);
  if (!project) return res.status(404).json({ error: 'Project not found' });

  const milestone = project.milestones.find((m) => m.id === req.params.mId);
  if (!milestone) return res.status(404).json({ error: 'Milestone not found' });

  if (status) milestone.status = status;
  if (typeof progressPercent === 'number') milestone.progressPercent = progressPercent;
  if (evidenceNotes) milestone.evidenceNotes = evidenceNotes;
  if (status === 'Completed' && !milestone.completedAt) {
    milestone.completedAt = new Date().toISOString();
    milestone.progressPercent = 100;
  }

  // Recalculate overall progress
  const totalPercent = project.milestones.reduce((acc, m) => acc + m.progressPercent, 0);
  project.overallProgress = Math.round(totalPercent / project.milestones.length);

  // Advance stage if milestone done
  if (project.overallProgress >= 90) {
    project.stage = 'Impact Measurement';
  } else if (project.overallProgress >= 70) {
    project.stage = 'Pilot';
  } else if (project.overallProgress >= 50) {
    project.stage = 'Testing';
  } else if (project.overallProgress >= 30) {
    project.stage = 'Prototype';
  }

  db.updateProject(project.id, {
    milestones: project.milestones,
    overallProgress: project.overallProgress,
    stage: project.stage,
    updatedAt: new Date().toISOString(),
  });

  db.addAuditLog({
    userId: currentSessionUser.id,
    userName: currentSessionUser.name,
    userRole: currentSessionUser.role,
    action: `Milestone Updated: ${milestone.title.slice(0, 35)}`,
    entityType: 'Milestone',
    entityId: milestone.id,
    newState: `${milestone.status} (${milestone.progressPercent}%)`,
    reason: evidenceNotes || 'Milestone progress update',
  });

  res.json({ success: true, milestone, overallProgress: project.overallProgress, stage: project.stage });
});

router.post('/projects/:id/impact', (req: Request, res: Response) => {
  const {
    householdsAffectedBefore,
    householdsBenefitedAfter,
    villagesCovered,
    costSavedPerAnnumInRupees,
    timeSavedMetric,
    environmentalImpact,
    educationOrHealthImprovement,
    livelihoodOrIncomeGenerated,
    technologyDeployedSummary,
    patentsFiledCount,
    researchPapersCount,
    startupsCreatedCount,
  } = req.body;

  const project = db.getProjectById(req.params.id);
  if (!project) return res.status(404).json({ error: 'Project not found' });

  const before = Number(householdsAffectedBefore) || 1000;
  const after = Number(householdsBenefitedAfter) || 800;
  const pct = Math.min(100, Math.round((after / before) * 100 * 10) / 10);

  const impact: ProjectImpact = {
    id: `imp-${Date.now()}`,
    projectId: project.id,
    challengeId: project.challengeId,
    householdsAffectedBefore: before,
    householdsBenefitedAfter: after,
    percentageImprovement: pct,
    villagesCovered: Number(villagesCovered) || 3,
    costSavedPerAnnumInRupees: Number(costSavedPerAnnumInRupees) || 1200000,
    timeSavedMetric: timeSavedMetric || '2 hours daily per family',
    environmentalImpact: environmentalImpact || 'Carbon emission reduction and zero toxic runoff.',
    educationOrHealthImprovement: educationOrHealthImprovement || '80% reduction in local incidence of target ailment/deficiency.',
    livelihoodOrIncomeGenerated: livelihoodOrIncomeGenerated || '₹25,000 monthly income generated for local community operators.',
    technologyDeployedSummary: technologyDeployedSummary || 'Complete hardware-software edge deployment.',
    patentsFiledCount: Number(patentsFiledCount) || 0,
    researchPapersCount: Number(researchPapersCount) || 1,
    startupsCreatedCount: Number(startupsCreatedCount) || 0,
    recordedAt: new Date().toISOString(),
    verifiedByGovernmentDepartment: 'Department of Higher & Technical Education, GoJ',
  };

  project.impactRecord = impact;
  project.stage = 'Completed';
  project.overallProgress = 100;

  db.updateProject(project.id, {
    impactRecord: impact,
    stage: 'Completed',
    overallProgress: 100,
  });

  db.updateChallenge(project.challengeId, {
    status: 'Completed',
  });

  db.addAuditLog({
    userId: currentSessionUser.id,
    userName: currentSessionUser.name,
    userRole: currentSessionUser.role,
    action: 'Impact Recorded & Project Completed',
    entityType: 'Impact',
    entityId: impact.id,
    newState: 'Completed with Verified Impact',
    reason: `Verified ${pct}% social impact improvement across ${impact.villagesCovered} villages.`,
  });

  res.status(201).json({ success: true, impact });
});

// ----------------------------------------------------
// 6. MESSAGES & NOTIFICATIONS
// ----------------------------------------------------

router.get('/messages', (req: Request, res: Response) => {
  const { channelType, targetEntityId } = req.query;
  const messages = db.getMessages(channelType as string, targetEntityId as string);
  res.json({ messages });
});

router.post('/messages', (req: Request, res: Response) => {
  const { channelType, targetEntityId, content } = req.body;
  if (!content || !targetEntityId) {
    return res.status(400).json({ error: 'Content and targetEntityId are required' });
  }

  const msg: DiscussionMessage = {
    id: `msg-${Date.now()}`,
    channelType: channelType || 'project',
    targetEntityId,
    senderId: currentSessionUser.id,
    senderName: currentSessionUser.name,
    senderRole: currentSessionUser.role,
    content,
    timestamp: new Date().toISOString(),
  };

  db.addMessage(msg);
  res.status(201).json({ success: true, message: msg });
});

router.get('/notifications', (req: Request, res: Response) => {
  const notifs = db.getNotifications(currentSessionUser.id, currentSessionUser.role);
  res.json({ notifications: notifs, unreadCount: notifs.filter((n) => !n.isRead).length });
});

router.put('/notifications/:id/read', (req: Request, res: Response) => {
  db.markNotificationRead(req.params.id);
  res.json({ success: true });
});

router.put('/notifications/mark-all-read', (req: Request, res: Response) => {
  db.markAllNotificationsRead(currentSessionUser.id, currentSessionUser.role);
  res.json({ success: true });
});

// ----------------------------------------------------
// 7. ANALYTICS & REPORTS
// ----------------------------------------------------

router.get('/analytics/overview', (req: Request, res: Response) => {
  const challenges = db.getChallenges();
  const projects = db.getProjects();
  const universities = db.getUniversities();
  const industry = db.getIndustryPartners();

  const totalChallenges = challenges.length;
  const validated = challenges.filter((c) => ['Validated', 'Assigned', 'Project Started', 'Completed'].includes(c.status)).length;
  const inProgress = challenges.filter((c) => ['Assigned', 'Project Started', 'Pilot Active'].includes(c.status)).length;
  const completed = challenges.filter((c) => c.status === 'Completed').length;
  const underReview = challenges.filter((c) => ['Submitted', 'Under Validation', 'Under AI Analysis'].includes(c.status)).length;

  const totalAffectedPopulation = challenges.reduce((acc, c) => acc + (c.affectedPopulation || 0), 0);

  // Total funds pledged across industry
  const totalPledged = projects.reduce((acc, p) => {
    const pSum = p.industryPartners.reduce((s, ip) => s + (ip.financialPledgeAmountInRupees || 0), 0);
    return acc + pSum;
  }, 0);

  res.json({
    overview: {
      totalChallenges,
      validated,
      inProgress,
      completed,
      underReview,
      totalAffectedPopulation,
      totalPledgedInRupees: totalPledged,
      activeProjectsCount: projects.length,
      participatingUniversitiesCount: universities.length,
      participatingIndustryCount: industry.length,
    },
  });
});

router.get('/analytics/districts', (req: Request, res: Response) => {
  const JHARKHAND_DISTRICTS = [
    'Ranchi', 'Bokaro', 'Dhanbad', 'Hazaribagh', 'Deoghar', 'Giridih',
    'East Singhbhum', 'Palamu', 'Dumka', 'West Singhbhum', 'Ramgarh',
    'Saraikela Kharsawan', 'Gumla', 'Latehar', 'Lohardaga', 'Simdega',
    'Khunti', 'Jamtara', 'Godda', 'Pakur', 'Sahibganj', 'Chatra',
    'Koderma', 'Garhwa'
  ];

  const challenges = db.getChallenges();
  const projects = db.getProjects();

  const districtStats = JHARKHAND_DISTRICTS.map((district) => {
    const dChallenges = challenges.filter((c) => c.location.district.toLowerCase() === district.toLowerCase());
    const dProjects = projects.filter((p) => p.district.toLowerCase() === district.toLowerCase());
    const highPriority = dChallenges.filter((c) => c.aiAnalysis?.priorityLevel === 'Critical' || c.aiAnalysis?.priorityLevel === 'High').length;
    const completed = dChallenges.filter((c) => c.status === 'Completed').length;

    return {
      district,
      challengesCount: dChallenges.length,
      highPriorityCount: highPriority,
      activeProjectsCount: dProjects.length,
      completedCount: completed,
      affectedPopulation: dChallenges.reduce((sum, c) => sum + (c.affectedPopulation || 0), 0),
    };
  });

  res.json({ districts: districtStats });
});

router.get('/analytics/domains', (req: Request, res: Response) => {
  const challenges = db.getChallenges();
  const domainCounts: Record<string, { total: number; highPriority: number; activeProjects: number }> = {};

  for (const c of challenges) {
    if (!domainCounts[c.domain]) {
      domainCounts[c.domain] = { total: 0, highPriority: 0, activeProjects: 0 };
    }
    domainCounts[c.domain].total += 1;
    if (c.aiAnalysis?.priorityLevel === 'High' || c.aiAnalysis?.priorityLevel === 'Critical') {
      domainCounts[c.domain].highPriority += 1;
    }
    if (c.status === 'Project Started' || c.status === 'Completed') {
      domainCounts[c.domain].activeProjects += 1;
    }
  }

  const breakdown = Object.entries(domainCounts).map(([domain, data]) => ({
    domain,
    ...data,
  }));

  res.json({ domains: breakdown });
});

router.get('/analytics/impact', (req: Request, res: Response) => {
  const projects = db.getProjects();
  const completedWithImpact = projects.filter((p) => p.impactRecord);

  let totalBefore = 0;
  let totalAfter = 0;
  let totalCostSaved = 0;
  let totalVillages = 0;
  let totalPatents = 0;
  let totalPapers = 0;
  let totalStartups = 0;

  for (const p of completedWithImpact) {
    const imp = p.impactRecord!;
    totalBefore += imp.householdsAffectedBefore || 0;
    totalAfter += imp.householdsBenefitedAfter || 0;
    totalCostSaved += imp.costSavedPerAnnumInRupees || 0;
    totalVillages += imp.villagesCovered || 0;
    totalPatents += imp.patentsFiledCount || 0;
    totalPapers += imp.researchPapersCount || 0;
    totalStartups += imp.startupsCreatedCount || 0;
  }

  res.json({
    impactSummary: {
      completedProjectsWithImpact: completedWithImpact.length,
      totalHouseholdsBenefited: totalAfter,
      totalHouseholdsBefore: totalBefore,
      overallImprovementPercent: totalBefore > 0 ? Math.round((totalAfter / totalBefore) * 100) : 0,
      totalCostSavedPerAnnumInRupees: totalCostSaved,
      totalVillagesReached: totalVillages,
      patentsFiled: totalPatents,
      researchPapersPublished: totalPapers,
      startupsIncubated: totalStartups,
      records: completedWithImpact.map((p) => ({
        projectId: p.id,
        projectTitle: p.title,
        university: p.universityName,
        district: p.district,
        impact: p.impactRecord,
      })),
    },
  });
});

router.get('/analytics/export/:type', (req: Request, res: Response) => {
  const { type } = req.params;

  if (type === 'challenges') {
    const challenges = db.getChallenges();
    let csv = 'ID,Title,Domain,District,Block,Affected Population,Priority,Status,Submitted By,Submitted At\n';
    for (const c of challenges) {
      csv += `"${c.id}","${c.title.replace(/"/g, '""')}","${c.domain}","${c.location.district}","${c.location.block}",${c.affectedPopulation},"${c.aiAnalysis?.priorityLevel || 'Medium'}","${c.status}","${c.submittedByName}","${c.submittedAt}"\n`;
    }
    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', 'attachment; filename="civicbridge_challenges.csv"');
    return res.send(csv);
  }

  if (type === 'universities') {
    const universities = db.getUniversities();
    let csv = 'ID,University Name,District,Type,Active Projects,Completed Projects,Student Count,Faculty Count\n';
    for (const u of universities) {
      csv += `"${u.id}","${u.name.replace(/"/g, '""')}","${u.district}","${u.type}",${u.activeProjectsCount},${u.pastCompletedProjects},${u.studentCount},${u.facultyCount}\n`;
    }
    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', 'attachment; filename="civicbridge_universities.csv"');
    return res.send(csv);
  }

  if (type === 'impact') {
    const projects = db.getProjects().filter((p) => p.impactRecord);
    let csv = 'Project ID,Project Title,District,University,Households Before,Households Benefited,Improvement %,Cost Saved (INR),Villages Covered\n';
    for (const p of projects) {
      const imp = p.impactRecord!;
      csv += `"${p.id}","${p.title.replace(/"/g, '""')}","${p.district}","${p.universityName}",${imp.householdsAffectedBefore},${imp.householdsBenefitedAfter},${imp.percentageImprovement}%,${imp.costSavedPerAnnumInRupees},${imp.villagesCovered}\n`;
    }
    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', 'attachment; filename="civicbridge_impact.csv"');
    return res.send(csv);
  }

  res.status(400).json({ error: 'Unknown export type' });
});

// ----------------------------------------------------
// 8. AUDIT LOGS
// ----------------------------------------------------

router.get('/audit-logs', (req: Request, res: Response) => {
  res.json({ logs: db.getAuditLogs() });
});

// ----------------------------------------------------
// 9. SEED RESET
// ----------------------------------------------------

router.post('/seed/reset', (req: Request, res: Response) => {
  const fresh = db.resetToSeed();
  currentSessionUser = fresh.users.find((u) => u.role === 'Government Department') || fresh.users[0];
  res.json({ success: true, message: 'Database reset to initial demo state with 20+ Jharkhand challenges and seed projects.' });
});
