/**
 * Core Data Models & Type Definitions for CivicBridge Jharkhand
 * Problem Statement: SIH26043 - Smart India Hackathon 2026
 */

export type UserRole =
  | 'Citizen'
  | 'Community Organization'
  | 'Panchayati Raj Institution'
  | 'Urban Local Body'
  | 'Government Department'
  | 'University Admin'
  | 'Faculty Mentor'
  | 'Student'
  | 'Industry Partner'
  | 'Startup/MSME'
  | 'CSR Organization'
  | 'Research Laboratory'
  | 'Innovation Hub'
  | 'Platform Administrator';

export type ChallengeDomain =
  | 'Education'
  | 'Agriculture'
  | 'Healthcare'
  | 'Water Resources'
  | 'Environment'
  | 'Energy'
  | 'Urban Development'
  | 'Accessibility'
  | 'Public Administration'
  | 'Rural Livelihoods'
  | 'Sanitation'
  | 'Infrastructure';

export type PriorityLevel = 'Critical' | 'High' | 'Medium' | 'Low';

export type ChallengeStatus =
  | 'Submitted'
  | 'Under AI Analysis'
  | 'Under Validation'
  | 'Validated'
  | 'Assigned'
  | 'Proposal Under Review'
  | 'Project Started'
  | 'Pilot Active'
  | 'Completed'
  | 'Rejected'
  | 'Needs Clarification';

export type ProjectStage =
  | 'Problem Definition'
  | 'Research'
  | 'Proposal'
  | 'Approval'
  | 'Team Formation'
  | 'Prototype'
  | 'Testing'
  | 'Pilot'
  | 'Validation'
  | 'Deployment'
  | 'Impact Measurement'
  | 'Completed';

export type MilestoneStatus =
  | 'Not Started'
  | 'In Progress'
  | 'Under Review'
  | 'Blocked'
  | 'Completed';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  avatarUrl?: string;
  organization?: string;
  district?: string;
  phone?: string;
  bio?: string;
  passwordHash?: string;
  createdAt: string;
}

export interface ChallengeMedia {
  id: string;
  name: string;
  type: 'image' | 'video' | 'pdf' | 'document';
  url: string;
  sizeBytes: number;
  uploadedAt: string;
}

export interface ChallengeLocation {
  state: string; // 'Jharkhand'
  district: string;
  block: string;
  villageOrCity: string;
  pincode?: string;
  gpsCoordinates?: {
    latitude: number;
    longitude: number;
  };
}

export interface RecommendedUniversity {
  universityId: string;
  universityName: string;
  district: string;
  matchScore: number; // 0 - 100
  matchReasons: string[];
  keyDepartments: string[];
  relevantFacilities: string[];
}

export interface ChallengeAIAnalysis {
  domain: ChallengeDomain;
  subDomain: string;
  priorityScore: number; // 0 - 100
  priorityLevel: PriorityLevel;
  urgency: 'Immediate' | 'Short-Term' | 'Medium-Term' | 'Long-Term';
  priorityReasoning: string[];
  duplicateProbability: number; // 0 - 100%
  possibleDuplicateId?: string;
  duplicateTitle?: string;
  recommendedUniversities: RecommendedUniversity[];
  requiredSkills: string[];
  suggestedSDG: string; // e.g. "SDG 6: Clean Water and Sanitation"
  suggestedProjectType: 'IoT & Automation' | 'Civil Engineering' | 'Biotechnology' | 'Mobile & Web Application' | 'Field Hardware' | 'Process Reform';
  confidenceScore: number; // 0 - 100
  analyzedAt: string;
  modelEngine: 'Deterministic Rule & NLP Vector Space' | 'Gemini 3.8 Flash Hybrid';
}

export interface DuplicateCandidate {
  existingChallengeId: string;
  existingTitle: string;
  similarityScore: number; // e.g. 87%
  domain: ChallengeDomain;
  district: string;
  status: ChallengeStatus;
}

export interface Challenge {
  id: string; // e.g. CB-JH-2026-000001
  title: string;
  detailedDescription: string;
  domain: ChallengeDomain;
  location: ChallengeLocation;
  affectedPopulation: number;
  urgency: 'Low' | 'Medium' | 'High' | 'Emergency';
  expectedOutcome: string;
  availableResources: string;
  contactName: string;
  contactPhone: string;
  contactEmail: string;
  media: ChallengeMedia[];
  status: ChallengeStatus;
  submittedByUserId: string;
  submittedByName: string;
  submittedAt: string;
  
  // AI fields
  aiAnalysis?: ChallengeAIAnalysis;
  duplicateCandidates: DuplicateCandidate[];
  isMerged?: boolean;
  mergedIntoId?: string;

  // Government & Assignment
  validatedBy?: string;
  validatedAt?: string;
  validationNotes?: string;
  assignedUniversityId?: string;
  assignedUniversityName?: string;
  assignedAt?: string;
  activeProjectId?: string;

  // Override record
  humanOverrides?: {
    originalDomain?: ChallengeDomain;
    originalPriority?: PriorityLevel;
    overrideReason: string;
    overriddenBy: string;
    overriddenAt: string;
  };
}

export interface University {
  id: string;
  name: string;
  shortName: string;
  district: string;
  address: string;
  type: 'Central University' | 'State University' | 'NIT/IIT' | 'Private/Deemed' | 'Polytechnic';
  departments: string[];
  facultyExpertise: string[];
  researchAreas: string[];
  innovationCenters: string[];
  incubationFacilities: string[];
  laboratories: string[];
  availableEquipment: string[];
  studentCount: number;
  facultyCount: number;
  activeProjectsCount: number;
  pastCompletedProjects: number;
  contactEmail: string;
  contactPhone: string;
  website: string;
}

export interface FacultyMentor {
  id: string;
  universityId: string;
  universityName: string;
  name: string;
  department: string;
  designation: string;
  specialization: string[];
  projectsMentored: number;
  email: string;
}

export interface StudentMember {
  id: string;
  name: string;
  universityId: string;
  universityName: string;
  department: string;
  yearOfStudy: string;
  skills: string[];
  roleInProject: string;
}

export interface IndustryPartner {
  id: string;
  companyName: string;
  industrySector: string;
  partnerType: 'Corporate/Industry' | 'Startup' | 'MSME' | 'CSR Foundation' | 'Research Lab' | 'Innovation Hub';
  district: string;
  expertise: string[];
  technologies: string[];
  csrFocusAreas: string[];
  fundingCapacity: string;
  mentorshipCapability: string[];
  labFacilities: string[];
  deploymentCapabilities: string[];
  contactPerson: string;
  email: string;
  phone: string;
  activePledgesCount: number;
}

export interface IndustryInterest {
  id: string;
  industryId: string;
  companyName: string;
  challengeId: string;
  projectId?: string;
  offeredSupport: ('Mentorship' | 'Funding' | 'Equipment' | 'Technical Support' | 'Prototype Sponsorship' | 'Pilot Hosting' | 'Deployment Support')[];
  financialPledgeAmountInRupees?: number;
  equipmentDetails?: string;
  mentorNominated?: string;
  status: 'Expressed' | 'Approved' | 'Active' | 'Delivered';
  createdAt: string;
}

export interface ProjectMilestone {
  id: string;
  title: string;
  description: string;
  owner: string;
  startDate: string;
  dueDate: string;
  status: MilestoneStatus;
  progressPercent: number;
  evidenceNotes?: string;
  deliverables?: string[];
  completedAt?: string;
}

export interface SolutionProposal {
  id: string;
  projectId: string;
  submittedByUniversityId: string;
  problemUnderstanding: string;
  proposedSolution: string;
  innovationHighlights: string[];
  technologyStack: string[];
  implementationPlan: string;
  estimatedBudgetInRupees: number;
  timelineMonths: number;
  expectedSocialImpact: string;
  scalabilityPlan: string;
  risksAndMitigation: string;
  sustainabilityStrategy: string;
  status: 'Draft' | 'Submitted' | 'Government Approved' | 'Revision Requested';
  submittedAt: string;
  reviewedAt?: string;
  reviewRemarks?: string;
}

export interface ProjectImpact {
  id: string;
  projectId: string;
  challengeId: string;
  householdsAffectedBefore: number;
  householdsBenefitedAfter: number;
  percentageImprovement: number;
  villagesCovered: number;
  costSavedPerAnnumInRupees: number;
  timeSavedMetric: string;
  environmentalImpact: string;
  educationOrHealthImprovement: string;
  livelihoodOrIncomeGenerated: string;
  technologyDeployedSummary: string;
  patentsFiledCount: number;
  researchPapersCount: number;
  startupsCreatedCount: number;
  recordedAt: string;
  verifiedByGovernmentDepartment: string;
}

export interface Project {
  id: string; // e.g. PRJ-JH-2026-001
  challengeId: string;
  challengeTitle: string;
  title: string;
  domain: ChallengeDomain;
  district: string;
  stage: ProjectStage;
  currentMilestoneIndex: number;
  overallProgress: number; // 0 - 100%
  universityId: string;
  universityName: string;
  leadFaculty: FacultyMentor;
  studentTeam: StudentMember[];
  industryPartners: IndustryInterest[];
  governmentDepartment: string;
  budgetInRupees: number;
  timelineStartDate: string;
  targetCompletionDate: string;
  proposal?: SolutionProposal;
  milestones: ProjectMilestone[];
  impactRecord?: ProjectImpact;
  createdAt: string;
  updatedAt: string;
}

export interface DiscussionMessage {
  id: string;
  channelType: 'challenge' | 'project' | 'industry' | 'government';
  targetEntityId: string; // challengeId or projectId
  senderId: string;
  senderName: string;
  senderRole: UserRole;
  content: string;
  attachments?: { name: string; url: string }[];
  timestamp: string;
}

export interface AppNotification {
  id: string;
  userId?: string; // specific user or role broadcast
  targetRole?: UserRole;
  title: string;
  message: string;
  type: 'challenge' | 'validation' | 'university' | 'proposal' | 'industry' | 'milestone' | 'impact' | 'system';
  relatedEntityId?: string;
  isRead: boolean;
  createdAt: string;
}

export interface AuditLog {
  id: string;
  userId: string;
  userName: string;
  userRole: UserRole;
  action: string;
  entityType: 'Challenge' | 'AI Analysis' | 'University' | 'Proposal' | 'Project' | 'Milestone' | 'Industry' | 'Impact';
  entityId: string;
  previousState?: string;
  newState: string;
  reason?: string;
  timestamp: string;
}
