/**
 * Typed API Client for CivicBridge Jharkhand
 */

import {
  User,
  Challenge,
  University,
  IndustryPartner,
  Project,
  DiscussionMessage,
  AppNotification,
  AuditLog,
  OverviewStats,
  DistrictStat,
  FacultyMentor,
  StudentMember,
} from './types';

const API_BASE = '/api';

export async function fetchMe(): Promise<{ user: User }> {
  const res = await fetch(`${API_BASE}/auth/me`);
  return res.json();
}

export async function fetchPersonas(): Promise<{ users: User[] }> {
  const res = await fetch(`${API_BASE}/auth/personas`);
  return res.json();
}

export async function switchRole(roleOrUserId: string): Promise<{ success: boolean; user: User }> {
  const res = await fetch(`${API_BASE}/auth/switch-role`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ role: roleOrUserId, userId: roleOrUserId }),
  });
  return res.json();
}

export async function registerUser(data: Partial<User>): Promise<{ success: boolean; user: User }> {
  const res = await fetch(`${API_BASE}/auth/register`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  return res.json();
}

export async function fetchChallenges(params?: {
  district?: string;
  domain?: string;
  priority?: string;
  status?: string;
  search?: string;
  submittedBy?: string;
}): Promise<{ challenges: Challenge[]; total: number }> {
  const q = new URLSearchParams();
  if (params?.district) q.set('district', params.district);
  if (params?.domain) q.set('domain', params.domain);
  if (params?.priority) q.set('priority', params.priority);
  if (params?.status) q.set('status', params.status);
  if (params?.search) q.set('search', params.search);
  if (params?.submittedBy) q.set('submittedBy', params.submittedBy);

  const res = await fetch(`${API_BASE}/challenges?${q.toString()}`);
  return res.json();
}

export async function fetchChallengeById(id: string): Promise<{ challenge: Challenge }> {
  const res = await fetch(`${API_BASE}/challenges/${id}`);
  return res.json();
}

export async function submitChallenge(data: any): Promise<{ success: boolean; challenge: Challenge }> {
  const res = await fetch(`${API_BASE}/challenges`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  return res.json();
}

export async function validateChallenge(
  id: string,
  data: {
    decision: 'approve' | 'reject' | 'needs_info' | 'assigned';
    overrideDomain?: string;
    overridePriority?: string;
    notes?: string;
    assignedUniversityId?: string;
  }
): Promise<{ success: boolean; challenge: Challenge }> {
  const res = await fetch(`${API_BASE}/challenges/${id}/validate`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  return res.json();
}

export async function mergeDuplicateChallenge(
  id: string,
  canonicalChallengeId: string,
  reason?: string
): Promise<{ success: boolean; message: string }> {
  const res = await fetch(`${API_BASE}/challenges/${id}/merge`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ canonicalChallengeId, reason }),
  });
  return res.json();
}

export async function fetchUniversities(): Promise<{ universities: University[] }> {
  const res = await fetch(`${API_BASE}/universities`);
  return res.json();
}

export async function fetchFaculty(): Promise<{ faculty: FacultyMentor[] }> {
  const res = await fetch(`${API_BASE}/faculty`);
  return res.json();
}

export async function fetchStudents(): Promise<{ students: StudentMember[] }> {
  const res = await fetch(`${API_BASE}/students`);
  return res.json();
}

export async function fetchIndustryPartners(): Promise<{ industryPartners: IndustryPartner[] }> {
  const res = await fetch(`${API_BASE}/industry`);
  return res.json();
}

export async function submitIndustryPledge(data: any): Promise<{ success: boolean; interest: any }> {
  const res = await fetch(`${API_BASE}/industry/pledge`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  return res.json();
}

export async function fetchProjects(params?: {
  stage?: string;
  district?: string;
  domain?: string;
  universityId?: string;
}): Promise<{ projects: Project[]; total: number }> {
  const q = new URLSearchParams();
  if (params?.stage) q.set('stage', params.stage);
  if (params?.district) q.set('district', params.district);
  if (params?.domain) q.set('domain', params.domain);
  if (params?.universityId) q.set('universityId', params.universityId);

  const res = await fetch(`${API_BASE}/projects?${q.toString()}`);
  return res.json();
}

export async function fetchProjectById(id: string): Promise<{ project: Project }> {
  const res = await fetch(`${API_BASE}/projects/${id}`);
  return res.json();
}

export async function createProject(data: any): Promise<{ success: boolean; project: Project }> {
  const res = await fetch(`${API_BASE}/projects`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  return res.json();
}

export async function submitProposal(
  projectId: string,
  data: any
): Promise<{ success: boolean; proposal: any }> {
  const res = await fetch(`${API_BASE}/projects/${projectId}/proposal`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  return res.json();
}

export async function reviewProposal(
  projectId: string,
  data: { decision: 'approve' | 'revise'; remarks?: string }
): Promise<{ success: boolean; proposal: any }> {
  const res = await fetch(`${API_BASE}/projects/${projectId}/proposal/review`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  return res.json();
}

export async function updateMilestone(
  projectId: string,
  milestoneId: string,
  data: any
): Promise<{ success: boolean; milestone: any; overallProgress: number; stage: string }> {
  const res = await fetch(`${API_BASE}/projects/${projectId}/milestones/${milestoneId}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  return res.json();
}

export async function recordProjectImpact(
  projectId: string,
  data: any
): Promise<{ success: boolean; impact: any }> {
  const res = await fetch(`${API_BASE}/projects/${projectId}/impact`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  return res.json();
}

export async function fetchMessages(
  channelType: string,
  targetEntityId: string
): Promise<{ messages: DiscussionMessage[] }> {
  const res = await fetch(`${API_BASE}/messages?channelType=${channelType}&targetEntityId=${targetEntityId}`);
  return res.json();
}

export async function sendMessage(data: {
  channelType: string;
  targetEntityId: string;
  content: string;
}): Promise<{ success: boolean; message: DiscussionMessage }> {
  const res = await fetch(`${API_BASE}/messages`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  return res.json();
}

export async function fetchNotifications(): Promise<{ notifications: AppNotification[]; unreadCount: number }> {
  const res = await fetch(`${API_BASE}/notifications`);
  return res.json();
}

export async function markNotificationRead(id: string): Promise<{ success: boolean }> {
  const res = await fetch(`${API_BASE}/notifications/${id}/read`, { method: 'PUT' });
  return res.json();
}

export async function markAllNotificationsRead(): Promise<{ success: boolean }> {
  const res = await fetch(`${API_BASE}/notifications/mark-all-read`, { method: 'PUT' });
  return res.json();
}

export async function fetchOverviewAnalytics(): Promise<{ overview: OverviewStats }> {
  const res = await fetch(`${API_BASE}/analytics/overview`);
  return res.json();
}

export async function fetchDistrictAnalytics(): Promise<{ districts: DistrictStat[] }> {
  const res = await fetch(`${API_BASE}/analytics/districts`);
  return res.json();
}

export async function fetchDomainAnalytics(): Promise<{ domains: { domain: string; total: number; highPriority: number; activeProjects: number }[] }> {
  const res = await fetch(`${API_BASE}/analytics/domains`);
  return res.json();
}

export async function fetchImpactAnalytics(): Promise<{ impactSummary: any }> {
  const res = await fetch(`${API_BASE}/analytics/impact`);
  return res.json();
}

export async function fetchAuditLogs(): Promise<{ logs: AuditLog[] }> {
  const res = await fetch(`${API_BASE}/audit-logs`);
  return res.json();
}

export async function resetDatabase(): Promise<{ success: boolean; message: string }> {
  const res = await fetch(`${API_BASE}/seed/reset`, { method: 'POST' });
  return res.json();
}
