/**
 * Analytics View - State Innovation Dashboard
 * Recharts visualization of domain distribution, district density,
 * project stages, and CSV report downloads.
 */

import React from 'react';
import { useApp } from '../context/AppContext';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  CartesianGrid,
  Legend,
} from 'recharts';
import {
  Download,
  FileSpreadsheet,
  TrendingUp,
  BarChart3,
  PieChart as PieIcon,
  ShieldCheck,
} from 'lucide-react';

const COLORS = ['#059669', '#0d9488', '#2563eb', '#7c3aed', '#d97706', '#dc2626', '#475569'];

export const AnalyticsView: React.FC = () => {
  const { analytics, challenges, projects } = useApp();

  const domainData = analytics?.challengesByDomain
    ? Object.entries(analytics.challengesByDomain).map(([name, value]) => ({
        name,
        value,
      }))
    : [];

  const districtData = analytics?.challengesByDistrict
    ? Object.entries(analytics.challengesByDistrict)
        .map(([name, value]) => ({
          name,
          value: Number(value) || 0,
        }))
        .sort((a, b) => b.value - a.value)
        .slice(0, 10)
    : [];

  const priorityData = analytics?.challengesByPriority
    ? Object.entries(analytics.challengesByPriority).map(([name, value]) => ({
        name,
        value,
      }))
    : [];

  const stageData = analytics?.projectsByStage
    ? Object.entries(analytics.projectsByStage).map(([name, value]) => ({
        name,
        value,
      }))
    : [];

  return (
    <div className="space-y-6 animate-in fade-in">
      {/* Top Banner */}
      <div className="p-6 bg-slate-900 text-white rounded-2xl border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-sm">
        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-xl bg-purple-700 flex items-center justify-center text-white font-bold shadow-md">
            <BarChart3 className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold uppercase tracking-wider text-purple-400">
                State Data Intelligence & Analytics
              </span>
              <span className="text-[10px] bg-slate-800 text-slate-300 px-2 py-0.5 rounded font-mono">
                Real-Time Geospatial & Domain Metrics
              </span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-white mt-1">
              Jharkhand Innovation Analytics Dashboard
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Comparative analytical intelligence tracking problem density, university allocation, and project stages.
            </p>
          </div>
        </div>

        {/* CSV Export Buttons */}
        <div className="flex flex-wrap items-center gap-2">
          <a
            href="/api/analytics/export/challenges"
            download="challenges.csv"
            className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold rounded-lg border border-slate-700 flex items-center gap-1.5 transition-colors"
          >
            <Download className="w-3.5 h-3.5 text-emerald-400" />
            <span>Challenges CSV</span>
          </a>
          <a
            href="/api/analytics/export/projects"
            download="projects.csv"
            className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold rounded-lg border border-slate-700 flex items-center gap-1.5 transition-colors"
          >
            <Download className="w-3.5 h-3.5 text-blue-400" />
            <span>Projects CSV</span>
          </a>
          <a
            href="/api/analytics/export/universities"
            download="universities.csv"
            className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold rounded-lg border border-slate-700 flex items-center gap-1.5 transition-colors"
          >
            <Download className="w-3.5 h-3.5 text-amber-400" />
            <span>Universities CSV</span>
          </a>
        </div>
      </div>

      {/* Row 1: Challenges by Domain & Top Districts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Domain Distribution */}
        <div className="p-6 bg-white rounded-2xl border border-slate-200 shadow-xs">
          <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider mb-1">
            Challenges by Domain Distribution
          </h3>
          <p className="text-xs text-slate-500 mb-4">
            Breakdown across water, agriculture, energy, healthcare, and education
          </p>

          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={domainData} margin={{ top: 10, right: 10, left: -20, bottom: 20 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" angle={-30} textAnchor="end" tick={{ fontSize: 10 }} interval={0} />
                <YAxis tick={{ fontSize: 11 }} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0f172a', border: 'none', borderRadius: '8px', color: '#fff', fontSize: '11px' }}
                />
                <Bar dataKey="value" fill="#059669" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Top Districts by Problem Volume */}
        <div className="p-6 bg-white rounded-2xl border border-slate-200 shadow-xs">
          <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider mb-1">
            Top 10 Districts by Challenge Volume
          </h3>
          <p className="text-xs text-slate-500 mb-4">
            Geographic hotspot density requiring urgent university intervention
          </p>

          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={districtData} layout="vertical" margin={{ top: 5, right: 20, left: 30, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#f1f5f9" />
                <XAxis type="number" tick={{ fontSize: 11 }} />
                <YAxis dataKey="name" type="category" tick={{ fontSize: 10 }} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0f172a', border: 'none', borderRadius: '8px', color: '#fff', fontSize: '11px' }}
                />
                <Bar dataKey="value" fill="#2563eb" radius={[0, 4, 4, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Row 2: Priority Pie Chart & Project Stage Funnel */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Priority Breakdown */}
        <div className="p-6 bg-white rounded-2xl border border-slate-200 shadow-xs flex flex-col justify-between">
          <div>
            <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider mb-1">
              AI Priority Classification Ratio
            </h3>
            <p className="text-xs text-slate-500 mb-4">
              Critical, High, Medium, and Low calculated via explainable multi-factor scoring
            </p>

            <div className="h-64 flex items-center justify-center">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={priorityData}
                    cx="50%"
                    cy="50%"
                    innerRadius={55}
                    outerRadius={80}
                    paddingAngle={4}
                    dataKey="value"
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  >
                    {priorityData.map((entry, index) => (
                      <Cell
                        key={`cell-${index}`}
                        fill={
                          entry.name === 'Critical'
                            ? '#dc2626'
                            : entry.name === 'High'
                            ? '#d97706'
                            : entry.name === 'Medium'
                            ? '#2563eb'
                            : '#059669'
                        }
                      />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        {/* Project Stage Funnel */}
        <div className="p-6 bg-white rounded-2xl border border-slate-200 shadow-xs">
          <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider mb-1">
            Projects Across 12-Stage Lifecycle
          </h3>
          <p className="text-xs text-slate-500 mb-4">
            Distribution from proposal drafting to laboratory prototyping and completed handover
          </p>

          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={stageData} margin={{ top: 10, right: 10, left: -20, bottom: 20 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" angle={-25} textAnchor="end" tick={{ fontSize: 10 }} interval={0} />
                <YAxis tick={{ fontSize: 11 }} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0f172a', border: 'none', borderRadius: '8px', color: '#fff', fontSize: '11px' }}
                />
                <Bar dataKey="value" fill="#7c3aed" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};
