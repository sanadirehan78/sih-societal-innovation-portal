/**
 * Industry & CSR Partner Portal
 * Facilitates corporate co-creation, CSR matching funds, equipment pledges, and industrial mentorship.
 */

import React from 'react';
import { useApp } from '../context/AppContext';
import {
  Briefcase,
  HeartHandshake,
  DollarSign,
  TrendingUp,
  ShieldCheck,
  Building2,
  ExternalLink,
  PlusCircle,
  Award,
} from 'lucide-react';

export const IndustryView: React.FC = () => {
  const {
    industryPartners,
    projects,
    challenges,
    setIsPledgeModalOpen,
    setActiveEntityForModal,
  } = useApp();

  const handleOpenPledge = (item: any) => {
    setActiveEntityForModal(item);
    setIsPledgeModalOpen(true);
  };

  const totalCSR = industryPartners.reduce(
    (acc, p) => acc + (p.activePledges?.reduce((sum, pl) => sum + (pl.financialPledgeAmountInRupees || 0), 0) || 0),
    0
  );

  return (
    <div className="space-y-6 animate-in fade-in">
      {/* Top Banner */}
      <div className="p-6 bg-slate-900 text-white rounded-2xl border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-sm">
        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-xl bg-amber-600 flex items-center justify-center text-white font-bold shadow-md">
            <HeartHandshake className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold uppercase tracking-wider text-amber-400">
                Public-Private Partnership & CSR Portal
              </span>
              <span className="text-[10px] bg-slate-800 text-slate-300 px-2 py-0.5 rounded font-mono">
                Tax-Exempt GoJ Innovation Fund
              </span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-white mt-1">
              Industry Co-Creation & Technology Transfer Clearinghouse
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Empowering Jharkhand's industrial leaders to co-fund student prototypes, provide testing labs, and mentor researchers.
            </p>
          </div>
        </div>

        <div className="text-right">
          <span className="text-2xl font-black text-amber-400 font-mono">
            ₹{((totalCSR || 2150000) / 100000).toFixed(1)} Lakh
          </span>
          <span className="block text-[10px] font-semibold text-slate-400 uppercase">
            Total Pledged CSR Capital
          </span>
        </div>
      </div>

      {/* Corporate Partners Roster */}
      <div>
        <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wider mb-3">
          Accredited Industry & CSR Partners ({industryPartners.length})
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {industryPartners.map((partner) => (
            <div
              key={partner.id}
              className="p-5 bg-white rounded-xl border border-slate-200 shadow-xs flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[10px] font-bold uppercase bg-slate-100 text-slate-700 px-2 py-0.5 rounded">
                    {partner.sector}
                  </span>
                  <span className="text-[10px] text-slate-400 font-mono">{partner.district}</span>
                </div>

                <h4 className="font-bold text-slate-900 text-sm">{partner.name}</h4>
                <p className="text-xs text-slate-500 mt-1">Focus: {partner.csrFocusAreas.join(', ')}</p>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                <span className="text-slate-500 text-[11px]">CSR Pledged:</span>
                <span className="font-bold text-amber-700 font-mono">
                  ₹{((partner.totalPledgedInRupees || 500000) / 100000).toFixed(1)}L
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Projects Seeking Co-Creation & CSR Pledges */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-base font-bold text-slate-900">
              Active University Projects Open for Industry Partnership
            </h3>
            <p className="text-xs text-slate-500">
              Provide industrial mentorship, laboratory validation, or matching CSR grants to accelerate deployment.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {projects.map((p) => (
            <div
              key={p.id}
              className="p-4 rounded-xl border border-slate-200 hover:border-amber-500 bg-slate-50/50 transition-all text-xs flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between gap-2 mb-1.5">
                  <span className="font-mono font-bold text-emerald-800 bg-white px-2 py-0.5 rounded border border-slate-200">
                    {p.id}
                  </span>
                  <span className="font-bold text-slate-700">Stage: {p.stage}</span>
                </div>

                <h4 className="font-bold text-slate-900 text-sm">{p.title}</h4>
                <p className="text-slate-600 mt-1">
                  Executing: <strong>{p.universityName}</strong>
                </p>
                <p className="text-slate-500 text-[11px] mt-0.5">
                  Lead Mentor: {p.leadFaculty.name} ({p.leadFaculty.department})
                </p>

                {p.industryPartnerName ? (
                  <div className="mt-2.5 p-2 bg-amber-50 border border-amber-200 rounded text-[11px] text-amber-900">
                    Industry Partner: <strong>{p.industryPartnerName}</strong> • {p.industrySupportType?.join(', ')}
                  </div>
                ) : (
                  <div className="mt-2.5 p-2 bg-slate-100 rounded text-[11px] text-slate-500">
                    Seeking Industry Co-Sponsorship & Prototype Testing Lab
                  </div>
                )}
              </div>

              <div className="mt-4 pt-3 border-t border-slate-200 flex items-center justify-between">
                <span className="text-slate-500">
                  Budget: <strong className="font-mono text-slate-800">₹{(p.budgetInRupees / 100000).toFixed(1)}L</strong>
                </span>

                <button
                  onClick={() => handleOpenPledge(p)}
                  className="px-3 py-1.5 bg-amber-600 hover:bg-amber-700 text-white rounded text-xs font-bold flex items-center gap-1.5 transition-colors shadow-xs"
                >
                  <Briefcase className="w-3.5 h-3.5" />
                  <span>Pledge CSR Support</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
