/**
 * Map View - Geospatial 24-District Challenge Density
 * Interactive SVG district heat map with real-time incident filtering.
 */

import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { JharkhandMap } from '../components/JharkhandMap';
import {
  MapPin,
  Users,
  AlertTriangle,
  ExternalLink,
  GraduationCap,
  Layers,
} from 'lucide-react';

export const MapView: React.FC = () => {
  const { challenges, setSelectedChallenge, universities } = useApp();
  const [selectedDistrict, setSelectedDistrict] = useState<string>('Ranchi');

  const districtChallenges = challenges.filter(
    (c) => c.location.district.toLowerCase() === selectedDistrict.toLowerCase()
  );

  const totalAffected = districtChallenges.reduce((acc, c) => acc + (c.affectedPopulation || 0), 0);
  const criticalCount = districtChallenges.filter(
    (c) => c.aiAnalysis?.priorityLevel === 'Critical'
  ).length;

  const districtUnis = universities.filter(
    (u) => u.district.toLowerCase() === selectedDistrict.toLowerCase()
  );

  return (
    <div className="space-y-6 animate-in fade-in">
      {/* Top Banner */}
      <div className="p-6 bg-slate-900 text-white rounded-2xl border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-sm">
        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-xl bg-teal-700 flex items-center justify-center text-white font-bold shadow-md">
            <MapPin className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold uppercase tracking-wider text-teal-400">
                Geospatial Density Intelligence
              </span>
              <span className="text-[10px] bg-slate-800 text-slate-300 px-2 py-0.5 rounded font-mono">
                All 24 Jharkhand Districts
              </span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-white mt-1">
              Jharkhand State Civic Challenge Heatmap
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Click any district below to inspect grassroots problems, affected populations, and local university partners.
            </p>
          </div>
        </div>

        <div className="text-right">
          <span className="text-2xl font-black text-teal-400 font-mono">24</span>
          <span className="block text-[10px] font-semibold text-slate-400 uppercase">
            Districts Monitored Live
          </span>
        </div>
      </div>

      {/* Grid: Map on Left, District Inspector on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Interactive Map */}
        <div className="lg:col-span-7 bg-white rounded-2xl border border-slate-200 p-6 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider">
                Interactive State District Grid
              </h3>
              <span className="text-xs text-slate-500">
                Selected: <strong className="text-emerald-800">{selectedDistrict}</strong>
              </span>
            </div>

            <JharkhandMap
              selectedDistrict={selectedDistrict}
              onSelectDistrict={(d) => setSelectedDistrict(d)}
            />
          </div>

          <div className="mt-4 pt-4 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
            <span>Color intensity represents challenge density</span>
            <span className="font-semibold text-emerald-800">
              {districtChallenges.length} challenges in {selectedDistrict}
            </span>
          </div>
        </div>

        {/* Right Column: District Inspector Panel */}
        <div className="lg:col-span-5 bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-5">
          <div>
            <span className="text-[10px] font-bold text-emerald-800 uppercase bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
              District Focus
            </span>
            <h3 className="text-xl font-black text-slate-900 mt-1">{selectedDistrict} District</h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Regional summary of reported civic challenges and university coverage.
            </p>
          </div>

          {/* KPI Mini-Cards */}
          <div className="grid grid-cols-3 gap-2 text-center">
            <div className="p-2.5 bg-slate-50 border border-slate-200 rounded-lg">
              <span className="text-[10px] font-bold text-slate-500 uppercase block">Total</span>
              <span className="text-base font-bold text-slate-900 font-mono">
                {districtChallenges.length}
              </span>
            </div>
            <div className="p-2.5 bg-red-50 border border-red-200 rounded-lg">
              <span className="text-[10px] font-bold text-red-700 uppercase block">Critical</span>
              <span className="text-base font-bold text-red-700 font-mono">{criticalCount}</span>
            </div>
            <div className="p-2.5 bg-emerald-50 border border-emerald-200 rounded-lg">
              <span className="text-[10px] font-bold text-emerald-800 uppercase block">Pop</span>
              <span className="text-base font-bold text-emerald-800 font-mono">
                {totalAffected > 1000 ? `${(totalAffected / 1000).toFixed(1)}k` : totalAffected}
              </span>
            </div>
          </div>

          {/* Local Academic Institutions */}
          {districtUnis.length > 0 && (
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs">
              <span className="font-bold text-slate-700 block mb-1">
                Regional University Anchors:
              </span>
              <div className="space-y-1">
                {districtUnis.map((u) => (
                  <div key={u.id} className="flex items-center gap-1.5 text-emerald-800 font-medium">
                    <GraduationCap className="w-3.5 h-3.5" />
                    <span>{u.name} ({u.type})</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* List of challenges in this district */}
          <div className="space-y-2.5">
            <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider">
              Challenges in {selectedDistrict} ({districtChallenges.length})
            </h4>

            {districtChallenges.length === 0 ? (
              <div className="p-6 bg-slate-50 border border-slate-200 rounded-xl text-center text-xs text-slate-500">
                No challenges reported in {selectedDistrict} yet.
              </div>
            ) : (
              <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
                {districtChallenges.map((c) => (
                  <div
                    key={c.id}
                    onClick={() => setSelectedChallenge(c)}
                    className="p-3 rounded-xl border border-slate-200 hover:border-emerald-500 hover:bg-emerald-50/20 transition-all cursor-pointer text-xs group"
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-mono font-bold text-[10px] bg-slate-100 px-1.5 py-0.2 rounded text-slate-700">
                        {c.id}
                      </span>
                      <span className="text-[10px] font-bold text-emerald-800">{c.domain}</span>
                    </div>

                    <h5 className="font-bold text-slate-900 group-hover:text-emerald-900 line-clamp-1">
                      {c.title}
                    </h5>
                    <p className="text-[11px] text-slate-500 line-clamp-1 mt-0.5">
                      {c.location.block} • {c.affectedPopulation.toLocaleString()} citizens
                    </p>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
