/**
 * Universities View - Higher Education Innovation Hub
 * Directory of 10+ universities, assigned challenges, and multidisciplinary teams.
 */

import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  GraduationCap,
  Users,
  Building2,
  FileText,
  Search,
  ExternalLink,
  PlusCircle,
  FlaskConical,
  Award,
} from 'lucide-react';
import { University } from '../types';

export const UniversityView: React.FC = () => {
  const {
    universities,
    challenges,
    projects,
    setSelectedChallenge,
    setIsTeamBuilderModalOpen,
    setActiveEntityForModal,
  } = useApp();

  const [selectedUni, setSelectedUni] = useState<University>(universities[0] || ({} as University));
  const [search, setSearch] = useState('');

  const filteredUnis = universities.filter(
    (u) =>
      u.name.toLowerCase().includes(search.toLowerCase()) ||
      u.district.toLowerCase().includes(search.toLowerCase()) ||
      u.shortName.toLowerCase().includes(search.toLowerCase())
  );

  const uniProjects = projects.filter((p) => p.universityId === selectedUni.id);
  const assignedChallenges = challenges.filter(
    (c) => c.assignedUniversityId === selectedUni.id && c.status === 'Assigned'
  );

  const handleAssembleTeam = (c: any) => {
    setActiveEntityForModal(c);
    setIsTeamBuilderModalOpen(true);
  };

  return (
    <div className="space-y-6 animate-in fade-in">
      {/* Top Banner */}
      <div className="p-6 bg-slate-900 text-white rounded-2xl border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-sm">
        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-xl bg-emerald-700 flex items-center justify-center text-white font-bold shadow-md">
            <GraduationCap className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold uppercase tracking-wider text-emerald-400">
                Academic Research & Engineering Clearinghouse
              </span>
              <span className="text-[10px] bg-slate-800 text-slate-300 px-2 py-0.5 rounded font-mono">
                10 Universities Enrolled
              </span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-white mt-1">
              Higher Education Technical Collaboration Portal
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Empowering faculty leads and multidisciplinary engineering students to solve validated Jharkhand civic challenges.
            </p>
          </div>
        </div>

        <div className="text-right">
          <span className="text-2xl font-black text-emerald-400 font-mono">
            {projects.length}
          </span>
          <span className="block text-[10px] font-semibold text-slate-400 uppercase">
            Active Projects Across State
          </span>
        </div>
      </div>

      {/* Main Grid: University List & Selected University Dossier */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: University Directory Selector */}
        <div className="lg:col-span-4 bg-white rounded-2xl border border-slate-200 p-4 shadow-xs space-y-3">
          <div className="relative">
            <Search className="w-3.5 h-3.5 absolute left-3 top-3 text-slate-400" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search university or district..."
              className="w-full pl-8 pr-3 py-2 border border-slate-300 rounded-lg text-xs focus:ring-2 focus:ring-emerald-500 focus:outline-none"
            />
          </div>

          <div className="space-y-2 max-h-[580px] overflow-y-auto pr-1">
            {filteredUnis.map((uni) => {
              const isSelected = selectedUni.id === uni.id;
              const uProjects = projects.filter((p) => p.universityId === uni.id).length;
              return (
                <div
                  key={uni.id}
                  onClick={() => setSelectedUni(uni)}
                  className={`p-3.5 rounded-xl border text-xs cursor-pointer transition-all ${
                    isSelected
                      ? 'border-emerald-600 bg-emerald-50/70 shadow-xs ring-1 ring-emerald-500'
                      : 'border-slate-200 hover:border-slate-300 bg-white'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <h4 className="font-bold text-slate-900 leading-snug">{uni.name}</h4>
                      <span className="text-[10px] text-slate-500">{uni.district} • {uni.type}</span>
                    </div>
                    <span className="text-[10px] font-bold bg-slate-100 text-slate-700 px-1.5 py-0.2 rounded font-mono">
                      {uni.shortName}
                    </span>
                  </div>

                  <div className="mt-2.5 flex items-center justify-between text-[10px] text-slate-600 pt-2 border-t border-slate-100">
                    <span>Active Projects: <strong className="text-emerald-800">{uProjects}</strong></span>
                    <span>Students: {uni.studentCount.toLocaleString()}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Column: University Detailed Dashboard */}
        <div className="lg:col-span-8 bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-6">
          {/* Header Info */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-slate-100 pb-4 gap-2">
            <div>
              <span className="text-[10px] font-bold uppercase text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                {selectedUni.type}
              </span>
              <h3 className="text-xl font-black text-slate-900 mt-1">{selectedUni.name}</h3>
              <p className="text-xs text-slate-500 mt-0.5">{selectedUni.address}</p>
            </div>

            <div className="flex items-center gap-2">
              <div className="p-2.5 bg-slate-50 rounded-lg text-center border border-slate-200">
                <span className="text-[10px] font-bold text-slate-400 block uppercase">Faculty</span>
                <span className="text-sm font-bold text-slate-900 font-mono">{selectedUni.facultyCount}</span>
              </div>
              <div className="p-2.5 bg-slate-50 rounded-lg text-center border border-slate-200">
                <span className="text-[10px] font-bold text-slate-400 block uppercase">Students</span>
                <span className="text-sm font-bold text-slate-900 font-mono">{selectedUni.studentCount}</span>
              </div>
            </div>
          </div>

          {/* Laboratories & Infrastructure */}
          <div>
            <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-2 flex items-center gap-1.5">
              <FlaskConical className="w-4 h-4 text-emerald-700" />
              <span>Accredited Research Laboratories & Innovation Centers</span>
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {selectedUni.laboratories.map((lab, i) => (
                <div key={i} className="p-2.5 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-700">
                  <span className="font-semibold text-slate-900 block">• {lab}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Assigned Problems Awaiting Team Assembly */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                Assigned State Challenges Awaiting Team ({assignedChallenges.length})
              </h4>
            </div>

            {assignedChallenges.length === 0 ? (
              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 text-xs text-slate-500 text-center">
                No unassigned challenges currently pending for {selectedUni.shortName}.
              </div>
            ) : (
              <div className="space-y-3">
                {assignedChallenges.map((c) => (
                  <div
                    key={c.id}
                    className="p-4 rounded-xl border border-slate-200 bg-slate-50/60 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
                  >
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-mono font-bold text-emerald-800">{c.id}</span>
                        <span className="font-bold text-slate-900">{c.title}</span>
                      </div>
                      <p className="text-slate-500 line-clamp-1">{c.detailedDescription}</p>
                    </div>

                    <button
                      onClick={() => handleAssembleTeam(c)}
                      className="px-3 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded text-xs font-bold flex items-center gap-1.5 flex-shrink-0 transition-all shadow-xs"
                    >
                      <Users className="w-3.5 h-3.5" />
                      <span>Assemble Team</span>
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Active Projects Deployed by this University */}
          <div>
            <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
              Active Innovation Projects ({uniProjects.length})
            </h4>

            {uniProjects.length === 0 ? (
              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 text-xs text-slate-500 text-center">
                No active projects deployed yet.
              </div>
            ) : (
              <div className="space-y-2.5">
                {uniProjects.map((p) => (
                  <div
                    key={p.id}
                    className="p-3.5 rounded-xl border border-slate-200 hover:border-emerald-500 bg-white transition-all text-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                  >
                    <div>
                      <span className="text-[10px] font-mono font-bold bg-slate-100 text-slate-700 px-1.5 py-0.2 rounded">
                        {p.id}
                      </span>
                      <h5 className="font-bold text-slate-900 mt-1">{p.title}</h5>
                      <span className="text-slate-500 text-[11px]">
                        Lead: {p.leadFaculty.name} ({p.leadFaculty.department}) • Stage: {p.stage}
                      </span>
                    </div>

                    <div className="w-32 flex-shrink-0">
                      <div className="flex justify-between text-[10px] text-slate-500 mb-1">
                        <span>Progress</span>
                        <span className="font-mono font-bold text-slate-900">{p.overallProgress}%</span>
                      </div>
                      <div className="w-full bg-slate-100 rounded-full h-1.5 overflow-hidden">
                        <div
                          className="bg-emerald-600 h-full rounded-full"
                          style={{ width: `${p.overallProgress}%` }}
                        ></div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
