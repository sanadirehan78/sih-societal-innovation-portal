/**
 * Government Department Desk - Higher & Technical Education
 * Validation pipeline, AI override management, university assignment,
 * and immutable administrative audit logs.
 */

import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import {
  ShieldCheck,
  CheckCircle2,
  AlertTriangle,
  FileText,
  GraduationCap,
  Download,
  Search,
  ExternalLink,
  History,
  Building2,
  Sparkles,
} from 'lucide-react';
import { Challenge, AuditLog } from '../types';
import * as api from '../api';

export const GovernmentView: React.FC = () => {
  const {
    challenges,
    universities,
    setSelectedChallenge,
    refreshAllData,
    showToast,
  } = useApp();

  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [filterTab, setFilterTab] = useState<'pending' | 'validated' | 'audit'>('pending');
  const [selectedForAction, setSelectedForAction] = useState<Challenge | null>(null);
  const [actionNotes, setActionNotes] = useState('');
  const [assignedUniId, setAssignedUniId] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);

  useEffect(() => {
    async function loadAudit() {
      try {
        const res = await api.fetchAuditLogs();
        if (res.logs) setAuditLogs(res.logs);
      } catch (err) {
        console.error(err);
      }
    }
    loadAudit();
  }, [challenges]);

  const pendingList = challenges.filter(
    (c) => c.status === 'Submitted' || c.status === 'Under Validation'
  );
  const validatedList = challenges.filter((c) =>
    ['Validated', 'Assigned', 'Project Started', 'Completed'].includes(c.status)
  );

  const handleQuickValidate = async (
    challengeId: string,
    decision: 'approve' | 'reject' | 'assigned'
  ) => {
    setIsProcessing(true);
    try {
      const res = await api.validateChallenge(challengeId, {
        decision,
        notes: actionNotes || 'Administrative clearance by Higher & Technical Education Dept',
        assignedUniversityId: assignedUniId || undefined,
      });

      if (res.success) {
        showToast(`Challenge ${challengeId} ${decision === 'approve' ? 'validated' : decision}!`);
        setSelectedForAction(null);
        setActionNotes('');
        await refreshAllData();
      }
    } catch (err) {
      showToast('Validation failed');
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in">
      {/* Top Banner */}
      <div className="p-6 bg-slate-900 text-white rounded-2xl border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-sm">
        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-xl bg-emerald-700 flex items-center justify-center text-white font-bold shadow-md">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold uppercase tracking-wider text-emerald-400">
                Official Validation & Oversight Desk
              </span>
              <span className="text-[10px] bg-slate-800 text-slate-300 px-2 py-0.5 rounded font-mono">
                Department of Higher & Technical Education, GoJ
              </span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-white mt-1">
              State Problem Triage & University Routing Clearinghouse
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Review AI domain scoring, verify citizen authenticity, and dispatch problems to accredited universities.
            </p>
          </div>
        </div>

        {/* CSV Export Tools */}
        <div className="flex items-center gap-2 self-start md:self-center">
          <a
            href="/api/analytics/export/challenges"
            download="challenges.csv"
            className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-lg border border-slate-700 flex items-center gap-1.5 transition-colors"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export CSV</span>
          </a>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-slate-200 gap-4">
        {[
          { id: 'pending', label: 'Pending Validation', count: pendingList.length },
          { id: 'validated', label: 'Approved & Assigned', count: validatedList.length },
          { id: 'audit', label: 'Immutable Audit Trail', count: auditLogs.length },
        ].map((t) => (
          <button
            key={t.id}
            onClick={() => setFilterTab(t.id as any)}
            className={`pb-3 text-xs font-bold flex items-center gap-1.5 transition-all relative ${
              filterTab === t.id
                ? 'text-emerald-800 border-b-2 border-emerald-700'
                : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            <span>{t.label}</span>
            <span
              className={`px-1.5 py-0.2 rounded-full text-[10px] font-mono ${
                filterTab === t.id ? 'bg-emerald-100 text-emerald-900' : 'bg-slate-100 text-slate-600'
              }`}
            >
              {t.count}
            </span>
          </button>
        ))}
      </div>

      {/* TAB 1: Pending Validation Queue */}
      {filterTab === 'pending' && (
        <div className="space-y-4">
          {pendingList.length === 0 ? (
            <div className="p-12 bg-white rounded-xl border border-slate-200 text-center text-xs text-slate-500">
              ✓ All citizen challenges have been validated! No pending submissions.
            </div>
          ) : (
            pendingList.map((c) => (
              <div
                key={c.id}
                className="p-5 bg-white rounded-xl border border-slate-200 shadow-xs hover:border-slate-300 transition-all space-y-3"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-mono font-bold bg-slate-900 text-white px-2 py-0.5 rounded">
                      {c.id}
                    </span>
                    <span className="text-xs font-bold text-slate-900">{c.title}</span>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="text-[10px] bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded font-bold">
                      Domain: {c.domain}
                    </span>
                    <span
                      className={`text-[10px] px-2 py-0.5 rounded font-bold ${
                        c.aiAnalysis?.priorityLevel === 'Critical'
                          ? 'bg-red-100 text-red-800'
                          : 'bg-amber-100 text-amber-800'
                      }`}
                    >
                      AI Priority: {c.aiAnalysis?.priorityLevel} ({c.aiAnalysis?.priorityScore} pts)
                    </span>
                  </div>
                </div>

                <p className="text-xs text-slate-600 leading-relaxed">{c.detailedDescription}</p>

                <div className="flex flex-wrap items-center gap-4 text-[11px] text-slate-500">
                  <span>📍 {c.location.block}, {c.location.district}</span>
                  <span>👥 {c.affectedPopulation.toLocaleString()} citizens impacted</span>
                  <span>👤 Submitter: {c.submittedByName}</span>
                  <span>Duplicate Risk: {c.aiAnalysis?.duplicateProbability}%</span>
                </div>

                {/* AI Recommended University Match */}
                {c.aiAnalysis?.recommendedUniversities && c.aiAnalysis.recommendedUniversities.length > 0 && (
                  <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 text-xs flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div>
                      <span className="font-bold text-slate-700">Top AI Match: </span>
                      <span className="font-bold text-emerald-800">
                        {c.aiAnalysis.recommendedUniversities[0].universityName}
                      </span>
                      <span className="text-slate-500 text-[11px]">
                        {' '}
                        ({c.aiAnalysis.recommendedUniversities[0].matchScore}% match score based on laboratory infrastructure)
                      </span>
                    </div>

                    <button
                      onClick={() => setSelectedChallenge(c)}
                      className="text-xs text-emerald-700 font-bold hover:underline flex items-center gap-1 self-start sm:self-auto"
                    >
                      <span>Inspect AI Breakdown</span>
                      <ExternalLink className="w-3 h-3" />
                    </button>
                  </div>
                )}

                {/* Validation Actions */}
                <div className="pt-2 border-t border-slate-100 flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2 flex-1 min-w-[200px]">
                    <select
                      value={assignedUniId}
                      onChange={(e) => setAssignedUniId(e.target.value)}
                      className="text-xs px-2.5 py-1.5 border border-slate-300 rounded-md focus:ring-1 focus:ring-emerald-500 focus:outline-none"
                    >
                      <option value="">Assign to University...</option>
                      {universities.map((u) => (
                        <option key={u.id} value={u.id}>
                          {u.name} ({u.district})
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => handleQuickValidate(c.id, 'approve')}
                      disabled={isProcessing}
                      className="px-3 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded text-xs font-bold transition-colors"
                    >
                      ✓ Approve
                    </button>
                    <button
                      onClick={() => handleQuickValidate(c.id, 'assigned')}
                      disabled={isProcessing || !assignedUniId}
                      className="px-3 py-1.5 bg-blue-700 hover:bg-blue-800 text-white rounded text-xs font-bold transition-colors disabled:opacity-40"
                    >
                      Assign to University
                    </button>
                    <button
                      onClick={() => handleQuickValidate(c.id, 'reject')}
                      disabled={isProcessing}
                      className="px-3 py-1.5 bg-rose-600 hover:bg-rose-700 text-white rounded text-xs font-bold transition-colors"
                    >
                      Reject
                    </button>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {/* TAB 2: Validated & Assigned */}
      {filterTab === 'validated' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {validatedList.map((c) => (
            <div
              key={c.id}
              onClick={() => setSelectedChallenge(c)}
              className="p-4 bg-white rounded-xl border border-slate-200 hover:border-emerald-500 transition-all cursor-pointer shadow-xs group"
            >
              <div className="flex items-center justify-between mb-2">
                <span className="text-[10px] font-mono font-bold bg-slate-100 text-slate-800 px-1.5 py-0.2 rounded">
                  {c.id}
                </span>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-100 text-emerald-800">
                  {c.status}
                </span>
              </div>
              <h4 className="text-xs font-bold text-slate-900 group-hover:text-emerald-900 line-clamp-1">
                {c.title}
              </h4>
              <p className="text-[11px] text-slate-500 mt-1">
                📍 {c.location.district} • Pop: {c.affectedPopulation.toLocaleString()}
              </p>
              {c.assignedUniversityName && (
                <div className="mt-2 text-[11px] text-emerald-800 font-semibold flex items-center gap-1">
                  <GraduationCap className="w-3.5 h-3.5" />
                  <span>{c.assignedUniversityName}</span>
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {/* TAB 3: Immutable Audit Trail */}
      {filterTab === 'audit' && (
        <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs">
          <div className="p-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <History className="w-4 h-4 text-slate-600" />
              <span className="font-bold text-xs text-slate-900">Immutable Administrative Activity Log</span>
            </div>
            <span className="text-[10px] text-slate-400">All administrative operations are cryptographically chained</span>
          </div>

          <div className="divide-y divide-slate-100 max-h-96 overflow-y-auto">
            {auditLogs.map((log) => (
              <div key={log.id} className="p-3.5 hover:bg-slate-50 transition-colors text-xs">
                <div className="flex items-center justify-between mb-1">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-slate-900">{log.userName}</span>
                    <span className="text-[10px] bg-slate-100 text-slate-700 px-1.5 py-0.2 rounded font-medium">
                      {log.userRole}
                    </span>
                  </div>
                  <span className="text-[10px] text-slate-400 font-mono">
                    {new Date(log.timestamp).toLocaleString()}
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  <span className="font-semibold text-emerald-800">{log.action}:</span>
                  <span className="text-slate-700">{log.reason || log.newState}</span>
                  <span className="font-mono text-[10px] text-slate-400 ml-auto">{log.entityId}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
