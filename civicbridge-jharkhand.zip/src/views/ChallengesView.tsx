/**
 * Challenges View - Crowdsourced Civic Problem Registry
 * Filterable and searchable by all 24 districts, 12 domains, priority and status.
 */

import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  Search,
  Filter,
  PlusCircle,
  MapPin,
  Users,
  AlertTriangle,
  Sparkles,
  ExternalLink,
  GraduationCap,
  LayoutGrid,
  List,
} from 'lucide-react';
import { ChallengeDomain, PriorityLevel, ChallengeStatus } from '../types';

const JHARKHAND_DISTRICTS = [
  'All',
  'Ranchi', 'Bokaro', 'Dhanbad', 'Hazaribagh', 'Deoghar', 'Giridih',
  'East Singhbhum', 'Palamu', 'Dumka', 'West Singhbhum', 'Ramgarh',
  'Saraikela Kharsawan', 'Gumla', 'Latehar', 'Lohardaga', 'Simdega',
  'Khunti', 'Jamtara', 'Godda', 'Pakur', 'Sahibganj', 'Chatra',
  'Koderma', 'Garhwa'
];

const DOMAINS: (ChallengeDomain | 'All')[] = [
  'All',
  'Education',
  'Agriculture',
  'Healthcare',
  'Water Resources',
  'Environment',
  'Energy',
  'Urban Development',
  'Accessibility',
  'Public Administration',
  'Rural Livelihoods',
  'Sanitation',
  'Infrastructure',
];

export const ChallengesView: React.FC = () => {
  const { challenges, setSelectedChallenge, setIsSubmitModalOpen } = useApp();

  const [search, setSearch] = useState('');
  const [district, setDistrict] = useState('All');
  const [domain, setDomain] = useState('All');
  const [priority, setPriority] = useState('All');
  const [status, setStatus] = useState('All');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');

  const filtered = challenges.filter((c) => {
    const matchSearch =
      search.trim() === '' ||
      c.title.toLowerCase().includes(search.toLowerCase()) ||
      c.id.toLowerCase().includes(search.toLowerCase()) ||
      c.location.district.toLowerCase().includes(search.toLowerCase()) ||
      c.location.block.toLowerCase().includes(search.toLowerCase());

    const matchDistrict = district === 'All' || c.location.district.toLowerCase() === district.toLowerCase();
    const matchDomain = domain === 'All' || c.domain === domain;
    const matchPriority = priority === 'All' || c.aiAnalysis?.priorityLevel === priority;
    const matchStatus = status === 'All' || c.status === status;

    return matchSearch && matchDistrict && matchDomain && matchPriority && matchStatus;
  });

  return (
    <div className="space-y-6 animate-in fade-in">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900">
            Crowdsourced Civic Challenges ({filtered.length})
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Grassroots problems submitted by citizens and local bodies across Jharkhand's 24 districts.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <div className="flex border border-slate-200 rounded-lg overflow-hidden bg-white">
            <button
              onClick={() => setViewMode('grid')}
              className={`p-2 transition-colors ${
                viewMode === 'grid' ? 'bg-slate-100 text-slate-900' : 'text-slate-400 hover:text-slate-700'
              }`}
              title="Grid View"
            >
              <LayoutGrid className="w-4 h-4" />
            </button>
            <button
              onClick={() => setViewMode('list')}
              className={`p-2 transition-colors ${
                viewMode === 'list' ? 'bg-slate-100 text-slate-900' : 'text-slate-400 hover:text-slate-700'
              }`}
              title="List View"
            >
              <List className="w-4 h-4" />
            </button>
          </div>

          <button
            onClick={() => setIsSubmitModalOpen(true)}
            className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold rounded-lg shadow-xs flex items-center gap-1.5 transition-all"
          >
            <PlusCircle className="w-4 h-4" />
            <span>Submit Challenge</span>
          </button>
        </div>
      </div>

      {/* Filter & Search Bar */}
      <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-xs space-y-3">
        <div className="flex flex-col md:flex-row gap-3">
          {/* Search input */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search by title, challenge ID, district, or block..."
              className="w-full pl-9 pr-3 py-2 border border-slate-300 rounded-lg text-xs focus:ring-2 focus:ring-emerald-500 focus:outline-none"
            />
          </div>

          {/* District Selector */}
          <div className="w-full md:w-48">
            <select
              value={district}
              onChange={(e) => setDistrict(e.target.value)}
              className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs focus:ring-2 focus:ring-emerald-500 focus:outline-none"
            >
              {JHARKHAND_DISTRICTS.map((d) => (
                <option key={d} value={d}>
                  District: {d}
                </option>
              ))}
            </select>
          </div>

          {/* Domain Selector */}
          <div className="w-full md:w-48">
            <select
              value={domain}
              onChange={(e) => setDomain(e.target.value)}
              className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs focus:ring-2 focus:ring-emerald-500 focus:outline-none"
            >
              {DOMAINS.map((dom) => (
                <option key={dom} value={dom}>
                  Domain: {dom}
                </option>
              ))}
            </select>
          </div>

          {/* Priority */}
          <div className="w-full md:w-36">
            <select
              value={priority}
              onChange={(e) => setPriority(e.target.value)}
              className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs focus:ring-2 focus:ring-emerald-500 focus:outline-none"
            >
              <option value="All">Priority: All</option>
              <option value="Critical">Critical</option>
              <option value="High">High</option>
              <option value="Medium">Medium</option>
              <option value="Low">Low</option>
            </select>
          </div>

          {/* Status */}
          <div className="w-full md:w-40">
            <select
              value={status}
              onChange={(e) => setStatus(e.target.value)}
              className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs focus:ring-2 focus:ring-emerald-500 focus:outline-none"
            >
              <option value="All">Status: All</option>
              <option value="Submitted">Submitted</option>
              <option value="Under Validation">Under Validation</option>
              <option value="Validated">Validated</option>
              <option value="Assigned">Assigned</option>
              <option value="Project Started">Project Started</option>
              <option value="Completed">Completed</option>
            </select>
          </div>
        </div>

        {/* Quick filter pills */}
        <div className="flex items-center gap-2 text-xs text-slate-500 pt-1 border-t border-slate-100 overflow-x-auto no-scrollbar">
          <span className="font-semibold text-[11px] text-slate-400 uppercase">Quick Filter:</span>
          {['All', 'Critical', 'Water Resources', 'Agriculture', 'Healthcare', 'Education'].map((pill) => (
            <button
              key={pill}
              onClick={() => {
                if (pill === 'All') {
                  setDistrict('All');
                  setDomain('All');
                  setPriority('All');
                  setStatus('All');
                  setSearch('');
                } else if (pill === 'Critical') {
                  setPriority('Critical');
                } else {
                  setDomain(pill);
                }
              }}
              className="px-2 py-0.5 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-700 text-[11px] font-medium transition-colors whitespace-nowrap"
            >
              {pill}
            </button>
          ))}
        </div>
      </div>

      {/* Challenge Results */}
      {filtered.length === 0 ? (
        <div className="p-12 bg-white rounded-xl border border-slate-200 text-center space-y-3">
          <div className="w-12 h-12 rounded-full bg-slate-100 flex items-center justify-center mx-auto text-slate-400">
            <Search className="w-6 h-6" />
          </div>
          <h3 className="font-bold text-slate-800 text-base">No matching civic challenges found</h3>
          <p className="text-xs text-slate-500 max-w-md mx-auto">
            Try resetting your search query, choosing 'All' districts, or submit a new community problem.
          </p>
        </div>
      ) : viewMode === 'grid' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((c) => (
            <div
              key={c.id}
              onClick={() => setSelectedChallenge(c)}
              className="p-4 bg-white rounded-xl border border-slate-200 hover:border-emerald-500 hover:shadow-md transition-all cursor-pointer flex flex-col justify-between group shadow-xs"
            >
              <div>
                {/* Top badges */}
                <div className="flex items-center justify-between gap-2 mb-2">
                  <span className="text-[10px] font-mono font-bold bg-slate-100 text-slate-800 px-2 py-0.5 rounded border border-slate-200">
                    {c.id}
                  </span>

                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded border ${
                      c.aiAnalysis?.priorityLevel === 'Critical'
                        ? 'bg-red-50 text-red-700 border-red-200'
                        : c.aiAnalysis?.priorityLevel === 'High'
                        ? 'bg-amber-50 text-amber-800 border-amber-200'
                        : 'bg-blue-50 text-blue-700 border-blue-200'
                    }`}
                  >
                    {c.aiAnalysis?.priorityLevel || 'Normal'} ({c.aiAnalysis?.priorityScore || 70} pts)
                  </span>
                </div>

                <h4 className="text-sm font-bold text-slate-900 group-hover:text-emerald-900 line-clamp-2 leading-snug">
                  {c.title}
                </h4>

                <p className="text-xs text-slate-500 line-clamp-2 mt-1.5 leading-relaxed">
                  {c.detailedDescription}
                </p>

                {/* Domain & Location Tags */}
                <div className="mt-3 flex flex-wrap gap-1.5">
                  <span className="text-[10px] font-semibold bg-emerald-50 text-emerald-800 px-2 py-0.5 rounded border border-emerald-200">
                    {c.domain}
                  </span>
                  <span className="text-[10px] text-slate-600 bg-slate-100 px-2 py-0.5 rounded">
                    📍 {c.location.district} ({c.location.block})
                  </span>
                </div>
              </div>

              {/* Bottom Meta */}
              <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
                <div className="flex items-center gap-1">
                  <Users className="w-3.5 h-3.5 text-slate-400" />
                  <span>{c.affectedPopulation.toLocaleString()} affected</span>
                </div>

                <span
                  className={`font-semibold ${
                    c.status === 'Completed'
                      ? 'text-emerald-700'
                      : c.status === 'Project Started'
                      ? 'text-blue-700'
                      : c.status === 'Assigned'
                      ? 'text-purple-700'
                      : 'text-amber-700'
                  }`}
                >
                  {c.status}
                </span>
              </div>
            </div>
          ))}
        </div>
      ) : (
        /* List View */
        <div className="bg-white rounded-xl border border-slate-200 divide-y divide-slate-100 overflow-hidden shadow-xs">
          {filtered.map((c) => (
            <div
              key={c.id}
              onClick={() => setSelectedChallenge(c)}
              className="p-4 hover:bg-slate-50 transition-colors cursor-pointer flex flex-col md:flex-row md:items-center justify-between gap-3"
            >
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-[10px] font-mono font-bold bg-slate-100 text-slate-800 px-1.5 py-0.2 rounded">
                    {c.id}
                  </span>
                  <span className="text-[10px] font-semibold text-emerald-800 bg-emerald-100 px-1.5 py-0.2 rounded">
                    {c.domain}
                  </span>
                  <span className="text-xs text-slate-400">• {c.location.district} ({c.location.block})</span>
                </div>
                <h4 className="text-xs sm:text-sm font-bold text-slate-900 line-clamp-1">{c.title}</h4>
                <p className="text-xs text-slate-500 line-clamp-1 mt-0.5">{c.detailedDescription}</p>
              </div>

              <div className="flex items-center gap-4 flex-shrink-0">
                <div className="text-right hidden sm:block">
                  <span className="text-xs font-mono font-bold text-slate-900 block">
                    {c.affectedPopulation.toLocaleString()} Pop
                  </span>
                  <span className="text-[10px] text-slate-400">Direct citizens</span>
                </div>

                <span
                  className={`text-[11px] font-bold px-2 py-0.5 rounded ${
                    c.aiAnalysis?.priorityLevel === 'Critical'
                      ? 'bg-red-100 text-red-800'
                      : 'bg-amber-100 text-amber-800'
                  }`}
                >
                  {c.aiAnalysis?.priorityLevel || 'Medium'}
                </span>

                <span className="text-xs font-semibold text-slate-700 bg-slate-100 px-2.5 py-1 rounded-md">
                  {c.status}
                </span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
