/**
 * Home View - CivicBridge Jharkhand
 * High-impact governmental portal with live statistics, 5-step collaborative engine,
 * and featured grassroots innovation projects.
 */

import React from 'react';
import { useApp } from '../context/AppContext';
import {
  Sparkles,
  ArrowRight,
  ShieldCheck,
  Building2,
  GraduationCap,
  Briefcase,
  Layers,
  TrendingUp,
  MapPin,
  CheckCircle2,
  AlertTriangle,
  FileText,
  Users,
  Award,
} from 'lucide-react';

export const HomeView: React.FC = () => {
  const {
    overviewStats,
    challenges,
    projects,
    universities,
    industryPartners,
    setActiveTab,
    setIsSubmitModalOpen,
    setSelectedChallenge,
    setSelectedProject,
    startGuidedDemo,
    setIsPresentationModalOpen,
  } = useApp();

  const urgentChallenges = challenges
    .filter((c) => c.aiAnalysis?.priorityLevel === 'Critical' || c.aiAnalysis?.priorityLevel === 'High')
    .slice(0, 3);

  const featuredProjects = projects.slice(0, 3);

  return (
    <div className="space-y-8 animate-in fade-in">
      {/* Hero Section */}
      <section className="relative rounded-2xl bg-gradient-to-br from-slate-900 via-slate-950 to-emerald-950 text-white p-6 sm:p-10 md:p-12 overflow-hidden shadow-xl border border-slate-800">
        {/* Subtle decorative accents */}
        <div className="absolute top-0 right-0 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none"></div>
        <div className="absolute bottom-0 left-1/3 w-80 h-80 bg-teal-500/10 rounded-full blur-2xl pointer-events-none"></div>

        <div className="relative z-10 max-w-3xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-950/80 border border-emerald-500/30 text-emerald-300 text-xs font-semibold mb-4">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
            <span>SIH 2026 • Problem Statement ID: SIH26043</span>
            <span className="text-slate-400">|</span>
            <span className="text-slate-300">Govt. of Jharkhand</span>
          </div>

          <h1 className="text-2xl sm:text-4xl md:text-5xl font-black tracking-tight text-white leading-tight">
            Turn Grassroots Civic Challenges Into Real Engineering Solutions
          </h1>

          <p className="mt-4 text-sm sm:text-base text-slate-300 leading-relaxed max-w-2xl">
            A centralized digital innovation ecosystem connecting Jharkhand's citizens with 10+ premier technical universities, industry CSR co-funding, and government departments to solve acute regional challenges.
          </p>

          {/* Action CTAs */}
          <div className="mt-6 sm:mt-8 flex flex-wrap items-center gap-3">
            <button
              onClick={() => setIsSubmitModalOpen(true)}
              className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs sm:text-sm font-bold rounded-lg shadow-lg shadow-emerald-900/30 transition-all flex items-center gap-2"
            >
              <span>Submit a Community Challenge</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <button
              onClick={startGuidedDemo}
              className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-emerald-300 hover:text-white text-xs sm:text-sm font-semibold rounded-lg border border-slate-700 transition-all flex items-center gap-2"
            >
              <Sparkles className="w-4 h-4 text-emerald-400" />
              <span>2-Minute Guided Demo Tour</span>
            </button>

            <button
              onClick={() => setIsPresentationModalOpen(true)}
              className="px-3 py-2 text-xs text-slate-400 hover:text-white transition-colors"
            >
              View 5-Slide Pitch Deck →
            </button>
          </div>
        </div>
      </section>

      {/* Live State Statistics Row */}
      <section className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
        <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-xs">
          <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
            Reported Challenges
          </span>
          <span className="text-2xl font-black text-slate-900 mt-1 block font-mono">
            {overviewStats?.totalChallenges || challenges.length}
          </span>
          <span className="text-[10px] text-emerald-700 font-semibold mt-0.5 block">
            Across all 24 districts
          </span>
        </div>

        <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-xs">
          <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
            Government Validated
          </span>
          <span className="text-2xl font-black text-emerald-700 mt-1 block font-mono">
            {overviewStats?.validated || 18}
          </span>
          <span className="text-[10px] text-slate-500 mt-0.5 block">
            Audited by Dept of Higher Ed
          </span>
        </div>

        <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-xs">
          <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
            University Projects
          </span>
          <span className="text-2xl font-black text-blue-700 mt-1 block font-mono">
            {overviewStats?.activeProjectsCount || projects.length}
          </span>
          <span className="text-[10px] text-slate-500 mt-0.5 block">
            10 Institutions active
          </span>
        </div>

        <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-xs">
          <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
            CSR Capital Pledged
          </span>
          <span className="text-2xl font-black text-amber-700 mt-1 block font-mono">
            ₹{((overviewStats?.totalPledgedInRupees || 2150000) / 100000).toFixed(1)} Lakh
          </span>
          <span className="text-[10px] text-slate-500 mt-0.5 block">
            Tata Steel, CCL & Industry
          </span>
        </div>

        <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-xs col-span-2 sm:col-span-1">
          <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
            Population Impacted
          </span>
          <span className="text-2xl font-black text-purple-700 mt-1 block font-mono">
            {(overviewStats?.totalAffectedPopulation || 65000).toLocaleString()}
          </span>
          <span className="text-[10px] text-emerald-600 font-semibold mt-0.5 block">
            Direct beneficiaries
          </span>
        </div>
      </section>

      {/* 5-Step Collaborative Innovation Engine */}
      <section className="bg-white rounded-2xl border border-slate-200 p-6 sm:p-8 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-6 gap-2">
          <div>
            <span className="text-[11px] font-bold uppercase tracking-widest text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
              How CivicBridge Operates
            </span>
            <h2 className="text-xl sm:text-2xl font-black text-slate-900 mt-1.5">
              The 5-Stakeholder Collaborative Innovation Lifecycle
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              From grassroots complaint to deployed technological asset with verifiable societal impact.
            </p>
          </div>

          <button
            onClick={() => setActiveTab('challenges')}
            className="text-xs font-bold text-emerald-700 hover:text-emerald-800 flex items-center gap-1 self-start"
          >
            <span>Explore All Challenges</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
          {[
            {
              step: '1',
              title: 'Citizens & PRIs',
              desc: 'Villagers, Panchayats & ULBs submit problems with photos, GPS coordinates, and affected population data.',
              icon: MapPin,
              color: 'emerald',
            },
            {
              step: '2',
              title: 'AI Triage Engine',
              desc: 'Deterministic domain classification, multi-factor priority scoring (0-100), and semantic duplicate clustering.',
              icon: Sparkles,
              color: 'teal',
            },
            {
              step: '3',
              title: 'Government Desk',
              desc: 'State department validates problem authenticity, logs any overrides into audit trail, and routes to universities.',
              icon: Building2,
              color: 'blue',
            },
            {
              step: '4',
              title: 'University Labs',
              desc: 'Faculty lead & cross-department students (CS, Civil, IoT, Agri) assemble and submit solution proposals.',
              icon: GraduationCap,
              color: 'purple',
            },
            {
              step: '5',
              title: 'Industry & Impact',
              desc: 'Corporate CSR provides co-funding & equipment. Project is deployed with verifiable Before vs. After metrics.',
              icon: TrendingUp,
              color: 'amber',
            },
          ].map((item) => {
            const Icon = item.icon;
            return (
              <div
                key={item.step}
                className="p-4 rounded-xl bg-slate-50 border border-slate-200 flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <span className="w-6 h-6 rounded-full bg-slate-900 text-white flex items-center justify-center font-bold text-xs">
                      {item.step}
                    </span>
                    <Icon className="w-4 h-4 text-emerald-700" />
                  </div>
                  <h4 className="font-bold text-slate-900 text-sm">{item.title}</h4>
                  <p className="text-xs text-slate-600 mt-1 leading-relaxed">{item.desc}</p>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* Featured Urgent Challenges & Active Projects (Two Columns) */}
      <section className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Urgent Civic Challenges */}
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <AlertTriangle className="w-5 h-5 text-red-600" />
                <h3 className="font-bold text-slate-900 text-base">Priority Civic Challenges</h3>
              </div>
              <button
                onClick={() => setActiveTab('challenges')}
                className="text-xs font-semibold text-emerald-700 hover:text-emerald-800"
              >
                View all ({challenges.length})
              </button>
            </div>

            <div className="space-y-3">
              {urgentChallenges.map((c) => (
                <div
                  key={c.id}
                  onClick={() => setSelectedChallenge(c)}
                  className="p-3.5 rounded-xl border border-slate-200 hover:border-emerald-500 hover:bg-emerald-50/20 transition-all cursor-pointer group shadow-xs"
                >
                  <div className="flex items-center justify-between gap-2 mb-1">
                    <div className="flex items-center gap-1.5">
                      <span className="text-[10px] font-mono font-bold bg-slate-100 text-slate-800 px-1.5 py-0.2 rounded">
                        {c.id}
                      </span>
                      <span className="text-[10px] font-semibold text-emerald-800 bg-emerald-100 px-1.5 py-0.2 rounded">
                        {c.domain}
                      </span>
                    </div>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-red-100 text-red-800 border border-red-200">
                      {c.aiAnalysis?.priorityLevel || 'High'} ({c.aiAnalysis?.priorityScore || 85} pts)
                    </span>
                  </div>

                  <h4 className="text-xs font-bold text-slate-900 group-hover:text-emerald-900 line-clamp-1">
                    {c.title}
                  </h4>
                  <p className="text-[11px] text-slate-500 line-clamp-2 mt-0.5">
                    {c.detailedDescription}
                  </p>

                  <div className="mt-2.5 flex items-center justify-between text-[10px] text-slate-400">
                    <span>
                      {c.location.district} ({c.location.block}) • Pop: {c.affectedPopulation.toLocaleString()}
                    </span>
                    <span className="text-emerald-600 font-semibold group-hover:underline">
                      Inspect Dossier →
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Active Multidisciplinary Innovation Projects */}
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <GraduationCap className="w-5 h-5 text-emerald-700" />
                <h3 className="font-bold text-slate-900 text-base">Active University Deployments</h3>
              </div>
              <button
                onClick={() => setActiveTab('projects')}
                className="text-xs font-semibold text-emerald-700 hover:text-emerald-800"
              >
                View all ({projects.length})
              </button>
            </div>

            <div className="space-y-3">
              {featuredProjects.map((p) => (
                <div
                  key={p.id}
                  onClick={() => setSelectedProject(p)}
                  className="p-3.5 rounded-xl border border-slate-200 hover:border-emerald-500 hover:bg-emerald-50/20 transition-all cursor-pointer group shadow-xs"
                >
                  <div className="flex items-center justify-between gap-2 mb-1">
                    <span className="text-[10px] font-mono font-bold bg-slate-100 text-slate-800 px-1.5 py-0.2 rounded">
                      {p.id}
                    </span>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-blue-100 text-blue-800">
                      Stage: {p.stage}
                    </span>
                  </div>

                  <h4 className="text-xs font-bold text-slate-900 group-hover:text-emerald-900 line-clamp-1">
                    {p.title}
                  </h4>
                  <p className="text-[11px] text-emerald-800 font-medium mt-0.5">
                    {p.universityName} • Lead: {p.leadFaculty.name}
                  </p>

                  {/* Progress bar */}
                  <div className="mt-2">
                    <div className="flex items-center justify-between text-[10px] text-slate-500 mb-1">
                      <span>Overall Milestone Progress</span>
                      <span className="font-mono font-bold text-slate-900">{p.overallProgress}%</span>
                    </div>
                    <div className="w-full bg-slate-100 rounded-full h-1.5 overflow-hidden">
                      <div
                        className="bg-emerald-600 h-full rounded-full transition-all"
                        style={{ width: `${p.overallProgress}%` }}
                      ></div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Participating Institutions & Industry Logos */}
      <section className="bg-slate-900 text-white rounded-2xl p-6 sm:p-8 border border-slate-800 shadow-sm">
        <div className="text-center max-w-2xl mx-auto mb-6">
          <span className="text-[11px] font-bold uppercase tracking-widest text-emerald-400">
            Jharkhand Innovation Ecosystem
          </span>
          <h3 className="text-lg sm:text-xl font-black text-white mt-1">
            Empowered by Premier Academic Institutions & Leading Industry Partners
          </h3>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 gap-3 text-center">
          {[
            'BIT Mesra',
            'IIT (ISM) Dhanbad',
            'NIT Jamshedpur',
            'Birsa Agricultural University',
            'Ranchi University',
            'Tata Steel',
            'Central Coalfields Ltd',
            'SAIL Bokaro',
            'Jindal Steel & Power',
            'Usha Martin',
            'AIIMS Deoghar',
            'IIIT Ranchi',
          ].map((inst) => (
            <div
              key={inst}
              className="p-3 rounded-lg bg-slate-800/80 border border-slate-700/60 text-xs font-bold text-slate-200 flex items-center justify-center min-h-[48px]"
            >
              {inst}
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};
