/**
 * Projects View - 12-Stage Innovation Lifecycle Tracker
 * Tracks multidisciplinary engineering teams, milestone deliverables,
 * proposals, and field pilots.
 */

import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  Layers,
  GraduationCap,
  Users,
  CheckCircle2,
  Clock,
  Flag,
  FileText,
  TrendingUp,
  AlertCircle,
  ExternalLink,
  PlusCircle,
  HeartHandshake,
} from 'lucide-react';
import { Project, Milestone } from '../types';

export const ProjectsView: React.FC = () => {
  const {
    projects,
    selectedProject,
    setSelectedProject,
    setIsMilestoneModalOpen,
    setIsProposalModalOpen,
    setIsImpactModalOpen,
    setIsPledgeModalOpen,
    setActiveEntityForModal,
  } = useApp();

  const currentProject = selectedProject || projects[0];

  const handleEditMilestone = (p: Project, m: Milestone) => {
    setActiveEntityForModal({ project: p, milestone: m });
    setIsMilestoneModalOpen(true);
  };

  const handleOpenProposal = (p: Project) => {
    setActiveEntityForModal(p);
    setIsProposalModalOpen(true);
  };

  const handleOpenImpact = (p: Project) => {
    setActiveEntityForModal(p);
    setIsImpactModalOpen(true);
  };

  const handleOpenPledge = (p: Project) => {
    setActiveEntityForModal(p);
    setIsPledgeModalOpen(true);
  };

  return (
    <div className="space-y-6 animate-in fade-in">
      {/* Top Banner */}
      <div className="p-6 bg-slate-900 text-white rounded-2xl border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-sm">
        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-xl bg-blue-600 flex items-center justify-center text-white font-bold shadow-md">
            <Layers className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold uppercase tracking-wider text-blue-400">
                12-Stage Innovation Lifecycle Engine
              </span>
              <span className="text-[10px] bg-slate-800 text-slate-300 px-2 py-0.5 rounded font-mono">
                {projects.length} Multidisciplinary Projects Active
              </span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-white mt-1">
              Field Innovation & Prototyping Pipeline
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Tracking research teams from problem definition to hardware testing, pilot verification, and community handover.
            </p>
          </div>
        </div>

        <div className="text-right">
          <span className="text-2xl font-black text-emerald-400 font-mono">
            {projects.filter((p) => p.stage === 'Completed').length}
          </span>
          <span className="block text-[10px] font-semibold text-slate-400 uppercase">
            Completed Deployments
          </span>
        </div>
      </div>

      {/* Grid: Project Selector and Detailed Project Dashboard */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Project Selector List */}
        <div className="lg:col-span-4 bg-white rounded-2xl border border-slate-200 p-4 shadow-xs space-y-2.5 max-h-[750px] overflow-y-auto">
          <span className="text-xs font-bold text-slate-500 uppercase tracking-wider px-1">
            Projects Roster ({projects.length})
          </span>

          {projects.map((p) => {
            const isSelected = currentProject?.id === p.id;
            return (
              <div
                key={p.id}
                onClick={() => setSelectedProject(p)}
                className={`p-3.5 rounded-xl border text-xs cursor-pointer transition-all ${
                  isSelected
                    ? 'border-blue-600 bg-blue-50/60 shadow-xs ring-1 ring-blue-500'
                    : 'border-slate-200 hover:border-slate-300 bg-white'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="font-mono font-bold text-slate-700 bg-slate-100 px-1.5 py-0.2 rounded">
                    {p.id}
                  </span>
                  <span className="font-bold text-[10px] px-2 py-0.5 rounded bg-blue-100 text-blue-800">
                    {p.stage}
                  </span>
                </div>

                <h4 className="font-bold text-slate-900 line-clamp-1">{p.title}</h4>
                <p className="text-[11px] text-slate-500 mt-0.5">{p.universityName}</p>

                {/* Progress Bar */}
                <div className="mt-2.5">
                  <div className="flex justify-between text-[10px] text-slate-500 mb-1">
                    <span>Milestones Progress</span>
                    <span className="font-mono font-bold text-slate-900">{p.overallProgress}%</span>
                  </div>
                  <div className="w-full bg-slate-200 rounded-full h-1.5 overflow-hidden">
                    <div
                      className="bg-blue-600 h-full rounded-full transition-all"
                      style={{ width: `${p.overallProgress}%` }}
                    ></div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Right: Detailed Project Dossier */}
        {currentProject && (
          <div className="lg:col-span-8 bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-6">
            {/* Header info */}
            <div className="flex flex-col sm:flex-row sm:items-start justify-between border-b border-slate-100 pb-4 gap-3">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <span className="font-mono font-bold text-blue-800 bg-blue-50 px-2 py-0.5 rounded border border-blue-200 text-xs">
                    {currentProject.id}
                  </span>
                  <span className="font-bold text-xs bg-slate-900 text-white px-2 py-0.5 rounded">
                    Stage: {currentProject.stage}
                  </span>
                </div>
                <h3 className="text-lg font-black text-slate-900">{currentProject.title}</h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Institution: <strong>{currentProject.universityName}</strong> • Target Date:{' '}
                  {currentProject.targetCompletionDate}
                </p>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-wrap items-center gap-2">
                <button
                  onClick={() => handleOpenProposal(currentProject)}
                  className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold rounded-lg flex items-center gap-1 transition-colors"
                >
                  <FileText className="w-3.5 h-3.5" />
                  <span>Solution Proposal</span>
                </button>

                <button
                  onClick={() => handleOpenPledge(currentProject)}
                  className="px-3 py-1.5 bg-amber-50 hover:bg-amber-100 text-amber-900 text-xs font-bold rounded-lg border border-amber-200 flex items-center gap-1 transition-colors"
                >
                  <HeartHandshake className="w-3.5 h-3.5 text-amber-700" />
                  <span>Industry CSR</span>
                </button>

                <button
                  onClick={() => handleOpenImpact(currentProject)}
                  className="px-3.5 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold rounded-lg flex items-center gap-1 transition-colors shadow-xs"
                >
                  <TrendingUp className="w-3.5 h-3.5" />
                  <span>Verify Impact</span>
                </button>
              </div>
            </div>

            {/* Overall Milestone Completion Banner */}
            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                  Lifecycle Progress & Stage Governance
                </span>
                <span className="text-sm font-mono font-black text-blue-700">
                  {currentProject.overallProgress}% Complete
                </span>
              </div>
              <div className="w-full bg-slate-200 rounded-full h-2.5 overflow-hidden">
                <div
                  className="bg-blue-600 h-full rounded-full transition-all"
                  style={{ width: `${currentProject.overallProgress}%` }}
                ></div>
              </div>
            </div>

            {/* Multidisciplinary Team Composition */}
            <div className="space-y-3">
              <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
                <Users className="w-4 h-4 text-emerald-700" />
                <span>Multidisciplinary Engineering Team Composition</span>
              </h4>

              {/* Lead Faculty Mentor */}
              <div className="p-3 bg-emerald-50/70 border border-emerald-200 rounded-xl text-xs flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div>
                  <span className="text-[10px] font-bold text-emerald-800 uppercase block">
                    Principal Faculty Lead
                  </span>
                  <span className="font-bold text-slate-900 text-sm">{currentProject.leadFaculty.name}</span>
                  <p className="text-slate-600 text-[11px]">
                    {currentProject.leadFaculty.designation} • {currentProject.leadFaculty.department}
                  </p>
                </div>
                <span className="text-[11px] text-slate-500 font-mono">
                  {currentProject.leadFaculty.email}
                </span>
              </div>

              {/* Student Team Across Departments */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {currentProject.studentTeam.map((st) => (
                  <div
                    key={st.id}
                    className="p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs flex flex-col justify-between"
                  >
                    <div>
                      <div className="flex items-center justify-between mb-0.5">
                        <span className="font-bold text-slate-900">{st.name}</span>
                        <span className="text-[10px] font-bold bg-blue-100 text-blue-800 px-1.5 py-0.2 rounded">
                          {st.department}
                        </span>
                      </div>
                      <p className="text-[10px] text-slate-500">{st.yearOfStudy}</p>
                    </div>
                    <div className="mt-2 flex flex-wrap gap-1">
                      {st.skills.map((sk, idx) => (
                        <span key={idx} className="text-[9px] bg-white border border-slate-200 px-1 py-0.2 rounded text-slate-600">
                          {sk}
                        </span>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Milestones Checklist */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
                  <Flag className="w-4 h-4 text-blue-700" />
                  <span>Milestones & Field Deliverables ({currentProject.milestones.length})</span>
                </h4>
                <span className="text-[11px] text-slate-400">Click any milestone to record updates</span>
              </div>

              <div className="space-y-2">
                {currentProject.milestones.map((m) => (
                  <div
                    key={m.id}
                    onClick={() => handleEditMilestone(currentProject, m)}
                    className="p-3.5 rounded-xl border border-slate-200 hover:border-blue-500 hover:bg-blue-50/20 transition-all cursor-pointer text-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-xs"
                  >
                    <div className="flex items-start gap-3">
                      <div
                        className={`w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5 ${
                          m.status === 'Completed'
                            ? 'bg-emerald-600 text-white'
                            : m.status === 'In Progress'
                            ? 'bg-blue-600 text-white'
                            : 'bg-slate-200 text-slate-600'
                        }`}
                      >
                        {m.status === 'Completed' ? (
                          <CheckCircle2 className="w-4 h-4" />
                        ) : (
                          <span className="text-[10px] font-bold">{m.progressPercent}%</span>
                        )}
                      </div>

                      <div>
                        <div className="flex items-center gap-2">
                          <h5 className="font-bold text-slate-900">{m.title}</h5>
                          <span
                            className={`text-[10px] font-bold px-1.5 py-0.2 rounded ${
                              m.status === 'Completed'
                                ? 'bg-emerald-100 text-emerald-800'
                                : m.status === 'In Progress'
                                ? 'bg-blue-100 text-blue-800'
                                : 'bg-slate-100 text-slate-600'
                            }`}
                          >
                            {m.status}
                          </span>
                        </div>
                        <p className="text-slate-500 mt-0.5">{m.description}</p>
                        {m.evidenceNotes && (
                          <p className="text-[11px] text-emerald-700 mt-1 font-medium">
                            Deliverable: {m.evidenceNotes}
                          </p>
                        )}
                      </div>
                    </div>

                    <div className="text-right flex-shrink-0 self-start sm:self-center">
                      <span className="text-[10px] text-slate-400 block">Due Date</span>
                      <span className="font-mono text-slate-700 font-semibold">{m.targetDueDate}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
