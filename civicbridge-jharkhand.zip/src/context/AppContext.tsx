/**
 * Global Application State for CivicBridge Jharkhand
 */

import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import {
  User,
  Challenge,
  University,
  Project,
  IndustryPartner,
  AppNotification,
  OverviewStats,
} from '../types';
import * as api from '../api';

export type ActiveNavTab =
  | 'home'
  | 'challenges'
  | 'government'
  | 'university'
  | 'industry'
  | 'projects'
  | 'impact'
  | 'map'
  | 'analytics'
  | 'about';

interface AppContextType {
  currentUser: User | null;
  allPersonas: User[];
  activeTab: ActiveNavTab;
  setActiveTab: (tab: ActiveNavTab) => void;
  challenges: Challenge[];
  universities: University[];
  projects: Project[];
  industryPartners: IndustryPartner[];
  notifications: AppNotification[];
  unreadCount: number;
  overviewStats: OverviewStats | null;
  selectedChallenge: Challenge | null;
  selectedProject: Project | null;
  setSelectedChallenge: (c: Challenge | null) => void;
  setSelectedProject: (p: Project | null) => void;
  isSubmitModalOpen: boolean;
  setIsSubmitModalOpen: (open: boolean) => void;
  isTeamBuilderModalOpen: boolean;
  setIsTeamBuilderModalOpen: (open: boolean) => void;
  isProposalModalOpen: boolean;
  setIsProposalModalOpen: (open: boolean) => void;
  isMilestoneModalOpen: boolean;
  setIsMilestoneModalOpen: (open: boolean) => void;
  isImpactModalOpen: boolean;
  setIsImpactModalOpen: (open: boolean) => void;
  isPledgeModalOpen: boolean;
  setIsPledgeModalOpen: (open: boolean) => void;
  isPresentationModalOpen: boolean;
  setIsPresentationModalOpen: (open: boolean) => void;
  activeEntityForModal: any;
  setActiveEntityForModal: (entity: any) => void;
  guidedDemoActive: boolean;
  guidedDemoStep: number;
  startGuidedDemo: () => void;
  exitGuidedDemo: () => void;
  nextDemoStep: () => void;
  prevDemoStep: () => void;
  refreshAllData: () => Promise<void>;
  switchUserPersona: (roleOrId: string) => Promise<void>;
  toastMessage: string | null;
  showToast: (msg: string) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [allPersonas, setAllPersonas] = useState<User[]>([]);
  const [activeTab, setActiveTab] = useState<ActiveNavTab>('home');
  const [challenges, setChallenges] = useState<Challenge[]>([]);
  const [universities, setUniversities] = useState<University[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [industryPartners, setIndustryPartners] = useState<IndustryPartner[]>([]);
  const [notifications, setNotifications] = useState<AppNotification[]>([]);
  const [unreadCount, setUnreadCount] = useState<number>(0);
  const [overviewStats, setOverviewStats] = useState<OverviewStats | null>(null);

  const [selectedChallenge, setSelectedChallenge] = useState<Challenge | null>(null);
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);

  // Modals
  const [isSubmitModalOpen, setIsSubmitModalOpen] = useState(false);
  const [isTeamBuilderModalOpen, setIsTeamBuilderModalOpen] = useState(false);
  const [isProposalModalOpen, setIsProposalModalOpen] = useState(false);
  const [isMilestoneModalOpen, setIsMilestoneModalOpen] = useState(false);
  const [isImpactModalOpen, setIsImpactModalOpen] = useState(false);
  const [isPledgeModalOpen, setIsPledgeModalOpen] = useState(false);
  const [isPresentationModalOpen, setIsPresentationModalOpen] = useState(false);
  const [activeEntityForModal, setActiveEntityForModal] = useState<any>(null);

  // Guided 2-Minute SIH Demo Tour
  const [guidedDemoActive, setGuidedDemoActive] = useState(false);
  const [guidedDemoStep, setGuidedDemoStep] = useState(0);

  // Toast notification
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((current) => (current === msg ? null : current));
    }, 4000);
  };

  const refreshAllData = async () => {
    try {
      const [meRes, personasRes, chalRes, uniRes, projRes, indRes, notifRes, statsRes] =
        await Promise.all([
          api.fetchMe(),
          api.fetchPersonas(),
          api.fetchChallenges(),
          api.fetchUniversities(),
          api.fetchProjects(),
          api.fetchIndustryPartners(),
          api.fetchNotifications(),
          api.fetchOverviewAnalytics(),
        ]);

      if (meRes.user) setCurrentUser(meRes.user);
      if (personasRes.users) setAllPersonas(personasRes.users);
      if (chalRes.challenges) setChallenges(chalRes.challenges);
      if (uniRes.universities) setUniversities(uniRes.universities);
      if (projRes.projects) setProjects(projRes.projects);
      if (indRes.industryPartners) setIndustryPartners(indRes.industryPartners);
      if (notifRes.notifications) {
        setNotifications(notifRes.notifications);
        setUnreadCount(notifRes.unreadCount || 0);
      }
      if (statsRes.overview) setOverviewStats(statsRes.overview);

      // Keep active selections fresh
      if (selectedChallenge) {
        const freshC = chalRes.challenges?.find((c) => c.id === selectedChallenge.id);
        if (freshC) setSelectedChallenge(freshC);
      }
      if (selectedProject) {
        const freshP = projRes.projects?.find((p) => p.id === selectedProject.id);
        if (freshP) setSelectedProject(freshP);
      }
    } catch (err) {
      console.error('Error fetching CivicBridge data:', err);
    }
  };

  useEffect(() => {
    refreshAllData();
    const interval = setInterval(refreshAllData, 12000); // Polling for live notifications and updates
    return () => clearInterval(interval);
  }, []);

  const switchUserPersona = async (roleOrId: string) => {
    try {
      const res = await api.switchRole(roleOrId);
      if (res.success && res.user) {
        setCurrentUser(res.user);
        showToast(`Switched active persona to ${res.user.name} (${res.user.role})`);
        await refreshAllData();
      }
    } catch (err) {
      console.error('Failed to switch persona:', err);
    }
  };

  const startGuidedDemo = () => {
    setGuidedDemoActive(true);
    setGuidedDemoStep(0);
    setActiveTab('home');
  };

  const exitGuidedDemo = () => {
    setGuidedDemoActive(false);
    setGuidedDemoStep(0);
  };

  const nextDemoStep = () => {
    const next = guidedDemoStep + 1;
    if (next > 7) {
      setGuidedDemoActive(false);
      setGuidedDemoStep(0);
      return;
    }
    setGuidedDemoStep(next);

    // Contextual tab routing for each demo stage
    switch (next) {
      case 1: // Citizen problem overview
        setActiveTab('challenges');
        break;
      case 2: // Citizen submit
        switchUserPersona('usr-citizen-01');
        setIsSubmitModalOpen(true);
        break;
      case 3: // AI Analysis & Government Review
        setIsSubmitModalOpen(false);
        switchUserPersona('usr-gov-01');
        setActiveTab('government');
        break;
      case 4: // University matching & Multidisciplinary Team
        switchUserPersona('usr-uni-admin-01');
        setActiveTab('university');
        break;
      case 5: // Industry partner CSR & Mentorship
        switchUserPersona('usr-ind-01');
        setActiveTab('industry');
        break;
      case 6: // Project milestones & active deployment
        setActiveTab('projects');
        break;
      case 7: // Measurable impact dashboard
        setActiveTab('impact');
        break;
      default:
        break;
    }
  };

  const prevDemoStep = () => {
    const prev = Math.max(0, guidedDemoStep - 1);
    setGuidedDemoStep(prev);
  };

  return (
    <AppContext.Provider
      value={{
        currentUser,
        allPersonas,
        activeTab,
        setActiveTab,
        challenges,
        universities,
        projects,
        industryPartners,
        notifications,
        unreadCount,
        overviewStats,
        selectedChallenge,
        selectedProject,
        setSelectedChallenge,
        setSelectedProject,
        isSubmitModalOpen,
        setIsSubmitModalOpen,
        isTeamBuilderModalOpen,
        setIsTeamBuilderModalOpen,
        isProposalModalOpen,
        setIsProposalModalOpen,
        isMilestoneModalOpen,
        setIsMilestoneModalOpen,
        isImpactModalOpen,
        setIsImpactModalOpen,
        isPledgeModalOpen,
        setIsPledgeModalOpen,
        isPresentationModalOpen,
        setIsPresentationModalOpen,
        activeEntityForModal,
        setActiveEntityForModal,
        guidedDemoActive,
        guidedDemoStep,
        startGuidedDemo,
        exitGuidedDemo,
        nextDemoStep,
        prevDemoStep,
        refreshAllData,
        switchUserPersona,
        toastMessage,
        showToast,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used within AppProvider');
  return ctx;
};
