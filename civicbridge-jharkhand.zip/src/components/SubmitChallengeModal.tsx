/**
 * Citizen Challenge Submission Modal
 * Multi-step submission with GPS auto-detection and file attachments
 */

import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  X,
  Upload,
  MapPin,
  Sparkles,
  CheckCircle2,
  FileText,
  AlertCircle,
  HelpCircle,
  FileCheck,
} from 'lucide-react';
import * as api from '../api';
import { ChallengeDomain } from '../types';

const JHARKHAND_DISTRICTS = [
  'Ranchi', 'Bokaro', 'Dhanbad', 'Hazaribagh', 'Deoghar', 'Giridih',
  'East Singhbhum', 'Palamu', 'Dumka', 'West Singhbhum', 'Ramgarh',
  'Saraikela Kharsawan', 'Gumla', 'Latehar', 'Lohardaga', 'Simdega',
  'Khunti', 'Jamtara', 'Godda', 'Pakur', 'Sahibganj', 'Chatra',
  'Koderma', 'Garhwa'
];

const DOMAINS: ChallengeDomain[] = [
  'Education',
  'Agriculture',
  'Healthcare',
  'Water Resources',
  'Environment',
  'Energy',
  'Urban Development',
  'Accessibility',
  'Public Administration',
  'Rural Livelihoods',
  'Sanitation',
  'Infrastructure',
];

export const SubmitChallengeModal: React.FC = () => {
  const { isSubmitModalOpen, setIsSubmitModalOpen, currentUser, refreshAllData, showToast } = useApp();

  const [step, setStep] = useState(1);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Form State
  const [title, setTitle] = useState('');
  const [detailedDescription, setDetailedDescription] = useState('');
  const [domain, setDomain] = useState<ChallengeDomain>('Water Resources');
  const [district, setDistrict] = useState('Ranchi');
  const [block, setBlock] = useState('Sadar');
  const [villageOrCity, setVillageOrCity] = useState('');
  const [affectedPopulation, setAffectedPopulation] = useState(500);
  const [urgency, setUrgency] = useState<'Low' | 'Medium' | 'High' | 'Emergency'>('High');
  const [expectedOutcome, setExpectedOutcome] = useState('');
  const [availableResources, setAvailableResources] = useState('');
  const [contactName, setContactName] = useState(currentUser?.name || 'Sunita Soren');
  const [contactPhone, setContactPhone] = useState(currentUser?.phone || '+91 94311 88290');
  const [contactEmail, setContactEmail] = useState(currentUser?.email || 'sunita.soren@jharkhandcivic.org');
  const [gpsCoordinates, setGpsCoordinates] = useState({ latitude: 23.3441, longitude: 85.3096 });
  const [isDetectingGps, setIsDetectingGps] = useState(false);

  // Attachment files simulation
  const [mediaList, setMediaList] = useState<any[]>([
    {
      id: 'med-1',
      name: 'field_inspection_site_photo.jpg',
      type: 'image',
      url: 'https://images.unsplash.com/photo-1578328819058-b69f3a3b0f6b?auto=format&fit=crop&w=600&q=80',
      sizeBytes: 1024 * 750,
      uploadedAt: new Date().toISOString(),
    },
  ]);
  const [uploadProgress, setUploadProgress] = useState<number | null>(null);

  if (!isSubmitModalOpen) return null;

  const handleDetectGps = () => {
    setIsDetectingGps(true);
    if ('geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          setGpsCoordinates({
            latitude: Number(pos.coords.latitude.toFixed(4)),
            longitude: Number(pos.coords.longitude.toFixed(4)),
          });
          setIsDetectingGps(false);
          showToast('GPS coordinates acquired from browser');
        },
        () => {
          // Fallback to Ranchi center coordinates
          setGpsCoordinates({ latitude: 23.3441, longitude: 85.3096 });
          setIsDetectingGps(false);
          showToast('Using Jharkhand District Geolocation');
        }
      );
    } else {
      setIsDetectingGps(false);
      showToast('Geolocation not available in browser');
    }
  };

  const handleSimulateFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    setUploadProgress(20);
    const interval = setInterval(() => {
      setUploadProgress((prev) => {
        if (prev === null) return 50;
        if (prev >= 100) {
          clearInterval(interval);
          setMediaList((existing) => [
            ...existing,
            {
              id: `med-${Date.now()}`,
              name: files[0].name,
              type: files[0].type.includes('image') ? 'image' : 'document',
              url: 'https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?auto=format&fit=crop&w=600&q=80',
              sizeBytes: files[0].size,
              uploadedAt: new Date().toISOString(),
            },
          ]);
          showToast(`Attached ${files[0].name}`);
          return null;
        }
        return prev + 30;
      });
    }, 200);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !detailedDescription || !district || !block) {
      showToast('Please fill in all mandatory challenge details');
      return;
    }

    setIsSubmitting(true);
    try {
      const res = await api.submitChallenge({
        title,
        detailedDescription,
        domain,
        district,
        block,
        villageOrCity,
        affectedPopulation,
        urgency,
        expectedOutcome,
        availableResources,
        contactName,
        contactPhone,
        contactEmail,
        media: mediaList,
        gpsCoordinates,
      });

      if (res.success && res.challenge) {
        showToast(`Challenge ${res.challenge.id} registered successfully! AI analysis complete.`);
        setIsSubmitModalOpen(false);
        await refreshAllData();
      } else {
        showToast('Failed to submit challenge');
      }
    } catch (err: any) {
      showToast(err.message || 'Error occurred during submission');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-xl shadow-2xl border border-slate-200 w-full max-w-2xl overflow-hidden animate-in fade-in zoom-in-95">
        {/* Modal Header */}
        <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-600 flex items-center justify-center text-white font-bold">
              <MapPin className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-bold">Submit a Community Challenge</h3>
              <p className="text-xs text-slate-300">
                CivicBridge Jharkhand • Crowdsourcing grassroots problems for university solutions
              </p>
            </div>
          </div>
          <button
            onClick={() => setIsSubmitModalOpen(false)}
            className="p-1 rounded-md text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Step Indicator */}
        <div className="bg-slate-50 border-b border-slate-200 px-6 py-3 flex items-center justify-between">
          {[
            { num: 1, label: 'Problem Details' },
            { num: 2, label: 'Location & Urgency' },
            { num: 3, label: 'Evidence & Attachments' },
          ].map((s) => (
            <div key={s.num} className="flex items-center gap-2">
              <span
                className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${
                  step === s.num
                    ? 'bg-emerald-700 text-white'
                    : step > s.num
                    ? 'bg-emerald-100 text-emerald-800'
                    : 'bg-slate-200 text-slate-600'
                }`}
              >
                {step > s.num ? '✓' : s.num}
              </span>
              <span className={`text-xs font-semibold ${step === s.num ? 'text-slate-900' : 'text-slate-500'}`}>
                {s.label}
              </span>
            </div>
          ))}
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4 max-h-[70vh] overflow-y-auto">
          {/* STEP 1: Problem Details */}
          {step === 1 && (
            <div className="space-y-4 animate-in fade-in">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Challenge Title *
                </label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g., Severe Fluoride Contamination in Handpumps of 3 Villages in Daltonganj"
                  className="w-full px-3 py-2 border border-slate-300 rounded-md text-sm focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Primary Domain / Sector *
                  </label>
                  <select
                    value={domain}
                    onChange={(e) => setDomain(e.target.value as ChallengeDomain)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-md text-sm focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  >
                    {DOMAINS.map((d) => (
                      <option key={d} value={d}>
                        {d}
                      </option>
                    ))}
                  </select>
                  <span className="text-[10px] text-slate-400 mt-1 block">
                    Our AI classifier will also review and verify domain taxonomy.
                  </span>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Estimated Affected Population *
                  </label>
                  <input
                    type="number"
                    min="1"
                    required
                    value={affectedPopulation}
                    onChange={(e) => setAffectedPopulation(Number(e.target.value))}
                    className="w-full px-3 py-2 border border-slate-300 rounded-md text-sm focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  />
                  <span className="text-[10px] text-slate-400 mt-1 block">
                    Total villagers, students, or citizens directly impacted.
                  </span>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Detailed Problem Description *
                </label>
                <textarea
                  required
                  rows={4}
                  value={detailedDescription}
                  onChange={(e) => setDetailedDescription(e.target.value)}
                  placeholder="Describe the exact ground reality: what is happening, what fails with the current setup, what health or economic consequences occur, and what technical help is needed..."
                  className="w-full px-3 py-2 border border-slate-300 rounded-md text-sm focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Expected Community Outcome
                </label>
                <input
                  type="text"
                  value={expectedOutcome}
                  onChange={(e) => setExpectedOutcome(e.target.value)}
                  placeholder="e.g., Safe drinking water below 1.0 ppm fluoride with low-cost maintenance"
                  className="w-full px-3 py-2 border border-slate-300 rounded-md text-sm focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                />
              </div>
            </div>
          )}

          {/* STEP 2: Location & Urgency */}
          {step === 2 && (
            <div className="space-y-4 animate-in fade-in">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    District (Jharkhand) *
                  </label>
                  <select
                    value={district}
                    onChange={(e) => setDistrict(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-md text-sm focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  >
                    {JHARKHAND_DISTRICTS.map((d) => (
                      <option key={d} value={d}>
                        {d}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Administrative Block / Tehsil *
                  </label>
                  <input
                    type="text"
                    required
                    value={block}
                    onChange={(e) => setBlock(e.target.value)}
                    placeholder="e.g., Sadar / Kanke / Mandar"
                    className="w-full px-3 py-2 border border-slate-300 rounded-md text-sm focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Village / Panchayat / Ward
                  </label>
                  <input
                    type="text"
                    value={villageOrCity}
                    onChange={(e) => setVillageOrCity(e.target.value)}
                    placeholder="e.g., Mahilong Gram Panchayat"
                    className="w-full px-3 py-2 border border-slate-300 rounded-md text-sm focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Urgency Level *
                  </label>
                  <select
                    value={urgency}
                    onChange={(e) => setUrgency(e.target.value as any)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-md text-sm focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  >
                    <option value="Emergency">Emergency (Immediate hazard to life/health)</option>
                    <option value="High">High (Impacting daily livelihood/education)</option>
                    <option value="Medium">Medium (Chronic infrastructural issue)</option>
                    <option value="Low">Low (Long-term community enhancement)</option>
                  </select>
                </div>
              </div>

              {/* Geolocation Tagging */}
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg flex items-center justify-between">
                <div>
                  <span className="text-xs font-bold text-slate-800 block">GPS Coordinates:</span>
                  <span className="text-xs font-mono text-slate-600">
                    {gpsCoordinates.latitude}° N, {gpsCoordinates.longitude}° E
                  </span>
                </div>
                <button
                  type="button"
                  onClick={handleDetectGps}
                  disabled={isDetectingGps}
                  className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded text-xs font-semibold flex items-center gap-1 transition-colors"
                >
                  <MapPin className="w-3.5 h-3.5" />
                  <span>{isDetectingGps ? 'Locating...' : 'Auto-Detect GPS'}</span>
                </button>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Local Resources / Community Facilities Available
                </label>
                <input
                  type="text"
                  value={availableResources}
                  onChange={(e) => setAvailableResources(e.target.value)}
                  placeholder="e.g., Panchayat hall with solar inverter, volunteer SHG members"
                  className="w-full px-3 py-2 border border-slate-300 rounded-md text-sm focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                />
              </div>
            </div>
          )}

          {/* STEP 3: Evidence & Attachments */}
          {step === 3 && (
            <div className="space-y-4 animate-in fade-in">
              {/* File upload drag zone */}
              <div className="border-2 border-dashed border-slate-300 hover:border-emerald-500 rounded-lg p-6 text-center bg-slate-50/50 cursor-pointer relative">
                <input
                  type="file"
                  onChange={handleSimulateFileUpload}
                  className="absolute inset-0 opacity-0 cursor-pointer"
                  accept="image/*,.pdf,.doc,.docx"
                />
                <Upload className="w-8 h-8 text-slate-400 mx-auto mb-2" />
                <p className="text-xs font-bold text-slate-700">
                  Click or drag site photos, water test reports, or documents
                </p>
                <p className="text-[11px] text-slate-400 mt-1">
                  Supports JPG, PNG, PDF up to 25MB (GPS geotagged photos preferred)
                </p>
              </div>

              {/* Upload progress indicator */}
              {uploadProgress !== null && (
                <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-lg text-xs">
                  <div className="flex justify-between font-semibold text-emerald-900 mb-1">
                    <span>Uploading attachment...</span>
                    <span>{uploadProgress}%</span>
                  </div>
                  <div className="w-full bg-emerald-200 rounded-full h-1.5 overflow-hidden">
                    <div
                      className="bg-emerald-700 h-full rounded-full transition-all duration-200"
                      style={{ width: `${uploadProgress}%` }}
                    ></div>
                  </div>
                </div>
              )}

              {/* Uploaded media list */}
              <div>
                <span className="text-xs font-bold text-slate-700 uppercase tracking-wider block mb-2">
                  Attached Evidence ({mediaList.length})
                </span>
                <div className="space-y-2">
                  {mediaList.map((m) => (
                    <div
                      key={m.id}
                      className="flex items-center justify-between p-2.5 bg-slate-50 border border-slate-200 rounded-lg text-xs"
                    >
                      <div className="flex items-center gap-2">
                        <FileCheck className="w-4 h-4 text-emerald-600" />
                        <div>
                          <p className="font-semibold text-slate-800">{m.name}</p>
                          <p className="text-[10px] text-slate-400">
                            {(m.sizeBytes / 1024).toFixed(1)} KB • Geotagged
                          </p>
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() => setMediaList((list) => list.filter((item) => item.id !== m.id))}
                        className="text-slate-400 hover:text-red-500 transition-colors"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              {/* Contact confirmation */}
              <div className="p-3 bg-emerald-50/70 border border-emerald-200 rounded-lg text-xs">
                <span className="font-bold text-emerald-900 block mb-1">
                  Primary Citizen / Submitter Contact
                </span>
                <p className="text-slate-700">
                  {contactName} • {contactPhone} • {contactEmail}
                </p>
                <p className="text-[10px] text-slate-500 mt-1">
                  You will receive SMS and portal alerts when Government verifies or Universities claim this problem.
                </p>
              </div>
            </div>
          )}

          {/* Modal Footer Controls */}
          <div className="pt-4 border-t border-slate-200 flex items-center justify-between">
            {step > 1 ? (
              <button
                type="button"
                onClick={() => setStep(step - 1)}
                className="px-4 py-2 border border-slate-300 rounded-md text-xs font-semibold text-slate-700 hover:bg-slate-50 transition-colors"
              >
                Back
              </button>
            ) : (
              <div></div>
            )}

            <div className="flex items-center gap-2">
              {step < 3 ? (
                <button
                  type="button"
                  onClick={() => setStep(step + 1)}
                  className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-md text-xs font-semibold transition-colors"
                >
                  Continue
                </button>
              ) : (
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-md text-xs font-bold flex items-center gap-1.5 shadow-md transition-all disabled:opacity-50"
                >
                  <Sparkles className="w-4 h-4 text-emerald-300" />
                  <span>{isSubmitting ? 'Running AI Triage...' : 'Submit to CivicBridge'}</span>
                </button>
              )}
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
