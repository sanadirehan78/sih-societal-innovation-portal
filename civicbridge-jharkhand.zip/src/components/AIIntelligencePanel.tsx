/**
 * AI Problem Intelligence Panel
 * Displays domain classification, multi-factor priority reasoning,
 * duplicate candidates, and university matching scores.
 */

import React, { useState } from 'react';
import { Challenge, RecommendedUniversity } from '../types';
import {
  Brain,
  Sparkles,
  AlertTriangle,
  GraduationCap,
  CopyCheck,
  ChevronDown,
  ChevronUp,
  CheckCircle2,
  ShieldAlert,
  ArrowRight,
} from 'lucide-react';
import * as api from '../api';
import { useApp } from '../context/AppContext';

interface Props {
  challenge: Challenge;
  onAssignUniversity?: (uniId: string) => void;
}

export const AIIntelligencePanel: React.FC<Props> = ({ challenge, onAssignUniversity }) => {
  const { refreshAllData, showToast } = useApp();
  const [isExpanded, setIsExpanded] = useState(true);
  const [isMerging, setIsMerging] = useState(false);

  const ai = challenge.aiAnalysis;
  if (!ai) {
    return (
      <div className="bg-slate-50 border border-slate-200 rounded-lg p-4 text-center text-xs text-slate-500">
        AI analysis pending for this challenge.
      </div>
    );
  }

  const handleMerge = async (duplicateCandidateId: string) => {
    if (window.confirm(`Merge this challenge into canonical record ${duplicateCandidateId}?`)) {
      setIsMerging(true);
      try {
        await api.mergeDuplicateChallenge(challenge.id, duplicateCandidateId, 'Confirmed duplicate via AI triage');
        showToast(`Challenge merged into ${duplicateCandidateId}`);
        await refreshAllData();
      } catch (err) {
        showToast('Failed to merge duplicate');
      } finally {
        setIsMerging(false);
      }
    }
  };

  const getPriorityBadgeClass = (priority: string) => {
    switch (priority) {
      case 'Critical':
        return 'bg-red-100 text-red-800 border-red-300';
      case 'High':
        return 'bg-amber-100 text-amber-800 border-amber-300';
      case 'Medium':
        return 'bg-blue-100 text-blue-800 border-blue-300';
      default:
        return 'bg-slate-100 text-slate-700 border-slate-300';
    }
  };

  return (
    <div className="bg-gradient-to-br from-slate-900 to-slate-950 text-white rounded-xl border border-slate-800 overflow-hidden shadow-lg">
      {/* Header */}
      <div
        className="px-4 py-3 bg-slate-800/80 border-b border-slate-700/80 flex items-center justify-between cursor-pointer"
        onClick={() => setIsExpanded(!isExpanded)}
      >
        <div className="flex items-center gap-2.5">
          <div className="w-7 h-7 rounded-lg bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
            <Brain className="w-4 h-4" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-white tracking-wide">AI Problem Intelligence Engine</span>
              <span className="text-[10px] bg-emerald-950 text-emerald-300 px-2 py-0.5 rounded font-mono border border-emerald-800">
                {ai.modelEngine}
              </span>
            </div>
            <p className="text-[11px] text-slate-400">
              Deterministic taxonomy & multi-factor priority analysis • Confidence {ai.confidenceScore}%
            </p>
          </div>
        </div>

        <button className="text-slate-400 hover:text-white transition-colors">
          {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
        </button>
      </div>

      {isExpanded && (
        <div className="p-4 space-y-4 text-xs">
          {/* Top Metric Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
            {/* Domain */}
            <div className="bg-slate-800/60 rounded-lg p-2.5 border border-slate-700/60">
              <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider block">
                Classified Domain
              </span>
              <span className="text-sm font-bold text-white mt-0.5 block truncate">
                {ai.domain}
              </span>
              <span className="text-[10px] text-emerald-400 font-mono">
                Sub: {ai.subDomain}
              </span>
            </div>

            {/* Priority Score */}
            <div className="bg-slate-800/60 rounded-lg p-2.5 border border-slate-700/60">
              <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider block">
                Calculated Priority
              </span>
              <div className="flex items-baseline gap-1.5 mt-0.5">
                <span className="text-base font-black text-amber-400 font-mono">
                  {ai.priorityScore}
                </span>
                <span className="text-[10px] text-slate-400">/ 100</span>
                <span className={`text-[10px] px-1.5 py-0.2 rounded font-bold uppercase ml-auto border ${getPriorityBadgeClass(ai.priorityLevel)}`}>
                  {ai.priorityLevel}
                </span>
              </div>
              <div className="w-full bg-slate-700 rounded-full h-1.5 mt-1.5 overflow-hidden">
                <div
                  className={`h-full rounded-full ${
                    ai.priorityScore >= 80 ? 'bg-red-500' : ai.priorityScore >= 60 ? 'bg-amber-400' : 'bg-blue-400'
                  }`}
                  style={{ width: `${ai.priorityScore}%` }}
                ></div>
              </div>
            </div>

            {/* Suggested Archetype */}
            <div className="bg-slate-800/60 rounded-lg p-2.5 border border-slate-700/60">
              <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider block">
                Solution Archetype
              </span>
              <span className="text-xs font-semibold text-white mt-0.5 block truncate">
                {ai.suggestedProjectType}
              </span>
              <span className="text-[10px] text-teal-400 block truncate mt-0.5">
                {ai.suggestedSDG}
              </span>
            </div>

            {/* Duplicate Risk */}
            <div className="bg-slate-800/60 rounded-lg p-2.5 border border-slate-700/60">
              <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider block">
                Duplicate Index
              </span>
              <span className="text-sm font-bold text-white mt-0.5 block font-mono">
                {ai.duplicateProbability}% Similarity
              </span>
              <span className={`text-[10px] font-medium block ${ai.duplicateProbability > 65 ? 'text-rose-400' : 'text-emerald-400'}`}>
                {ai.duplicateProbability > 65 ? 'Possible Duplicate' : 'Distinct Challenge'}
              </span>
            </div>
          </div>

          {/* Explainable Priority Reasoning Breakdown */}
          <div className="bg-slate-800/40 rounded-lg p-3 border border-slate-700/50">
            <h5 className="text-[11px] font-bold text-slate-300 uppercase tracking-wider mb-2 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span>Explainable Priority Score Breakdown</span>
            </h5>
            <ul className="space-y-1.5 text-[11px] text-slate-300">
              {ai.priorityReasoning.map((reason, idx) => (
                <li key={idx} className="flex items-start gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0 mt-0.5" />
                  <span>{reason}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Duplicate Candidates Alert (If any exist) */}
          {challenge.duplicateCandidates && challenge.duplicateCandidates.length > 0 && (
            <div className="bg-amber-950/40 border border-amber-800/60 rounded-lg p-3">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-1.5 text-amber-300 font-bold text-xs">
                  <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
                  <span>Semantic Duplicate Detection ({challenge.duplicateCandidates.length} potential matches)</span>
                </div>
              </div>
              <div className="space-y-2">
                {challenge.duplicateCandidates.map((dup) => (
                  <div
                    key={dup.existingChallengeId}
                    className="bg-slate-900/80 rounded p-2.5 border border-slate-800 flex items-center justify-between gap-3 text-xs"
                  >
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-emerald-400 font-bold text-[10px]">
                          {dup.existingChallengeId}
                        </span>
                        <span className="text-[10px] bg-amber-900/60 text-amber-200 px-1.5 py-0.2 rounded font-mono">
                          {dup.similarityScore}% match
                        </span>
                        <span className="text-[10px] text-slate-400">
                          {dup.district} • {dup.status}
                        </span>
                      </div>
                      <p className="text-slate-200 font-medium truncate text-xs mt-0.5">
                        {dup.existingTitle}
                      </p>
                    </div>

                    <button
                      onClick={() => handleMerge(dup.existingChallengeId)}
                      disabled={isMerging}
                      className="px-2.5 py-1 bg-amber-600 hover:bg-amber-500 text-slate-950 font-bold text-[11px] rounded flex items-center gap-1 flex-shrink-0 transition-colors"
                      title="Merge this submission into the canonical challenge"
                    >
                      <CopyCheck className="w-3 h-3" />
                      <span>Merge</span>
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* University Recommendations with "Why?" Score */}
          <div>
            <h5 className="text-[11px] font-bold text-slate-300 uppercase tracking-wider mb-2 flex items-center gap-1.5">
              <GraduationCap className="w-3.5 h-3.5 text-emerald-400" />
              <span>Recommended University Research Labs & Matching Rationale</span>
            </h5>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
              {ai.recommendedUniversities.map((uni) => (
                <div
                  key={uni.universityId}
                  className="bg-slate-800/50 rounded-lg p-3 border border-slate-700/60 flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <h6 className="font-bold text-white text-xs">{uni.universityName}</h6>
                        <span className="text-[10px] text-slate-400">{uni.district}</span>
                      </div>
                      <span className="bg-emerald-900 text-emerald-300 border border-emerald-700 px-2 py-0.5 rounded font-mono font-black text-xs">
                        {uni.matchScore}% Match
                      </span>
                    </div>

                    {/* Why Matched List */}
                    <div className="mt-2 space-y-1">
                      {uni.matchReasons.map((reason, i) => (
                        <div key={i} className="text-[11px] text-slate-300 flex items-start gap-1.5">
                          <span className="text-emerald-400">•</span>
                          <span>{reason}</span>
                        </div>
                      ))}
                    </div>

                    {/* Relevant Facilities */}
                    {uni.relevantFacilities && uni.relevantFacilities.length > 0 && (
                      <div className="mt-2 flex flex-wrap gap-1">
                        {uni.relevantFacilities.map((fac, i) => (
                          <span
                            key={i}
                            className="bg-slate-900 text-slate-300 text-[10px] px-1.5 py-0.5 rounded border border-slate-700"
                          >
                            {fac}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>

                  {onAssignUniversity && challenge.status !== 'Assigned' && challenge.status !== 'Project Started' && (
                    <button
                      onClick={() => onAssignUniversity(uni.universityId)}
                      className="mt-3 w-full py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs rounded flex items-center justify-center gap-1 transition-colors"
                    >
                      <span>Assign to {uni.universityName}</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
