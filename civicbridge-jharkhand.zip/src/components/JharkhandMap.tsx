/**
 * Interactive 24-District Jharkhand Density Map & District Inspector
 * SIH 2026 Problem Statement: SIH26043
 */

import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  MapPin,
  AlertTriangle,
  Layers,
  GraduationCap,
  Users,
  Search,
  CheckCircle2,
  ExternalLink,
} from 'lucide-react';
import { Challenge } from '../types';

interface DistrictMeta {
  name: string;
  division: string;
  headquarters: string;
  x: number; // approximate coordinate for SVG plotting
  y: number;
  svgPath?: string;
}

const DISTRICT_COORDINATES: DistrictMeta[] = [
  // Palamu Division (North-West)
  { name: 'Garhwa', division: 'Palamu', headquarters: 'Garhwa', x: 60, y: 70 },
  { name: 'Palamu', division: 'Palamu', headquarters: 'Daltonganj', x: 130, y: 110 },
  { name: 'Latehar', division: 'Palamu', headquarters: 'Latehar', x: 140, y: 190 },

  // North Chotanagpur Division (Center-North)
  { name: 'Chatra', division: 'North Chotanagpur', headquarters: 'Chatra', x: 210, y: 100 },
  { name: 'Hazaribagh', division: 'North Chotanagpur', headquarters: 'Hazaribagh', x: 280, y: 140 },
  { name: 'Koderma', division: 'North Chotanagpur', headquarters: 'Koderma', x: 320, y: 80 },
  { name: 'Giridih', division: 'North Chotanagpur', headquarters: 'Giridih', x: 400, y: 110 },
  { name: 'Bokaro', division: 'North Chotanagpur', headquarters: 'Bokaro Steel City', x: 380, y: 200 },
  { name: 'Dhanbad', division: 'North Chotanagpur', headquarters: 'Dhanbad', x: 440, y: 180 },
  { name: 'Ramgarh', division: 'North Chotanagpur', headquarters: 'Ramgarh Cantonment', x: 300, y: 220 },

  // South Chotanagpur Division (Center-South)
  { name: 'Lohardaga', division: 'South Chotanagpur', headquarters: 'Lohardaga', x: 180, y: 240 },
  { name: 'Gumla', division: 'South Chotanagpur', headquarters: 'Gumla', x: 150, y: 310 },
  { name: 'Simdega', division: 'South Chotanagpur', headquarters: 'Simdega', x: 160, y: 400 },
  { name: 'Ranchi', division: 'South Chotanagpur', headquarters: 'Ranchi', x: 270, y: 280 },
  { name: 'Khunti', division: 'South Chotanagpur', headquarters: 'Khunti', x: 260, y: 350 },

  // Kolhan Division (South-East)
  { name: 'West Singhbhum', division: 'Kolhan', headquarters: 'Chaibasa', x: 310, y: 420 },
  { name: 'Saraikela Kharsawan', division: 'Kolhan', headquarters: 'Saraikela', x: 380, y: 350 },
  { name: 'East Singhbhum', division: 'Kolhan', headquarters: 'Jamshedpur', x: 450, y: 360 },

  // Santhal Pargana Division (North-East)
  { name: 'Deoghar', division: 'Santhal Pargana', headquarters: 'Deoghar', x: 470, y: 100 },
  { name: 'Dumka', division: 'Santhal Pargana', headquarters: 'Dumka', x: 530, y: 130 },
  { name: 'Jamtara', division: 'Santhal Pargana', headquarters: 'Jamtara', x: 490, y: 170 },
  { name: 'Godda', division: 'Santhal Pargana', headquarters: 'Godda', x: 570, y: 90 },
  { name: 'Pakur', division: 'Santhal Pargana', headquarters: 'Pakur', x: 620, y: 130 },
  { name: 'Sahibganj', division: 'Santhal Pargana', headquarters: 'Sahibganj', x: 610, y: 60 },
];

export const JharkhandMap: React.FC = () => {
  const { challenges, projects, setSelectedChallenge } = useApp();
  const [selectedDistrictName, setSelectedDistrictName] = useState<string>('Ranchi');
  const [searchQuery, setSearchQuery] = useState('');
  const [divisionFilter, setDivisionFilter] = useState('All');

  const selectedMeta =
    DISTRICT_COORDINATES.find((d) => d.name.toLowerCase() === selectedDistrictName.toLowerCase()) ||
    DISTRICT_COORDINATES[0];

  const districtChallenges = challenges.filter(
    (c) => c.location.district.toLowerCase() === selectedDistrictName.toLowerCase()
  );
  const districtProjects = projects.filter(
    (p) => p.district.toLowerCase() === selectedDistrictName.toLowerCase()
  );

  const getDistrictStats = (districtName: string) => {
    const ch = challenges.filter(
      (c) => c.location.district.toLowerCase() === districtName.toLowerCase()
    );
    const prj = projects.filter(
      (p) => p.district.toLowerCase() === districtName.toLowerCase()
    );
    const highPri = ch.filter(
      (c) => c.aiAnalysis?.priorityLevel === 'Critical' || c.aiAnalysis?.priorityLevel === 'High'
    ).length;
    const pop = ch.reduce((acc, c) => acc + (c.affectedPopulation || 0), 0);

    return { count: ch.length, projectCount: prj.length, highPri, pop };
  };

  const getIntensityColor = (count: number) => {
    if (count >= 4) return 'fill-rose-600 hover:fill-rose-500';
    if (count >= 2) return 'fill-amber-500 hover:fill-amber-400';
    if (count >= 1) return 'fill-emerald-600 hover:fill-emerald-500';
    return 'fill-slate-700 hover:fill-slate-600';
  };

  const filteredDistricts = DISTRICT_COORDINATES.filter((d) => {
    const matchesSearch = d.name.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesDiv = divisionFilter === 'All' || d.division === divisionFilter;
    return matchesSearch && matchesDiv;
  });

  return (
    <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
      {/* Header */}
      <div className="p-4 sm:p-6 border-b border-slate-200 bg-slate-50/70 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-lg bg-emerald-100 text-emerald-800">
              <MapPin className="w-5 h-5" />
            </span>
            <h3 className="text-lg font-bold text-slate-900">
              24-District Geographic Intelligence Map (Jharkhand)
            </h3>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Real-time geospatial density of grassroots challenges, priority hot-spots, and active university projects.
          </p>
        </div>

        {/* Legend */}
        <div className="flex items-center gap-3 text-xs bg-white px-3 py-1.5 rounded-lg border border-slate-200">
          <span className="text-[11px] font-semibold text-slate-500">Density:</span>
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-3 rounded-full bg-rose-600"></span>
            <span className="text-slate-700 font-medium text-[11px]">Critical / High (3+)</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-3 rounded-full bg-amber-500"></span>
            <span className="text-slate-700 font-medium text-[11px]">Medium (1-2)</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-3 rounded-full bg-emerald-600"></span>
            <span className="text-slate-700 font-medium text-[11px]">Active Pilot</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12">
        {/* Left: Vector Schematic Map */}
        <div className="lg:col-span-7 p-4 sm:p-6 bg-slate-950 flex flex-col justify-between relative min-h-[480px]">
          {/* Subtle Grid Background */}
          <div className="absolute inset-0 bg-[radial-gradient(#334155_1px,transparent_1px)] [background-size:16px_16px] opacity-30 pointer-events-none"></div>

          {/* District Selector Filter */}
          <div className="relative z-10 flex flex-wrap items-center gap-2 mb-2">
            <div className="relative flex-1 min-w-[140px]">
              <Search className="w-3.5 h-3.5 absolute left-2.5 top-2.5 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search district..."
                className="w-full pl-8 pr-3 py-1.5 bg-slate-900 border border-slate-700 text-white rounded-md text-xs focus:ring-1 focus:ring-emerald-400 focus:outline-none"
              />
            </div>
            <select
              value={divisionFilter}
              onChange={(e) => setDivisionFilter(e.target.value)}
              className="bg-slate-900 border border-slate-700 text-slate-200 text-xs rounded-md px-2.5 py-1.5 focus:ring-1 focus:ring-emerald-400 focus:outline-none"
            >
              <option value="All">All Divisions (5)</option>
              <option value="South Chotanagpur">South Chotanagpur</option>
              <option value="North Chotanagpur">North Chotanagpur</option>
              <option value="Santhal Pargana">Santhal Pargana</option>
              <option value="Kolhan">Kolhan</option>
              <option value="Palamu">Palamu</option>
            </select>
          </div>

          {/* SVG Map of Jharkhand */}
          <div className="relative z-10 w-full flex-1 flex items-center justify-center py-2">
            <svg
              viewBox="0 0 700 500"
              className="w-full max-w-[620px] h-auto drop-shadow-2xl"
              style={{ filter: 'drop-shadow(0 10px 25px rgba(0,0,0,0.5))' }}
            >
              {/* State Outline Connector Mesh */}
              <path
                d="M 50 60 Q 300 30 630 50 Q 650 200 470 400 Q 300 480 150 420 Q 40 280 50 60 Z"
                fill="none"
                stroke="#1e293b"
                strokeWidth="1.5"
                strokeDasharray="4 4"
              />

              {/* District Nodes */}
              {DISTRICT_COORDINATES.map((district) => {
                const stats = getDistrictStats(district.name);
                const isSelected = selectedDistrictName.toLowerCase() === district.name.toLowerCase();
                const radius = 18 + Math.min(14, stats.count * 3);

                return (
                  <g
                    key={district.name}
                    className="cursor-pointer transition-all duration-200"
                    onClick={() => setSelectedDistrictName(district.name)}
                  >
                    {/* Ring highlight if selected */}
                    {isSelected && (
                      <circle
                        cx={district.x}
                        cy={district.y}
                        r={radius + 6}
                        fill="none"
                        stroke="#34d399"
                        strokeWidth="2.5"
                        className="animate-pulse"
                      />
                    )}

                    {/* Main District Circle */}
                    <circle
                      cx={district.x}
                      cy={district.y}
                      r={radius}
                      className={`${getIntensityColor(stats.count)} transition-all duration-150 stroke-slate-900 stroke-2`}
                    />

                    {/* Count badge */}
                    <text
                      x={district.x}
                      y={district.y + 4}
                      textAnchor="middle"
                      fill="#ffffff"
                      fontSize="11"
                      fontWeight="bold"
                      fontFamily="monospace"
                    >
                      {stats.count}
                    </text>

                    {/* District Name Label */}
                    <text
                      x={district.x}
                      y={district.y + radius + 13}
                      textAnchor="middle"
                      fill={isSelected ? '#34d399' : '#cbd5e1'}
                      fontSize="10"
                      fontWeight={isSelected ? 'bold' : '500'}
                    >
                      {district.name}
                    </text>
                  </g>
                );
              })}
            </svg>
          </div>

          <div className="relative z-10 text-[11px] text-slate-400 flex items-center justify-between pt-2 border-t border-slate-800">
            <span>Tip: Click on any district node to inspect problems & university projects</span>
            <span className="font-mono text-emerald-400">Total Districts: 24</span>
          </div>
        </div>

        {/* Right: District Dossier Inspector */}
        <div className="lg:col-span-5 p-4 sm:p-6 bg-white flex flex-col justify-between">
          <div>
            {/* Header info */}
            <div className="flex items-start justify-between border-b border-slate-200 pb-3">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                  {selectedMeta.division} Division
                </span>
                <h4 className="text-xl font-black text-slate-900 mt-1">{selectedMeta.name} District</h4>
                <p className="text-xs text-slate-500">HQ: {selectedMeta.headquarters}, Jharkhand</p>
              </div>

              <div className="text-right">
                <span className="text-2xl font-black text-emerald-700 font-mono">
                  {districtChallenges.length}
                </span>
                <span className="block text-[10px] font-semibold text-slate-400 uppercase">
                  Challenges
                </span>
              </div>
            </div>

            {/* Quick Metrics */}
            <div className="grid grid-cols-3 gap-2 my-4">
              <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-200 text-center">
                <span className="text-[10px] font-bold text-slate-500 block uppercase">Critical / High</span>
                <span className="text-base font-black text-red-600 font-mono">
                  {districtChallenges.filter((c) => c.aiAnalysis?.priorityLevel === 'Critical' || c.aiAnalysis?.priorityLevel === 'High').length}
                </span>
              </div>
              <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-200 text-center">
                <span className="text-[10px] font-bold text-slate-500 block uppercase">Active Projects</span>
                <span className="text-base font-black text-emerald-700 font-mono">
                  {districtProjects.length}
                </span>
              </div>
              <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-200 text-center">
                <span className="text-[10px] font-bold text-slate-500 block uppercase">Affected Pop</span>
                <span className="text-base font-black text-slate-800 font-mono">
                  {districtChallenges.reduce((sum, c) => sum + (c.affectedPopulation || 0), 0).toLocaleString()}
                </span>
              </div>
            </div>

            {/* Reported Challenges in this District */}
            <div>
              <h5 className="text-xs font-bold text-slate-800 mb-2 flex items-center justify-between">
                <span>Reported Challenges in {selectedMeta.name}</span>
                <span className="text-[10px] text-slate-400 font-normal">
                  Showing {districtChallenges.length} record(s)
                </span>
              </h5>

              {districtChallenges.length === 0 ? (
                <div className="p-6 bg-slate-50 rounded-lg border border-dashed border-slate-300 text-center text-xs text-slate-500">
                  No civic challenges currently registered in {selectedMeta.name}.
                </div>
              ) : (
                <div className="space-y-2 max-h-64 overflow-y-auto pr-1">
                  {districtChallenges.map((c) => (
                    <div
                      key={c.id}
                      onClick={() => setSelectedChallenge(c)}
                      className="p-3 rounded-lg border border-slate-200 hover:border-emerald-500 bg-white hover:bg-emerald-50/40 transition-all cursor-pointer shadow-sm group"
                    >
                      <div className="flex items-center justify-between gap-2 mb-1">
                        <span className="text-[10px] font-bold text-emerald-800 bg-emerald-100/70 px-1.5 py-0.2 rounded font-mono">
                          {c.id}
                        </span>
                        <span className={`text-[10px] font-bold px-1.5 py-0.2 rounded ${
                          c.aiAnalysis?.priorityLevel === 'Critical' ? 'bg-red-100 text-red-800' :
                          c.aiAnalysis?.priorityLevel === 'High' ? 'bg-amber-100 text-amber-800' :
                          'bg-blue-100 text-blue-800'
                        }`}>
                          {c.aiAnalysis?.priorityLevel || 'Normal'}
                        </span>
                      </div>
                      <h6 className="text-xs font-bold text-slate-900 group-hover:text-emerald-900 line-clamp-1">
                        {c.title}
                      </h6>
                      <p className="text-[11px] text-slate-500 line-clamp-1 mt-0.5">
                        {c.detailedDescription}
                      </p>
                      <div className="mt-2 flex items-center justify-between text-[10px] text-slate-400">
                        <span>Block: {c.location.block}</span>
                        <span className="text-emerald-600 font-semibold flex items-center gap-0.5">
                          View details <ExternalLink className="w-2.5 h-2.5" />
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Quick district pill selector */}
          <div className="mt-4 pt-3 border-t border-slate-100">
            <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider block mb-1.5">
              All 24 Districts (Click to View):
            </span>
            <div className="flex flex-wrap gap-1 max-h-20 overflow-y-auto no-scrollbar">
              {filteredDistricts.map((d) => (
                <button
                  key={d.name}
                  onClick={() => setSelectedDistrictName(d.name)}
                  className={`px-2 py-0.5 rounded text-[10px] font-medium transition-colors ${
                    selectedDistrictName === d.name
                      ? 'bg-emerald-700 text-white font-bold'
                      : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                  }`}
                >
                  {d.name}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
