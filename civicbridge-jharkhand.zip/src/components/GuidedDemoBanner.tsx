/**
 * Guided Demo Banner - 2-Minute SIH 2026 Walkthrough Controller
 */

import React from 'react';
import { useApp } from '../context/AppContext';
import {
  Sparkles,
  ChevronRight,
  ChevronLeft,
  X,
  CheckCircle2,
  ArrowRight,
} from 'lucide-react';

export const GuidedDemoBanner: React.FC = () => {
  const {
    guidedDemoActive,
    guidedDemoStep,
    nextDemoStep,
    prevDemoStep,
    exitGuidedDemo,
    currentUser,
  } = useApp();

  if (!guidedDemoActive) return null;

  const STEPS = [
    {
      title: 'SIH26043 Problem Statement Overview',
      role: 'Platform Introduction',
      desc: 'CivicBridge Jharkhand connects grassroots community challenges with multidisciplinary university teams, industry CSR, and government validation to drive sustainable societal impact.',
      actionPrompt: 'Click Next to explore citizen challenges crowdsourced across Jharkhand.',
    },
    {
      title: 'Step 1: Explore Crowdsourced Challenges',
      role: 'Citizen & Community Perspective',
      desc: 'Citizens report local challenges across all 24 districts—from arsenic groundwater in Sahibganj to solar cold storage for tribal farmers in Khunti.',
      actionPrompt: 'Click Next to simulate submitting a new civic challenge as a Citizen.',
    },
    {
      title: 'Step 2: Submit a Civic Problem',
      role: 'Citizen Persona (Sunita Soren)',
      desc: 'Submit problem with GPS coordinates, affected population, urgency, and photo evidence. Watch our AI Intelligence Pipeline classify, score priority, and check duplicates in real time!',
      actionPrompt: 'Fill or review the challenge form, then click Next to review as Government.',
    },
    {
      title: 'Step 3: AI Analysis & Government Validation',
      role: 'Government Department (GoJ Officer)',
      desc: 'The Department of Higher & Technical Education inspects AI domain classification, duplicate similarity scores, and explainable multi-factor priority points before approving.',
      actionPrompt: 'Click Next to see University matching and team assembly.',
    },
    {
      title: 'Step 4: University Multidisciplinary Team',
      role: 'University Admin (Dr. Alok Verma, BIT Mesra)',
      desc: 'Universities receive matched challenges tailored to their labs. Faculty mentors assemble student teams spanning Electronics, Civil, AI, and Agriculture, and draft formal proposals.',
      actionPrompt: 'Click Next to see how Industry and CSR partners get involved.',
    },
    {
      title: 'Step 5: Industry Mentorship & CSR Co-Funding',
      role: 'Industry Partner (Tata Steel / CCL)',
      desc: 'Corporates and MSMEs pledge financial co-funding, field equipment, and industrial mentors under statutory CSR or open innovation frameworks.',
      actionPrompt: 'Click Next to view live project tracking and milestone execution.',
    },
    {
      title: 'Step 6: Milestone Execution & Field Pilot',
      role: 'Project Dashboard (Active Deployment)',
      desc: 'Track projects across 12 structured phases from CAD prototyping to field testing at Gram Panchayats with verifiable telemetry and milestone approvals.',
      actionPrompt: 'Click Next to verify real-world social impact and outcome metrics.',
    },
    {
      title: 'Step 7: Quantified Before vs. After Social Impact',
      role: 'Impact & Evaluation (Department of Higher Education)',
      desc: 'Every project must measure verifiable outcomes: households benefited, cost saved, carbon offset, patents filed, and research papers published.',
      actionPrompt: 'Tour complete! You can freely explore or reset the demo database anytime.',
    },
  ];

  const currentStepInfo = STEPS[guidedDemoStep] || STEPS[0];

  return (
    <div className="bg-gradient-to-r from-slate-900 via-emerald-950 to-slate-900 text-white border-b border-emerald-700 shadow-md px-4 py-3 sticky top-[108px] z-30 animate-in fade-in">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-start md:items-center justify-between gap-3">
        <div className="flex items-start gap-3">
          <div className="w-8 h-8 rounded-full bg-emerald-500/20 border border-emerald-400 flex items-center justify-center text-emerald-300 flex-shrink-0 mt-0.5">
            <Sparkles className="w-4 h-4 text-emerald-400" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[11px] font-bold uppercase tracking-wider bg-emerald-800 text-emerald-200 px-2 py-0.5 rounded">
                Demo Step {guidedDemoStep + 1} of {STEPS.length}
              </span>
              <span className="text-xs font-semibold text-emerald-300">
                Active Persona: <strong className="text-white">{currentUser?.name}</strong> ({currentUser?.role})
              </span>
            </div>
            <h4 className="text-sm font-bold text-white mt-0.5">{currentStepInfo.title}</h4>
            <p className="text-xs text-slate-300 max-w-3xl leading-relaxed mt-0.5">
              {currentStepInfo.desc}
            </p>
          </div>
        </div>

        {/* Controls */}
        <div className="flex items-center gap-2 self-end md:self-center flex-shrink-0">
          <button
            onClick={prevDemoStep}
            disabled={guidedDemoStep === 0}
            className="px-2.5 py-1 text-xs font-medium rounded bg-slate-800 hover:bg-slate-700 text-slate-300 disabled:opacity-40 disabled:cursor-not-allowed flex items-center gap-1 border border-slate-700"
          >
            <ChevronLeft className="w-3.5 h-3.5" />
            <span>Prev</span>
          </button>

          <button
            onClick={nextDemoStep}
            className="px-3 py-1 text-xs font-bold rounded bg-emerald-500 hover:bg-emerald-400 text-slate-950 flex items-center gap-1 shadow-sm transition-all"
          >
            <span>{guidedDemoStep === STEPS.length - 1 ? 'Finish Tour' : 'Next Step'}</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={exitGuidedDemo}
            className="p-1 text-slate-400 hover:text-white rounded hover:bg-slate-800 transition-colors ml-1"
            title="Exit guided tour"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
