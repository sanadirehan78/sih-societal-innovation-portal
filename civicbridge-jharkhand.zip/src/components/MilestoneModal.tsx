/**
 * Milestone Update Modal
 * Track progress %, upload evidence notes, and update project stage
 */

import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { X, CheckCircle2, Flag, FileText } from 'lucide-react';
import * as api from '../api';
import { MilestoneStatus } from '../types';

export const MilestoneModal: React.FC = () => {
  const {
    isMilestoneModalOpen,
    setIsMilestoneModalOpen,
    activeEntityForModal,
    refreshAllData,
    showToast,
  } = useApp();

  const { project, milestone } = activeEntityForModal || {};

  const [status, setStatus] = useState<MilestoneStatus>(milestone?.status || 'In Progress');
  const [progressPercent, setProgressPercent] = useState<number>(milestone?.progressPercent || 0);
  const [evidenceNotes, setEvidenceNotes] = useState(milestone?.evidenceNotes || '');
  const [isUpdating, setIsUpdating] = useState(false);

  if (!isMilestoneModalOpen || !project || !milestone) return null;

  const handleUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsUpdating(true);
    try {
      const res = await api.updateMilestone(project.id, milestone.id, {
        status,
        progressPercent: Number(progressPercent),
        evidenceNotes,
      });

      if (res.success) {
        showToast(`Milestone updated to ${status} (${progressPercent}%)!`);
        setIsMilestoneModalOpen(false);
        await refreshAllData();
      }
    } catch (err) {
      showToast('Failed to update milestone');
    } finally {
      setIsUpdating(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/75 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-xl shadow-2xl border border-slate-200 w-full max-w-lg overflow-hidden animate-in fade-in zoom-in-95">
        <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-600 flex items-center justify-center font-bold">
              <Flag className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-bold">Update Project Milestone</h3>
              <p className="text-xs text-slate-300 truncate max-w-sm">{milestone.title}</p>
            </div>
          </div>
          <button
            onClick={() => setIsMilestoneModalOpen(false)}
            className="p-1 rounded-md text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleUpdate} className="p-6 space-y-4 text-xs">
          <div>
            <span className="font-bold text-slate-500 uppercase block mb-1">Milestone Description</span>
            <p className="text-slate-700 bg-slate-50 p-3 rounded-lg border border-slate-200 leading-relaxed">
              {milestone.description}
            </p>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">
                Milestone Status *
              </label>
              <select
                value={status}
                onChange={(e) => {
                  const s = e.target.value as MilestoneStatus;
                  setStatus(s);
                  if (s === 'Completed') setProgressPercent(100);
                }}
                className="w-full px-3 py-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              >
                <option value="Not Started">Not Started</option>
                <option value="In Progress">In Progress</option>
                <option value="Under Review">Under Review</option>
                <option value="Blocked">Blocked</option>
                <option value="Completed">Completed</option>
              </select>
            </div>

            <div>
              <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">
                Progress: {progressPercent}%
              </label>
              <input
                type="range"
                min="0"
                max="100"
                step="5"
                value={progressPercent}
                onChange={(e) => setProgressPercent(Number(e.target.value))}
                className="w-full accent-emerald-600 mt-2"
              />
            </div>
          </div>

          <div>
            <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">
              Field Evidence / Lab Test Deliverable Notes
            </label>
            <textarea
              rows={3}
              value={evidenceNotes}
              onChange={(e) => setEvidenceNotes(e.target.value)}
              placeholder="e.g., Completed CAD simulation and PCB board assembly. Successfully demonstrated zero-leakage test at university hydraulic laboratory."
              className="w-full px-3 py-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-emerald-500 focus:outline-none"
            />
          </div>

          <div className="pt-3 border-t border-slate-200 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={() => setIsMilestoneModalOpen(false)}
              className="px-4 py-2 border border-slate-300 rounded-md font-semibold text-slate-700 hover:bg-slate-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isUpdating}
              className="px-5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-md font-bold transition-all shadow-md"
            >
              {isUpdating ? 'Updating...' : 'Save Milestone Update'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
