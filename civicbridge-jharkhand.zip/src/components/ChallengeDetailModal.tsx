/**
 * Challenge Detail Modal
 * Comprehensive dossier with AI intelligence, government validation,
 * university assignment, and discussion messages.
 */

import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  X,
  MapPin,
  Users,
  Calendar,
  Building2,
  GraduationCap,
  ShieldCheck,
  CheckCircle2,
  AlertTriangle,
  MessageSquare,
  Send,
  ExternalLink,
  Layers,
  ArrowRight,
  FileCheck,
} from 'lucide-react';
import { AIIntelligencePanel } from './AIIntelligencePanel';
import * as api from '../api';

export const ChallengeDetailModal: React.FC = () => {
  const {
    selectedChallenge,
    setSelectedChallenge,
    currentUser,
    universities,
    refreshAllData,
    showToast,
    setIsTeamBuilderModalOpen,
    setActiveEntityForModal,
  } = useApp();

  const [activeTab, setActiveTab] = useState<'dossier' | 'ai' | 'discussions'>('dossier');
  const [validationNotes, setValidationNotes] = useState('');
  const [overrideDomain, setOverrideDomain] = useState('');
  const [overridePriority, setOverridePriority] = useState('');
  const [assignedUniversityId, setAssignedUniversityId] = useState('');
  const [isValidating, setIsValidating] = useState(false);

  // Discussion message
  const [newMessage, setNewMessage] = useState('');
  const [messages, setMessages] = useState<any[]>([]);
  const [isLoadingMessages, setIsLoadingMessages] = useState(false);

  if (!selectedChallenge) return null;

  const loadMessages = async () => {
    setIsLoadingMessages(true);
    try {
      const res = await api.fetchMessages('challenge', selectedChallenge.id);
      if (res.messages) setMessages(res.messages);
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoadingMessages(false);
    }
  };

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMessage.trim()) return;

    try {
      const res = await api.sendMessage({
        channelType: 'challenge',
        targetEntityId: selectedChallenge.id,
        content: newMessage.trim(),
      });
      if (res.success && res.message) {
        setMessages((prev) => [...prev, res.message]);
        setNewMessage('');
        showToast('Comment posted to challenge thread');
      }
    } catch (err) {
      showToast('Failed to post message');
    }
  };

  const handleValidation = async (decision: 'approve' | 'reject' | 'needs_info' | 'assigned') => {
    setIsValidating(true);
    try {
      const res = await api.validateChallenge(selectedChallenge.id, {
        decision,
        notes: validationNotes,
        overrideDomain: overrideDomain || undefined,
        overridePriority: overridePriority || undefined,
        assignedUniversityId: assignedUniversityId || undefined,
      });

      if (res.success && res.challenge) {
        setSelectedChallenge(res.challenge);
        showToast(`Challenge successfully ${decision === 'approve' ? 'validated' : decision}`);
        await refreshAllData();
      }
    } catch (err) {
      showToast('Validation operation failed');
    } finally {
      setIsValidating(false);
    }
  };

  const handleCreateProjectClick = () => {
    setActiveEntityForModal(selectedChallenge);
    setIsTeamBuilderModalOpen(true);
  };

  const isGov = currentUser?.role === 'Government Department' || currentUser?.role === 'Platform Administrator';
  const isUni = currentUser?.role === 'University Admin' || currentUser?.role === 'Faculty Mentor';

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/75 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-xl shadow-2xl border border-slate-200 w-full max-w-4xl max-h-[90vh] flex flex-col overflow-hidden animate-in fade-in zoom-in-95">
        {/* Modal Header */}
        <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between flex-shrink-0">
          <div className="flex items-center gap-3">
            <span className="text-xs font-mono font-bold bg-emerald-800 text-emerald-200 px-2 py-0.5 rounded border border-emerald-600">
              {selectedChallenge.id}
            </span>
            <div>
              <h3 className="text-base font-bold text-white line-clamp-1">
                {selectedChallenge.title}
              </h3>
              <p className="text-xs text-slate-400">
                {selectedChallenge.location.district} District • {selectedChallenge.domain} • Submitted by {selectedChallenge.submittedByName}
              </p>
            </div>
          </div>
          <button
            onClick={() => setSelectedChallenge(null)}
            className="p-1 rounded-md text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab switcher */}
        <div className="bg-slate-100 border-b border-slate-200 px-6 py-2 flex items-center justify-between flex-shrink-0">
          <div className="flex items-center space-x-2">
            {[
              { id: 'dossier', label: 'Problem Dossier' },
              { id: 'ai', label: 'AI Intelligence & Matches' },
              { id: 'discussions', label: 'Discussion Channel' },
            ].map((t) => (
              <button
                key={t.id}
                onClick={() => {
                  setActiveTab(t.id as any);
                  if (t.id === 'discussions') loadMessages();
                }}
                className={`px-3 py-1.5 rounded-md text-xs font-bold transition-colors ${
                  activeTab === t.id
                    ? 'bg-white text-emerald-900 shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {t.label}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-2">
            <span
              className={`px-2.5 py-1 rounded text-xs font-bold ${
                selectedChallenge.status === 'Completed'
                  ? 'bg-emerald-100 text-emerald-800'
                  : selectedChallenge.status === 'Project Started'
                  ? 'bg-blue-100 text-blue-800'
                  : selectedChallenge.status === 'Assigned'
                  ? 'bg-purple-100 text-purple-800'
                  : selectedChallenge.status === 'Validated'
                  ? 'bg-teal-100 text-teal-800'
                  : 'bg-amber-100 text-amber-800'
              }`}
            >
              Status: {selectedChallenge.status}
            </span>
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto flex-1 space-y-6">
          {/* TAB 1: Dossier */}
          {activeTab === 'dossier' && (
            <div className="space-y-5 animate-in fade-in">
              {/* Ground details */}
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
                <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">
                  Ground Reality & Problem Statement
                </h4>
                <p className="text-sm text-slate-800 leading-relaxed">
                  {selectedChallenge.detailedDescription}
                </p>
              </div>

              {/* Geographic & Demographics Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="p-3 bg-white rounded-lg border border-slate-200">
                  <span className="text-[10px] font-semibold text-slate-400 uppercase block">Location</span>
                  <span className="text-xs font-bold text-slate-900 mt-0.5 block truncate">
                    {selectedChallenge.location.block}, {selectedChallenge.location.district}
                  </span>
                  <span className="text-[10px] text-slate-500">{selectedChallenge.location.villageOrCity}</span>
                </div>

                <div className="p-3 bg-white rounded-lg border border-slate-200">
                  <span className="text-[10px] font-semibold text-slate-400 uppercase block">Affected Population</span>
                  <span className="text-sm font-black text-slate-900 mt-0.5 block font-mono">
                    {selectedChallenge.affectedPopulation.toLocaleString()}
                  </span>
                  <span className="text-[10px] text-slate-500">Direct citizens impacted</span>
                </div>

                <div className="p-3 bg-white rounded-lg border border-slate-200">
                  <span className="text-[10px] font-semibold text-slate-400 uppercase block">Urgency</span>
                  <span className="text-xs font-bold text-red-600 mt-0.5 block">
                    {selectedChallenge.urgency}
                  </span>
                  <span className="text-[10px] text-slate-500">Citizen reported level</span>
                </div>

                <div className="p-3 bg-white rounded-lg border border-slate-200">
                  <span className="text-[10px] font-semibold text-slate-400 uppercase block">GPS Pin</span>
                  <span className="text-xs font-mono font-bold text-emerald-800 mt-0.5 block">
                    {selectedChallenge.location.gpsCoordinates?.latitude}° N
                  </span>
                  <span className="text-[10px] text-slate-500 font-mono">
                    {selectedChallenge.location.gpsCoordinates?.longitude}° E
                  </span>
                </div>
              </div>

              {/* Expected outcome & resources */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-3.5 bg-slate-50 rounded-lg border border-slate-200 text-xs">
                  <span className="font-bold text-slate-800 block mb-1">Expected Solution Outcome:</span>
                  <p className="text-slate-600 leading-relaxed">{selectedChallenge.expectedOutcome}</p>
                </div>
                <div className="p-3.5 bg-slate-50 rounded-lg border border-slate-200 text-xs">
                  <span className="font-bold text-slate-800 block mb-1">Local Community Resources:</span>
                  <p className="text-slate-600 leading-relaxed">{selectedChallenge.availableResources}</p>
                </div>
              </div>

              {/* Evidence attachments */}
              {selectedChallenge.media && selectedChallenge.media.length > 0 && (
                <div>
                  <h5 className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                    Evidence & Field Photographs ({selectedChallenge.media.length})
                  </h5>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                    {selectedChallenge.media.map((m) => (
                      <div
                        key={m.id}
                        className="group relative rounded-lg border border-slate-200 overflow-hidden bg-slate-100"
                      >
                        <img
                          src={m.url}
                          alt={m.name}
                          className="w-full h-28 object-cover group-hover:scale-105 transition-transform"
                        />
                        <div className="p-2 bg-white text-[10px]">
                          <p className="font-semibold text-slate-800 truncate">{m.name}</p>
                          <span className="text-slate-400">{(m.sizeBytes / 1024).toFixed(1)} KB</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Assigned University Banner */}
              {selectedChallenge.assignedUniversityName && (
                <div className="p-4 bg-emerald-50 rounded-xl border border-emerald-200 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-lg bg-emerald-700 text-white flex items-center justify-center font-bold">
                      <GraduationCap className="w-5 h-5" />
                    </div>
                    <div>
                      <span className="text-[10px] font-bold uppercase text-emerald-800 tracking-wider">
                        Assigned Solution Institution
                      </span>
                      <h5 className="text-sm font-bold text-slate-900">
                        {selectedChallenge.assignedUniversityName}
                      </h5>
                    </div>
                  </div>

                  {selectedChallenge.status === 'Assigned' && isUni && (
                    <button
                      onClick={handleCreateProjectClick}
                      className="px-3 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-md text-xs font-bold flex items-center gap-1.5 transition-colors shadow-sm"
                    >
                      <Users className="w-3.5 h-3.5" />
                      <span>Form Multidisciplinary Team</span>
                    </button>
                  )}
                </div>
              )}

              {/* Government Review Panel (If Government or Admin) */}
              {isGov && selectedChallenge.status !== 'Completed' && (
                <div className="p-4 bg-slate-900 text-white rounded-xl border border-slate-800 space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <ShieldCheck className="w-4 h-4 text-emerald-400" />
                      <span className="text-xs font-bold">Government Department Validation & Routing Desk</span>
                    </div>
                    <span className="text-[10px] text-slate-400">Department of Higher & Technical Education, GoJ</span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                    <div>
                      <label className="block text-[10px] text-slate-400 uppercase font-semibold mb-1">
                        Override Domain (Optional)
                      </label>
                      <input
                        type="text"
                        placeholder="Leave blank to accept AI domain"
                        value={overrideDomain}
                        onChange={(e) => setOverrideDomain(e.target.value)}
                        className="w-full px-2.5 py-1.5 bg-slate-800 border border-slate-700 rounded text-xs text-white focus:outline-none focus:ring-1 focus:ring-emerald-400"
                      />
                    </div>

                    <div>
                      <label className="block text-[10px] text-slate-400 uppercase font-semibold mb-1">
                        Assign to University Directly
                      </label>
                      <select
                        value={assignedUniversityId}
                        onChange={(e) => setAssignedUniversityId(e.target.value)}
                        className="w-full px-2.5 py-1.5 bg-slate-800 border border-slate-700 rounded text-xs text-white focus:outline-none focus:ring-1 focus:ring-emerald-400"
                      >
                        <option value="">Select University...</option>
                        {universities.map((u) => (
                          <option key={u.id} value={u.id}>
                            {u.name} ({u.district})
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-[10px] text-slate-400 uppercase font-semibold mb-1">
                      Validation Notes / Field Directives
                    </label>
                    <textarea
                      rows={2}
                      value={validationNotes}
                      onChange={(e) => setValidationNotes(e.target.value)}
                      placeholder="Add administrative notes, instructions for university team, or reason for status update..."
                      className="w-full px-2.5 py-1.5 bg-slate-800 border border-slate-700 rounded text-xs text-white focus:outline-none focus:ring-1 focus:ring-emerald-400"
                    />
                  </div>

                  <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-slate-800">
                    <button
                      onClick={() => handleValidation('approve')}
                      disabled={isValidating}
                      className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded text-xs font-bold transition-colors"
                    >
                      ✓ Approve & Validate
                    </button>
                    <button
                      onClick={() => handleValidation('assigned')}
                      disabled={isValidating || !assignedUniversityId}
                      className="px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded text-xs font-bold transition-colors disabled:opacity-40"
                    >
                      Assign to Selected University
                    </button>
                    <button
                      onClick={() => handleValidation('needs_info')}
                      disabled={isValidating}
                      className="px-3 py-1.5 bg-amber-600 hover:bg-amber-500 text-white rounded text-xs font-bold transition-colors"
                    >
                      Request Clarification
                    </button>
                    <button
                      onClick={() => handleValidation('reject')}
                      disabled={isValidating}
                      className="px-3 py-1.5 bg-rose-700 hover:bg-rose-600 text-white rounded text-xs font-bold transition-colors ml-auto"
                    >
                      Reject Submission
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 2: AI Intelligence */}
          {activeTab === 'ai' && (
            <div className="animate-in fade-in">
              <AIIntelligencePanel
                challenge={selectedChallenge}
                onAssignUniversity={async (uniId) => {
                  await handleValidation('assigned');
                  setAssignedUniversityId(uniId);
                }}
              />
            </div>
          )}

          {/* TAB 3: Discussions */}
          {activeTab === 'discussions' && (
            <div className="space-y-4 animate-in fade-in">
              <div className="bg-slate-50 p-3 rounded-lg border border-slate-200 text-xs text-slate-600">
                Stakeholder collaboration channel for Citizens, Government, Faculty, and Industry Mentors.
              </div>

              {/* Message List */}
              <div className="space-y-2 max-h-64 overflow-y-auto pr-1">
                {messages.length === 0 ? (
                  <div className="p-6 text-center text-xs text-slate-400">
                    No messages posted yet. Start the conversation below.
                  </div>
                ) : (
                  messages.map((m) => (
                    <div key={m.id} className="p-3 bg-white rounded-lg border border-slate-200 text-xs shadow-xs">
                      <div className="flex items-center justify-between mb-1">
                        <div className="flex items-center gap-1.5">
                          <span className="font-bold text-slate-900">{m.senderName}</span>
                          <span className="text-[10px] bg-emerald-100 text-emerald-800 font-semibold px-1.5 py-0.2 rounded">
                            {m.senderRole}
                          </span>
                        </div>
                        <span className="text-[10px] text-slate-400">
                          {new Date(m.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>
                      <p className="text-slate-700 leading-relaxed">{m.content}</p>
                    </div>
                  ))
                )}
              </div>

              {/* Compose message */}
              <form onSubmit={handleSendMessage} className="flex gap-2">
                <input
                  type="text"
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  placeholder={`Post update as ${currentUser?.name} (${currentUser?.role})...`}
                  className="flex-1 px-3 py-2 border border-slate-300 rounded-md text-xs focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                />
                <button
                  type="submit"
                  className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-md text-xs font-bold flex items-center gap-1.5 transition-colors"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Send</span>
                </button>
              </form>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
