/**
 * University Solution Proposal Modal
 * Authoring & Government Appraisal Workflow
 */

import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  X,
  FileText,
  CheckCircle2,
  AlertCircle,
  Sparkles,
  Send,
  ShieldCheck,
} from 'lucide-react';
import * as api from '../api';

export const ProposalModal: React.FC = () => {
  const {
    isProposalModalOpen,
    setIsProposalModalOpen,
    activeEntityForModal,
    currentUser,
    refreshAllData,
    showToast,
  } = useApp();

  const project = activeEntityForModal;

  const [problemUnderstanding, setProblemUnderstanding] = useState(
    project?.proposal?.problemUnderstanding ||
      'Comprehensive ground investigation of groundwater chemistry and seasonal hydro-dynamics.'
  );
  const [proposedSolution, setProposedSolution] = useState(
    project?.proposal?.proposedSolution ||
      'Deployment of gravity-assisted solar electro-coagulation filtration modules with IoT telemetry.'
  );
  const [innovationHighlights, setInnovationHighlights] = useState(
    project?.proposal?.innovationHighlights?.join(', ') ||
      'Zero consumables operational model, Biochar secondary filter, Real-time cellular telemetry'
  );
  const [technologyStack, setTechnologyStack] = useState(
    project?.proposal?.technologyStack?.join(', ') ||
      'ESP32 Microcontroller, Arsenic Spectrometry Sensor, Solar MPPT Inverter, Cloud Dashboard'
  );
  const [implementationPlan, setImplementationPlan] = useState(
    project?.proposal?.implementationPlan ||
      'Phase 1: Lab prototype (Month 1). Phase 2: Gram Panchayat pilot unit (Month 2). Phase 3: Community training & handover (Month 3-4).'
  );
  const [budget, setBudget] = useState(project?.budgetInRupees || 750000);
  const [timelineMonths, setTimelineMonths] = useState(project?.proposal?.timelineMonths || 4);
  const [expectedSocialImpact, setExpectedSocialImpact] = useState(
    project?.proposal?.expectedSocialImpact ||
      '1,200 households provided safe drinking water meeting BIS 10500 standards.'
  );
  const [scalabilityPlan, setScalabilityPlan] = useState(
    project?.proposal?.scalabilityPlan ||
      'Design schematics released under open hardware license for replication across 500+ fluoride-affected habitations.'
  );
  const [risksAndMitigation, setRisksAndMitigation] = useState(
    project?.proposal?.risksAndMitigation ||
      'Monsoon flood risk mitigated by elevated RCC plinth mounting structure.'
  );
  const [sustainabilityStrategy, setSustainabilityStrategy] = useState(
    project?.proposal?.sustainabilityStrategy ||
      'Village Jal Sahiya committee collects ₹20/month household maintenance fund with SHG operations.'
  );

  const [reviewRemarks, setReviewRemarks] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!isProposalModalOpen || !project) return null;

  const isGov = currentUser?.role === 'Government Department' || currentUser?.role === 'Platform Administrator';
  const hasExistingProposal = Boolean(project.proposal);

  const handleSubmitProposal = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      const res = await api.submitProposal(project.id, {
        problemUnderstanding,
        proposedSolution,
        innovationHighlights: innovationHighlights.split(',').map((s: string) => s.trim()),
        technologyStack: technologyStack.split(',').map((s: string) => s.trim()),
        implementationPlan,
        estimatedBudgetInRupees: budget,
        timelineMonths,
        expectedSocialImpact,
        scalabilityPlan,
        risksAndMitigation,
        sustainabilityStrategy,
      });

      if (res.success) {
        showToast('Solution Proposal submitted to Government for review!');
        setIsProposalModalOpen(false);
        await refreshAllData();
      }
    } catch (err) {
      showToast('Failed to submit proposal');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleReviewProposal = async (decision: 'approve' | 'revise') => {
    setIsSubmitting(true);
    try {
      const res = await api.reviewProposal(project.id, {
        decision,
        remarks: reviewRemarks || (decision === 'approve' ? 'Approved by Technical Appraisal Committee' : 'Revision needed'),
      });
      if (res.success) {
        showToast(`Proposal ${decision === 'approve' ? 'Approved' : 'Revision Requested'}`);
        setIsProposalModalOpen(false);
        await refreshAllData();
      }
    } catch (err) {
      showToast('Review operation failed');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/75 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-xl shadow-2xl border border-slate-200 w-full max-w-3xl overflow-hidden animate-in fade-in zoom-in-95">
        {/* Header */}
        <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-600 flex items-center justify-center font-bold">
              <FileText className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-bold">Technical Solution Proposal</h3>
              <p className="text-xs text-slate-300">
                {project.universityName} • {project.title}
              </p>
            </div>
          </div>
          <button
            onClick={() => setIsProposalModalOpen(false)}
            className="p-1 rounded-md text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <form onSubmit={handleSubmitProposal} className="p-6 space-y-4 max-h-[75vh] overflow-y-auto text-xs">
          {project.proposal?.status && (
            <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-lg flex items-center justify-between">
              <div>
                <span className="font-bold text-emerald-900 block">Proposal Status: {project.proposal.status}</span>
                {project.proposal.reviewRemarks && (
                  <p className="text-slate-600 mt-0.5">Remarks: {project.proposal.reviewRemarks}</p>
                )}
              </div>
              <span className="text-[10px] text-slate-400">
                Submitted {new Date(project.proposal.submittedAt).toLocaleDateString()}
              </span>
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">
                Problem Understanding & Root Cause *
              </label>
              <textarea
                rows={3}
                required
                value={problemUnderstanding}
                onChange={(e) => setProblemUnderstanding(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">
                Proposed Technological Solution *
              </label>
              <textarea
                rows={3}
                required
                value={proposedSolution}
                onChange={(e) => setProposedSolution(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">
                Innovation Highlights (comma separated)
              </label>
              <input
                type="text"
                value={innovationHighlights}
                onChange={(e) => setInnovationHighlights(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">
                Technology Stack / Components (comma separated)
              </label>
              <input
                type="text"
                value={technologyStack}
                onChange={(e) => setTechnologyStack(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              />
            </div>
          </div>

          <div>
            <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">
              Phased Implementation Plan *
            </label>
            <textarea
              rows={2}
              required
              value={implementationPlan}
              onChange={(e) => setImplementationPlan(e.target.value)}
              className="w-full px-3 py-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-emerald-500 focus:outline-none"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">
                Estimated Budget (₹) *
              </label>
              <input
                type="number"
                value={budget}
                onChange={(e) => setBudget(Number(e.target.value))}
                className="w-full px-3 py-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-emerald-500 focus:outline-none font-mono"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">
                Duration (Months) *
              </label>
              <input
                type="number"
                value={timelineMonths}
                onChange={(e) => setTimelineMonths(Number(e.target.value))}
                className="w-full px-3 py-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-emerald-500 focus:outline-none font-mono"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">
                Expected Social Impact Metric *
              </label>
              <textarea
                rows={2}
                value={expectedSocialImpact}
                onChange={(e) => setExpectedSocialImpact(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">
                Scalability & Replication Strategy
              </label>
              <textarea
                rows={2}
                value={scalabilityPlan}
                onChange={(e) => setScalabilityPlan(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">
                Risks & Mitigation Plan
              </label>
              <input
                type="text"
                value={risksAndMitigation}
                onChange={(e) => setRisksAndMitigation(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">
                Long-Term Sustainability & Handover
              </label>
              <input
                type="text"
                value={sustainabilityStrategy}
                onChange={(e) => setSustainabilityStrategy(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              />
            </div>
          </div>

          {/* Government Appraisal Section */}
          {isGov && (
            <div className="p-4 bg-slate-900 text-white rounded-xl space-y-3">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span className="font-bold">Government Department Evaluation & Clearance</span>
              </div>
              <input
                type="text"
                value={reviewRemarks}
                onChange={(e) => setReviewRemarks(e.target.value)}
                placeholder="Enter evaluation remarks or clearance conditions..."
                className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded text-white focus:outline-none focus:ring-1 focus:ring-emerald-400"
              />
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => handleReviewProposal('approve')}
                  disabled={isSubmitting}
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded"
                >
                  ✓ Approve Solution Proposal
                </button>
                <button
                  type="button"
                  onClick={() => handleReviewProposal('revise')}
                  disabled={isSubmitting}
                  className="px-4 py-2 bg-amber-600 hover:bg-amber-500 text-slate-950 font-bold rounded"
                >
                  Request Revisions
                </button>
              </div>
            </div>
          )}

          {/* Footer Controls */}
          <div className="pt-4 border-t border-slate-200 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={() => setIsProposalModalOpen(false)}
              className="px-4 py-2 border border-slate-300 rounded-md font-semibold text-slate-700 hover:bg-slate-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-md font-bold transition-all shadow-md flex items-center gap-1.5"
            >
              <Send className="w-3.5 h-3.5" />
              <span>{isSubmitting ? 'Submitting...' : 'Save & Submit Proposal'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
