/**
 * University Multidisciplinary Team Builder Modal
 * Assembles faculty mentor, cross-department students, and budget parameters.
 */

import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import {
  X,
  Users,
  GraduationCap,
  Sparkles,
  Calendar,
  CheckCircle2,
  Briefcase,
  Layers,
} from 'lucide-react';
import * as api from '../api';
import { FacultyMentor, StudentMember } from '../types';

export const TeamBuilderModal: React.FC = () => {
  const {
    isTeamBuilderModalOpen,
    setIsTeamBuilderModalOpen,
    activeEntityForModal,
    universities,
    refreshAllData,
    showToast,
    setSelectedProject,
    setActiveTab,
  } = useApp();

  const challenge = activeEntityForModal;

  const [availableFaculty, setAvailableFaculty] = useState<FacultyMentor[]>([]);
  const [availableStudents, setAvailableStudents] = useState<StudentMember[]>([]);

  const [selectedUniId, setSelectedUniId] = useState(
    challenge?.assignedUniversityId || universities[0]?.id || ''
  );
  const [projectTitle, setProjectTitle] = useState(
    challenge ? `Multidisciplinary Innovation: ${challenge.title}` : ''
  );
  const [selectedFacultyId, setSelectedFacultyId] = useState('');
  const [selectedStudentIds, setSelectedStudentIds] = useState<string[]>([]);
  const [budget, setBudget] = useState(650000);
  const [targetDate, setTargetDate] = useState('2026-06-30');
  const [isCreating, setIsCreating] = useState(false);

  useEffect(() => {
    async function loadMembers() {
      try {
        const [fRes, sRes] = await Promise.all([api.fetchFaculty(), api.fetchStudents()]);
        if (fRes.faculty) {
          setAvailableFaculty(fRes.faculty);
          if (fRes.faculty.length > 0) setSelectedFacultyId(fRes.faculty[0].id);
        }
        if (sRes.students) {
          setAvailableStudents(sRes.students);
          // Pick first two by default
          setSelectedStudentIds([sRes.students[0]?.id, sRes.students[1]?.id].filter(Boolean));
        }
      } catch (err) {
        console.error(err);
      }
    }
    if (isTeamBuilderModalOpen) {
      loadMembers();
    }
  }, [isTeamBuilderModalOpen]);

  if (!isTeamBuilderModalOpen || !challenge) return null;

  const toggleStudent = (sId: string) => {
    setSelectedStudentIds((prev) =>
      prev.includes(sId) ? prev.filter((id) => id !== sId) : [...prev, sId]
    );
  };

  const handleCreateProject = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedFacultyId || selectedStudentIds.length === 0) {
      showToast('Please select a faculty mentor and at least one student team member');
      return;
    }

    setIsCreating(true);
    try {
      const res = await api.createProject({
        challengeId: challenge.id,
        title: projectTitle || `Innovation: ${challenge.title}`,
        universityId: selectedUniId,
        leadFacultyId: selectedFacultyId,
        studentIds: selectedStudentIds,
        budgetInRupees: budget,
        targetCompletionDate: targetDate,
      });

      if (res.success && res.project) {
        showToast(`Multidisciplinary Project ${res.project.id} launched!`);
        setIsTeamBuilderModalOpen(false);
        setSelectedProject(res.project);
        setActiveTab('projects');
        await refreshAllData();
      }
    } catch (err) {
      showToast('Failed to create project');
    } finally {
      setIsCreating(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/75 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-xl shadow-2xl border border-slate-200 w-full max-w-3xl overflow-hidden animate-in fade-in zoom-in-95">
        {/* Header */}
        <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-600 flex items-center justify-center font-bold">
              <Users className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-bold">Multidisciplinary Team Builder</h3>
              <p className="text-xs text-slate-300">
                Form university research & engineering team for challenge {challenge.id}
              </p>
            </div>
          </div>
          <button
            onClick={() => setIsTeamBuilderModalOpen(false)}
            className="p-1 rounded-md text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleCreateProject} className="p-6 space-y-4 max-h-[75vh] overflow-y-auto">
          {/* Target Challenge Info */}
          <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-lg text-xs">
            <span className="font-bold text-emerald-900 block">Civic Problem: {challenge.title}</span>
            <p className="text-slate-600 mt-0.5">
              {challenge.location.district} District • {challenge.domain} • Urgency: {challenge.urgency}
            </p>
          </div>

          {/* Project Title */}
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
              Project / Solution Title *
            </label>
            <input
              type="text"
              required
              value={projectTitle}
              onChange={(e) => setProjectTitle(e.target.value)}
              className="w-full px-3 py-2 border border-slate-300 rounded-md text-sm focus:ring-2 focus:ring-emerald-500 focus:outline-none"
            />
          </div>

          {/* University selector */}
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
              Executing University Institution *
            </label>
            <select
              value={selectedUniId}
              onChange={(e) => setSelectedUniId(e.target.value)}
              className="w-full px-3 py-2 border border-slate-300 rounded-md text-sm focus:ring-2 focus:ring-emerald-500 focus:outline-none"
            >
              {universities.map((u) => (
                <option key={u.id} value={u.id}>
                  {u.name} ({u.district}) - {u.type}
                </option>
              ))}
            </select>
          </div>

          {/* Faculty Mentor Selector */}
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
              Select Lead Faculty Mentor *
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {availableFaculty.map((f) => {
                const isSelected = selectedFacultyId === f.id;
                return (
                  <div
                    key={f.id}
                    onClick={() => setSelectedFacultyId(f.id)}
                    className={`p-3 rounded-lg border text-xs cursor-pointer transition-all ${
                      isSelected
                        ? 'border-emerald-600 bg-emerald-50/70 shadow-xs'
                        : 'border-slate-200 hover:border-slate-300 bg-white'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-slate-900">{f.name}</span>
                      {isSelected && <CheckCircle2 className="w-4 h-4 text-emerald-600" />}
                    </div>
                    <p className="text-[11px] text-emerald-800 font-medium">
                      {f.designation} • {f.department}
                    </p>
                    <p className="text-[10px] text-slate-500 mt-1">
                      Specs: {f.specialization.join(', ')}
                    </p>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Multidisciplinary Student Team Selector */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
                Assemble Multidisciplinary Student Team * ({selectedStudentIds.length} Selected)
              </label>
              <span className="text-[10px] text-slate-400">Select cross-department candidates</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 max-h-48 overflow-y-auto p-1 border border-slate-200 rounded-lg bg-slate-50/50">
              {availableStudents.map((s) => {
                const isSelected = selectedStudentIds.includes(s.id);
                return (
                  <div
                    key={s.id}
                    onClick={() => toggleStudent(s.id)}
                    className={`p-2.5 rounded-lg border text-xs cursor-pointer transition-all ${
                      isSelected
                        ? 'border-emerald-600 bg-white ring-1 ring-emerald-500 shadow-xs'
                        : 'border-slate-200 hover:border-slate-300 bg-white'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-slate-900">{s.name}</span>
                      <span className="text-[10px] font-bold text-emerald-700 bg-emerald-100 px-1.5 py-0.2 rounded">
                        {s.department}
                      </span>
                    </div>
                    <p className="text-[10px] text-slate-500">{s.yearOfStudy}</p>
                    <div className="mt-1 flex flex-wrap gap-1">
                      {s.skills.map((sk, idx) => (
                        <span
                          key={idx}
                          className="bg-slate-100 text-slate-600 text-[9px] px-1 py-0.2 rounded"
                        >
                          {sk}
                        </span>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Budget & Timeline */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                Estimated Project Budget (₹) *
              </label>
              <input
                type="number"
                step="10000"
                min="50000"
                value={budget}
                onChange={(e) => setBudget(Number(e.target.value))}
                className="w-full px-3 py-2 border border-slate-300 rounded-md text-sm focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              />
              <span className="text-[10px] text-slate-400 mt-1 block">
                Eligible for GoJ Innovation Seed Grant & Industry CSR co-funding.
              </span>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                Target Completion Date *
              </label>
              <input
                type="date"
                value={targetDate}
                onChange={(e) => setTargetDate(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-md text-sm focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              />
            </div>
          </div>

          {/* Footer */}
          <div className="pt-4 border-t border-slate-200 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={() => setIsTeamBuilderModalOpen(false)}
              className="px-4 py-2 border border-slate-300 rounded-md text-xs font-semibold text-slate-700 hover:bg-slate-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isCreating}
              className="px-5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-md text-xs font-bold transition-all shadow-md flex items-center gap-1.5"
            >
              <Users className="w-3.5 h-3.5" />
              <span>{isCreating ? 'Creating Project...' : 'Launch Innovation Project'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
