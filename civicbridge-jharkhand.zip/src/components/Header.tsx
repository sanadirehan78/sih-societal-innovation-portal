/**
 * Header Component - Official CivicBridge Jharkhand Portal
 */

import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  Bell,
  ChevronDown,
  Sparkles,
  PlusCircle,
  FileText,
  Building2,
  GraduationCap,
  Briefcase,
  Layers,
  BarChart3,
  MapPin,
  TrendingUp,
  RotateCcw,
  CheckCircle2,
} from 'lucide-react';
import * as api from '../api';

export const Header: React.FC = () => {
  const {
    currentUser,
    allPersonas,
    switchUserPersona,
    activeTab,
    setActiveTab,
    challenges,
    projects,
    universities,
    notifications,
    unreadCount,
    setIsSubmitModalOpen,
    setIsPresentationModalOpen,
    startGuidedDemo,
    guidedDemoActive,
    refreshAllData,
    showToast,
  } = useApp();

  const [isPersonaMenuOpen, setIsPersonaMenuOpen] = useState(false);
  const [isNotifOpen, setIsNotifOpen] = useState(false);
  const [isResetting, setIsResetting] = useState(false);

  const pendingValidationCount = challenges.filter(
    (c) => c.status === 'Submitted' || c.status === 'Under Validation'
  ).length;

  const handleResetData = async () => {
    if (window.confirm('Reset database back to initial seed data with 20+ challenges, universities and projects?')) {
      setIsResetting(true);
      try {
        const res = await api.resetDatabase();
        showToast(res.message || 'Database restored to initial state');
        await refreshAllData();
      } catch (err) {
        showToast('Failed to reset database');
      } finally {
        setIsResetting(false);
      }
    }
  };

  return (
    <header id="app-header" className="sticky top-0 z-40 bg-white border-b border-slate-200 shadow-sm">
      {/* Tricolor accent bar */}
      <div className="h-1.5 w-full flex">
        <div className="w-1/3 bg-[#FF9933]"></div>
        <div className="w-1/3 bg-white border-y border-slate-200"></div>
        <div className="w-1/3 bg-[#138808]"></div>
      </div>

      {/* Top Governmental Bar */}
      <div className="bg-slate-900 text-slate-200 text-xs px-4 py-1.5 flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center space-x-3">
          <span className="inline-flex items-center gap-1.5 font-semibold text-amber-400">
            <span className="h-2 w-2 rounded-full bg-emerald-400 animate-pulse"></span>
            SIH 2026 (Problem Statement ID: SIH26043)
          </span>
          <span className="hidden md:inline text-slate-400">|</span>
          <span className="hidden md:inline text-slate-300">
            Department of Higher & Technical Education, Government of Jharkhand
          </span>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => setIsPresentationModalOpen(true)}
            className="flex items-center gap-1 hover:text-white text-emerald-400 font-medium transition-colors"
            title="View 5-Slide Judge Presentation Deck"
          >
            <FileText className="w-3.5 h-3.5" />
            <span>Judge Deck (5 Slides)</span>
          </button>
          <span className="text-slate-500">|</span>
          <button
            onClick={handleResetData}
            disabled={isResetting}
            className="flex items-center gap-1 hover:text-amber-300 text-slate-300 transition-colors"
            title="Reset database to seed records"
          >
            <RotateCcw className={`w-3 h-3 ${isResetting ? 'animate-spin' : ''}`} />
            <span>Reset Demo DB</span>
          </button>
        </div>
      </div>

      {/* Primary Brand & Navigation Header */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo & Emblem */}
          <div className="flex items-center gap-3 cursor-pointer" onClick={() => setActiveTab('home')}>
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-emerald-700 to-teal-900 flex items-center justify-center text-white font-black shadow-md border border-emerald-600">
              <span className="text-base tracking-wider font-mono">JH</span>
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-black text-slate-900 text-lg tracking-tight">CivicBridge</span>
                <span className="bg-emerald-100 text-emerald-800 text-[11px] font-bold px-1.5 py-0.5 rounded border border-emerald-300">
                  JHARKHAND
                </span>
              </div>
              <p className="text-[11px] text-slate-500 font-medium leading-none">
                Crowdsourced Innovation & University Solution Engine
              </p>
            </div>
          </div>

          {/* Action Tools: Guided Demo, Submit, Persona Switcher */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* 2-Min Guided Demo Button */}
            <button
              onClick={guidedDemoActive ? () => {} : startGuidedDemo}
              className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-md border transition-all ${
                guidedDemoActive
                  ? 'bg-emerald-600 text-white border-emerald-700 shadow-inner ring-2 ring-emerald-400 ring-offset-1'
                  : 'bg-gradient-to-r from-emerald-50 to-teal-50 text-emerald-900 border-emerald-300 hover:border-emerald-500 hover:shadow-sm'
              }`}
            >
              <Sparkles className="w-4 h-4 text-emerald-600" />
              <span className="hidden sm:inline">2-Min Guided Demo</span>
              <span className="sm:hidden">Demo</span>
            </button>

            {/* Submit Challenge CTA */}
            <button
              onClick={() => setIsSubmitModalOpen(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-semibold rounded-md shadow-sm transition-all"
            >
              <PlusCircle className="w-4 h-4" />
              <span>Submit Challenge</span>
            </button>

            {/* Persona Switcher Dropdown */}
            <div className="relative">
              <button
                onClick={() => setIsPersonaMenuOpen(!isPersonaMenuOpen)}
                className="flex items-center gap-2 px-2.5 py-1.5 rounded-md border border-slate-300 hover:border-slate-400 bg-slate-50 hover:bg-slate-100 text-xs font-medium text-slate-700 transition-colors"
                title="Switch active user persona to experience different roles"
              >
                <div className="w-5 h-5 rounded-full bg-slate-800 text-white flex items-center justify-center text-[10px] font-bold">
                  {currentUser?.name?.charAt(0) || 'U'}
                </div>
                <div className="text-left hidden md:block">
                  <div className="font-semibold text-slate-900 leading-tight truncate max-w-[120px]">
                    {currentUser?.name}
                  </div>
                  <div className="text-[10px] text-emerald-700 font-medium leading-tight">
                    {currentUser?.role}
                  </div>
                </div>
                <ChevronDown className="w-3.5 h-3.5 text-slate-500" />
              </button>

              {isPersonaMenuOpen && (
                <div className="absolute right-0 mt-2 w-72 bg-white rounded-lg shadow-xl border border-slate-200 py-2 z-50 animate-in fade-in slide-in-from-top-1">
                  <div className="px-3 py-2 border-b border-slate-100 bg-slate-50">
                    <p className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">
                      Switch Role Persona (Evaluator Mode)
                    </p>
                    <p className="text-[11px] text-slate-600 mt-0.5">
                      Experience CivicBridge from the exact perspective of different stakeholders:
                    </p>
                  </div>
                  <div className="max-h-72 overflow-y-auto divide-y divide-slate-100">
                    {allPersonas.map((p) => {
                      const isSelected = currentUser?.id === p.id;
                      return (
                        <button
                          key={p.id}
                          onClick={() => {
                            switchUserPersona(p.id);
                            setIsPersonaMenuOpen(false);
                          }}
                          className={`w-full text-left px-3 py-2 flex items-start gap-2.5 transition-colors text-xs ${
                            isSelected ? 'bg-emerald-50 text-emerald-950 font-semibold' : 'hover:bg-slate-50 text-slate-700'
                          }`}
                        >
                          <div className={`mt-0.5 w-6 h-6 rounded-full flex items-center justify-center text-[11px] font-bold ${
                            isSelected ? 'bg-emerald-700 text-white' : 'bg-slate-200 text-slate-700'
                          }`}>
                            {p.name.charAt(0)}
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center justify-between">
                              <span className="font-semibold truncate">{p.name}</span>
                              {isSelected && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 flex-shrink-0" />}
                            </div>
                            <div className="text-[11px] text-emerald-700 font-medium">{p.role}</div>
                            <div className="text-[10px] text-slate-400 truncate">{p.organization} ({p.district})</div>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>

            {/* Notifications Bell */}
            <div className="relative">
              <button
                onClick={() => setIsNotifOpen(!isNotifOpen)}
                className="relative p-2 text-slate-600 hover:text-slate-900 rounded-md hover:bg-slate-100 transition-colors"
                title="System Notifications & Alerts"
              >
                <Bell className="w-4 h-4" />
                {unreadCount > 0 && (
                  <span className="absolute top-1 right-1 w-4 h-4 bg-rose-600 text-white rounded-full text-[9px] font-bold flex items-center justify-center ring-2 ring-white animate-pulse">
                    {unreadCount}
                  </span>
                )}
              </button>

              {isNotifOpen && (
                <div className="absolute right-0 mt-2 w-80 bg-white rounded-lg shadow-xl border border-slate-200 py-2 z-50">
                  <div className="px-3 py-2 border-b border-slate-100 flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-800">Stakeholder Notifications</span>
                    <button
                      onClick={async () => {
                        await api.markAllNotificationsRead();
                        refreshAllData();
                      }}
                      className="text-[11px] text-emerald-600 hover:text-emerald-800 font-semibold"
                    >
                      Mark all read
                    </button>
                  </div>
                  <div className="max-h-64 overflow-y-auto divide-y divide-slate-100">
                    {notifications.length === 0 ? (
                      <div className="p-4 text-center text-xs text-slate-400">No recent notifications</div>
                    ) : (
                      notifications.slice(0, 8).map((n) => (
                        <div
                          key={n.id}
                          className={`p-3 text-xs ${n.isRead ? 'bg-white' : 'bg-emerald-50/60 font-medium'}`}
                        >
                          <div className="flex items-center justify-between mb-1">
                            <span className="text-[10px] font-bold uppercase text-emerald-700 tracking-wider">
                              {n.type}
                            </span>
                            <span className="text-[10px] text-slate-400">
                              {new Date(n.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                            </span>
                          </div>
                          <p className="font-semibold text-slate-900">{n.title}</p>
                          <p className="text-[11px] text-slate-600 mt-0.5">{n.message}</p>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Primary Functional Navigation Bar */}
        <nav className="flex items-center space-x-1 sm:space-x-2 overflow-x-auto py-2 border-t border-slate-100 no-scrollbar">
          {[
            { id: 'home', label: 'Home', icon: Layers },
            { id: 'challenges', label: 'Challenges', icon: FileText, count: challenges.length },
            { id: 'government', label: 'Government Desk', icon: Building2, alertCount: pendingValidationCount },
            { id: 'university', label: 'Universities', icon: GraduationCap, count: universities.length },
            { id: 'industry', label: 'Industry & CSR', icon: Briefcase },
            { id: 'projects', label: 'Projects', icon: Layers, count: projects.length },
            { id: 'impact', label: 'Impact Metrics', icon: TrendingUp },
            { id: 'map', label: '24 Districts Map', icon: MapPin },
            { id: 'analytics', label: 'Analytics', icon: BarChart3 },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-semibold whitespace-nowrap transition-all ${
                  isActive
                    ? 'bg-emerald-800 text-white shadow-sm'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-emerald-200' : 'text-slate-400'}`} />
                <span>{tab.label}</span>
                {tab.count !== undefined && (
                  <span
                    className={`ml-1 px-1.5 py-0.2 rounded-full text-[10px] font-bold ${
                      isActive ? 'bg-emerald-950 text-emerald-200' : 'bg-slate-200 text-slate-700'
                    }`}
                  >
                    {tab.count}
                  </span>
                )}
                {tab.alertCount !== undefined && tab.alertCount > 0 && (
                  <span className="ml-1 px-1.5 py-0.2 rounded-full text-[10px] font-bold bg-amber-500 text-slate-950 animate-pulse">
                    {tab.alertCount} new
                  </span>
                )}
              </button>
            );
          })}
        </nav>
      </div>
    </header>
  );
};
