/**
 * Industry & CSR Partner Pledge Modal
 * Pledges funding, equipment, mentorship, and pilot testing access
 */

import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  X,
  Briefcase,
  CheckCircle2,
  DollarSign,
  HeartHandshake,
  Sparkles,
} from 'lucide-react';
import * as api from '../api';

export const IndustryPledgeModal: React.FC = () => {
  const {
    isPledgeModalOpen,
    setIsPledgeModalOpen,
    activeEntityForModal,
    currentUser,
    refreshAllData,
    showToast,
  } = useApp();

  const target = activeEntityForModal; // can be challenge or project

  const [companyName, setCompanyName] = useState(
    currentUser?.organization || 'Tata Steel Innovation Group'
  );
  const [pledgeTypes, setPledgeTypes] = useState<string[]>([
    'Mentorship',
    'Financial Grant',
    'Equipment Access',
  ]);
  const [amount, setAmount] = useState<number>(250000);
  const [equipmentDetails, setEquipmentDetails] = useState(
    'Access to metallurgical analysis spectrometer and rapid CNC machining workshop'
  );
  const [mentorName, setMentorName] = useState(
    currentUser?.name || 'Sanjay Murmu (Lead Principal Metallurgist)'
  );
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!isPledgeModalOpen || !target) return null;

  const togglePledgeType = (type: string) => {
    setPledgeTypes((prev) =>
      prev.includes(type) ? prev.filter((t) => t !== type) : [...prev, type]
    );
  };

  const handlePledgeSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      const res = await api.submitIndustryPledge({
        industryId: currentUser?.id,
        challengeId: target.challengeId || target.id,
        projectId: target.challengeId ? target.id : undefined,
        offeredSupport: pledgeTypes,
        financialPledgeAmountInRupees: amount,
        equipmentDetails,
        mentorNominated: mentorName,
      });

      if (res.success) {
        showToast(`Partnership pledge of ₹${amount.toLocaleString()} registered!`);
        setIsPledgeModalOpen(false);
        await refreshAllData();
      }
    } catch (err) {
      showToast('Failed to submit industry pledge');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/75 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-xl shadow-2xl border border-slate-200 w-full max-w-lg overflow-hidden animate-in fade-in zoom-in-95">
        <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-600 flex items-center justify-center font-bold">
              <HeartHandshake className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-bold">Industry Partnership & CSR Pledge</h3>
              <p className="text-xs text-slate-300">
                Support innovation solving: {target.title || target.challengeTitle}
              </p>
            </div>
          </div>
          <button
            onClick={() => setIsPledgeModalOpen(false)}
            className="p-1 rounded-md text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handlePledgeSubmit} className="p-6 space-y-4 text-xs">
          <div>
            <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">
              Company / Partner Entity *
            </label>
            <input
              type="text"
              required
              value={companyName}
              onChange={(e) => setCompanyName(e.target.value)}
              className="w-full px-3 py-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-emerald-500 focus:outline-none"
            />
          </div>

          <div>
            <label className="block font-bold text-slate-700 uppercase tracking-wider mb-2">
              Select Modes of Support Offered *
            </label>
            <div className="grid grid-cols-2 gap-2">
              {[
                'Financial Grant',
                'Mentorship',
                'Equipment Access',
                'Prototype Testing',
                'Pilot Site Access',
                'Market Linkage',
              ].map((t) => {
                const isChecked = pledgeTypes.includes(t);
                return (
                  <button
                    type="button"
                    key={t}
                    onClick={() => togglePledgeType(t)}
                    className={`p-2.5 rounded-lg border text-left font-medium transition-all ${
                      isChecked
                        ? 'border-emerald-600 bg-emerald-50 text-emerald-950 font-bold'
                        : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    ✓ {t}
                  </button>
                );
              })}
            </div>
          </div>

          <div>
            <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">
              Financial CSR Pledge Amount (₹)
            </label>
            <input
              type="number"
              step="10000"
              value={amount}
              onChange={(e) => setAmount(Number(e.target.value))}
              className="w-full px-3 py-2 border border-slate-300 rounded-md font-mono focus:ring-2 focus:ring-emerald-500 focus:outline-none"
            />
            <span className="text-[10px] text-slate-400 mt-1 block">
              Directly disbursable to university innovation account with GoJ tax exemption receipt.
            </span>
          </div>

          <div>
            <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">
              Nominated Industry Mentor
            </label>
            <input
              type="text"
              value={mentorName}
              onChange={(e) => setMentorName(e.target.value)}
              className="w-full px-3 py-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-emerald-500 focus:outline-none"
            />
          </div>

          <div>
            <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">
              Equipment / Facility Access Details
            </label>
            <textarea
              rows={2}
              value={equipmentDetails}
              onChange={(e) => setEquipmentDetails(e.target.value)}
              placeholder="List specific labs, testing equipment, or site access provided..."
              className="w-full px-3 py-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-emerald-500 focus:outline-none"
            />
          </div>

          <div className="pt-3 border-t border-slate-200 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={() => setIsPledgeModalOpen(false)}
              className="px-4 py-2 border border-slate-300 rounded-md font-semibold text-slate-700 hover:bg-slate-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-md font-bold transition-all shadow-md flex items-center gap-1.5"
            >
              <Briefcase className="w-3.5 h-3.5" />
              <span>{isSubmitting ? 'Confirming...' : 'Register Industry Pledge'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
