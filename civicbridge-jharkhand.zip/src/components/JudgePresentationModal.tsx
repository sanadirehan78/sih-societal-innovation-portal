/**
 * Judge Presentation Modal - SIH 2026 (Problem Statement ID: SIH26043)
 * 5-Slide judge presentation deck explaining the problem, architecture,
 * AI engine, 12-stage lifecycle, and verifiable social impact.
 */

import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  X,
  ChevronLeft,
  ChevronRight,
  Sparkles,
  Layers,
  Brain,
  GraduationCap,
  TrendingUp,
  Building2,
  Users,
  ShieldCheck,
  CheckCircle2,
  ArrowRight,
} from 'lucide-react';

export const JudgePresentationModal: React.FC = () => {
  const { isPresentationModalOpen, setIsPresentationModalOpen } = useApp();
  const [currentSlide, setCurrentSlide] = useState(0);

  if (!isPresentationModalOpen) return null;

  const SLIDES = [
    {
      number: '01',
      tag: 'Problem Statement & Context',
      title: 'SIH26043: The Disconnect Between Grassroots Need & Higher Education',
      subtitle: 'Department of Higher & Technical Education, Government of Jharkhand',
      content: (
        <div className="space-y-4">
          <div className="bg-slate-900 text-slate-100 p-4 rounded-xl border border-slate-800">
            <h4 className="text-emerald-400 font-bold text-sm mb-1">
              Core Challenge Faced by Jharkhand
            </h4>
            <p className="text-xs text-slate-300 leading-relaxed">
              Jharkhand's 24 districts face acute, location-specific grassroots challenges—such as arsenic & fluoride groundwater poisoning, forest-fringe elephant-human conflict, post-harvest lac and mahua spoilage, and tribal health accessibility.
              Simultaneously, Jharkhand's 10+ premier engineering universities (BIT Mesra, IIT ISM Dhanbad, NIT Jamshedpur, Birsa Agricultural University) educate 65,000+ engineers doing academic capstones that rarely solve indigenous community problems.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <div className="p-3 bg-red-50 border border-red-200 rounded-lg text-xs">
              <span className="font-bold text-red-900 block mb-1">Siloed Higher Education</span>
              <p className="text-slate-600">
                Student final-year projects replicate toy web portals rather than addressing rural engineering realities.
              </p>
            </div>
            <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg text-xs">
              <span className="font-bold text-amber-900 block mb-1">Lack of Coordinated Bridge</span>
              <p className="text-slate-600">
                Panchayati Raj and Urban Local Bodies have no structured channel to submit technical bottlenecks to research universities.
              </p>
            </div>
            <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg text-xs">
              <span className="font-bold text-blue-900 block mb-1">Unspent CSR Capital</span>
              <p className="text-slate-600">
                Industrial giants (Tata Steel, Coal India, SAIL) lack structured co-creation pipelines with university labs.
              </p>
            </div>
          </div>

          <div className="p-3 bg-emerald-50 border border-emerald-300 rounded-lg flex items-center justify-between text-xs">
            <span className="font-bold text-emerald-950">
              CivicBridge Jharkhand Solution: The State Innovation Clearinghouse
            </span>
            <span className="text-emerald-700 font-mono font-semibold">SIH 2026 Target</span>
          </div>
        </div>
      ),
    },
    {
      number: '02',
      tag: 'System Architecture',
      title: 'The 5-Stakeholder Collaborative Innovation Engine',
      subtitle: 'Unified Digital Pipeline linking Grassroots to Production',
      content: (
        <div className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-5 gap-2 text-center text-xs">
            <div className="p-3 bg-slate-900 text-white rounded-lg border border-slate-800 flex flex-col items-center justify-between">
              <div className="w-8 h-8 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold mb-2">1</div>
              <h5 className="font-bold text-white text-xs">Citizens & PRIs</h5>
              <p className="text-[10px] text-slate-400 mt-1">Submit geotagged problems, photos, and affected population data.</p>
            </div>
            <div className="p-3 bg-slate-900 text-white rounded-lg border border-slate-800 flex flex-col items-center justify-between">
              <div className="w-8 h-8 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold mb-2">2</div>
              <h5 className="font-bold text-white text-xs">AI Triage Engine</h5>
              <p className="text-[10px] text-slate-400 mt-1">Classifies domain, scores priority, checks duplicate similarity.</p>
            </div>
            <div className="p-3 bg-slate-900 text-white rounded-lg border border-slate-800 flex flex-col items-center justify-between">
              <div className="w-8 h-8 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold mb-2">3</div>
              <h5 className="font-bold text-white text-xs">Government GoJ</h5>
              <p className="text-[10px] text-slate-400 mt-1">Validates problems, audits overrides, and assigns to matching university.</p>
            </div>
            <div className="p-3 bg-slate-900 text-white rounded-lg border border-slate-800 flex flex-col items-center justify-between">
              <div className="w-8 h-8 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold mb-2">4</div>
              <h5 className="font-bold text-white text-xs">Universities</h5>
              <p className="text-[10px] text-slate-400 mt-1">Cross-department faculty mentors & student teams build prototypes.</p>
            </div>
            <div className="p-3 bg-slate-900 text-white rounded-lg border border-slate-800 flex flex-col items-center justify-between">
              <div className="w-8 h-8 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold mb-2">5</div>
              <h5 className="font-bold text-white text-xs">Industry & Impact</h5>
              <p className="text-[10px] text-slate-400 mt-1">Co-funds via CSR, provides equipment, verifies before-after impact.</p>
            </div>
          </div>

          <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 text-xs">
            <h5 className="font-bold text-slate-800 mb-2">Key Architectural Safeguards</h5>
            <div className="grid grid-cols-2 gap-3 text-slate-700">
              <div className="flex items-start gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0" />
                <span><strong>Role-Based Access Control:</strong> 14 distinct stakeholder personas with tailored security perimeters.</span>
              </div>
              <div className="flex items-start gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0" />
                <span><strong>Immutable Audit Log:</strong> Every status transition, administrative override, and fund pledge is logged.</span>
              </div>
              <div className="flex items-start gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0" />
                <span><strong>Full-Stack Security:</strong> Zero browser leakage of secret API keys via Express API proxies.</span>
              </div>
              <div className="flex items-start gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0" />
                <span><strong>District GIS Map:</strong> Real-time density across all 24 Jharkhand districts.</span>
              </div>
            </div>
          </div>
        </div>
      ),
    },
    {
      number: '03',
      tag: 'AI Intelligence Engine',
      title: 'Explainable AI Triage & Precision University Matching',
      subtitle: 'Hybrid Intelligence: Deterministic Taxonomy, Semantic Vectorization & LLM',
      content: (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
            <div className="p-3.5 bg-slate-900 text-white rounded-xl border border-slate-800">
              <h5 className="font-bold text-emerald-400 flex items-center gap-1.5 mb-2">
                <Brain className="w-4 h-4" />
                <span>Multi-Factor Priority Formulation</span>
              </h5>
              <p className="text-slate-300 mb-2">
                Unlike subjective scoring, our engine calculates an explainable 0-100 score:
              </p>
              <div className="font-mono bg-slate-950 p-2 rounded border border-slate-800 text-[11px] text-emerald-300">
                Priority = 0.25(Population) + 0.30(Urgency) + 0.15(Health/Safety) + 0.15(Economic) + 0.15(Seasonal Risk)
              </div>
              <p className="text-[11px] text-slate-400 mt-2">
                Outputs human-readable justifications explaining why points were awarded.
              </p>
            </div>

            <div className="p-3.5 bg-slate-900 text-white rounded-xl border border-slate-800">
              <h5 className="font-bold text-teal-400 flex items-center gap-1.5 mb-2">
                <Sparkles className="w-4 h-4" />
                <span>Semantic Duplicate Detection & Merge</span>
              </h5>
              <p className="text-slate-300 mb-2">
                Prevents fragmentation when multiple villagers report the same broken check-dam or contaminated borewell:
              </p>
              <ul className="space-y-1 text-[11px] text-slate-300">
                <li>• TF-IDF cosine similarity across problem descriptions.</li>
                <li>• District & block geographic clustering.</li>
                <li>• One-click administrative merge into canonical challenge record.</li>
              </ul>
            </div>
          </div>

          <div className="p-3.5 bg-emerald-50 rounded-xl border border-emerald-200 text-xs">
            <h5 className="font-bold text-emerald-950 mb-1">
              Precision University Matching Algorithm (e.g. 94% Match)
            </h5>
            <p className="text-slate-700">
              Matches problems to universities based on specific laboratory infrastructure (e.g., Water Quality & Hydrology Lab at BIT Mesra, Mining Environment Center at IIT ISM Dhanbad), past completed projects in that domain, and geographic proximity to the affected district.
            </p>
          </div>
        </div>
      ),
    },
    {
      number: '04',
      tag: 'Implementation Lifecycle',
      title: '12-Stage Innovation Lifecycle & Multidisciplinary Execution',
      subtitle: 'From Problem Definition to Deployment & Handover',
      content: (
        <div className="space-y-4 text-xs">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {[
              '1. Problem Definition',
              '2. Field Research',
              '3. Solution Proposal',
              '4. Govt Approval',
              '5. Team Assembly',
              '6. Rapid Prototype',
              '7. Laboratory Test',
              '8. Field Pilot',
              '9. Citizen Validation',
              '10. Deployment',
              '11. Impact Audit',
              '12. Community Handover',
            ].map((stage, idx) => (
              <div
                key={idx}
                className="p-2.5 bg-slate-50 border border-slate-200 rounded-lg flex items-center gap-2"
              >
                <span className="w-5 h-5 rounded-full bg-emerald-700 text-white flex items-center justify-center font-bold text-[10px]">
                  {idx + 1}
                </span>
                <span className="font-semibold text-slate-800 text-[11px] truncate">{stage}</span>
              </div>
            ))}
          </div>

          <div className="bg-slate-900 text-white p-4 rounded-xl border border-slate-800">
            <h5 className="font-bold text-amber-400 mb-2">Multidisciplinary Engineering Teams</h5>
            <p className="text-slate-300 leading-relaxed mb-3">
              Real community problems are never single-discipline. Our platform enforces cross-department composition:
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-[11px]">
              <div className="bg-slate-800 p-2 rounded">
                <span className="text-emerald-400 font-bold block">Hardware & Civil</span>
                <span className="text-slate-400">Structural integrity, hydraulics, filtration beds, CAD housings.</span>
              </div>
              <div className="bg-slate-800 p-2 rounded">
                <span className="text-teal-400 font-bold block">IoT & Software</span>
                <span className="text-slate-400">Microcontrollers, GSM telemetry, cloud dashboard, mobile alerts.</span>
              </div>
              <div className="bg-slate-800 p-2 rounded">
                <span className="text-amber-400 font-bold block">Agriculture & Biotech</span>
                <span className="text-slate-400">Microbial culture, soil chemistry, community user adoption.</span>
              </div>
            </div>
          </div>
        </div>
      ),
    },
    {
      number: '05',
      tag: 'Impact & Scaling',
      title: 'Verifiable Impact, Sustainability & State-Wide Rollout',
      subtitle: 'Measuring True Societal Transformation for SIH 2026',
      content: (
        <div className="space-y-4 text-xs">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
            <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-lg">
              <span className="text-2xl font-black text-emerald-800 font-mono">100%</span>
              <span className="block text-[10px] font-bold text-slate-600 uppercase mt-1">
                24 Districts Covered
              </span>
            </div>
            <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
              <span className="text-2xl font-black text-blue-800 font-mono">₹1.8 Cr+</span>
              <span className="block text-[10px] font-bold text-slate-600 uppercase mt-1">
                Annual Community Savings
              </span>
            </div>
            <div className="p-3 bg-purple-50 border border-purple-200 rounded-lg">
              <span className="text-2xl font-black text-purple-800 font-mono">14+</span>
              <span className="block text-[10px] font-bold text-slate-600 uppercase mt-1">
                Patents & Research Papers
              </span>
            </div>
            <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg">
              <span className="text-2xl font-black text-amber-800 font-mono">50,000+</span>
              <span className="block text-[10px] font-bold text-slate-600 uppercase mt-1">
                Citizens Directly Benefited
              </span>
            </div>
          </div>

          <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-2">
            <h5 className="font-bold text-slate-900">Institutional Sustainability Strategy</h5>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-slate-700">
              <div>
                <strong>GoJ Academic Credit Integration:</strong> Mandating B.Tech capstone credits for solving validated CivicBridge state problems.
              </div>
              <div>
                <strong>Self-Sustaining User Fees:</strong> Community SHGs manage decentralized kiosks with minor maintenance fees for long-term viability.
              </div>
              <div>
                <strong>State CSR Clearinghouse:</strong> Tax-exempt statutory CSR matching funds channeled directly to accredited university projects.
              </div>
              <div>
                <strong>National Replication:</strong> Modular microservice architecture ready for rollout to other Indian states under AICTE & MoE.
              </div>
            </div>
          </div>
        </div>
      ),
    },
  ];

  const current = SLIDES[currentSlide];

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/85 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-4xl overflow-hidden flex flex-col max-h-[92vh] animate-in fade-in zoom-in-95">
        {/* Header */}
        <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-3">
            <span className="w-8 h-8 rounded-lg bg-emerald-600 flex items-center justify-center font-bold text-sm">
              SIH
            </span>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-white">Judge Presentation Deck</span>
                <span className="text-[10px] bg-emerald-950 text-emerald-300 px-2 py-0.5 rounded font-mono border border-emerald-800">
                  Slide {currentSlide + 1} of {SLIDES.length}
                </span>
              </div>
              <p className="text-[11px] text-slate-400">
                CivicBridge Jharkhand (Problem Statement ID: SIH26043)
              </p>
            </div>
          </div>

          <button
            onClick={() => setIsPresentationModalOpen(false)}
            className="p-1 rounded-md text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Slide Canvas */}
        <div className="p-6 md:p-8 flex-1 overflow-y-auto bg-white">
          <div className="mb-4">
            <span className="text-[11px] font-bold uppercase tracking-widest text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded border border-emerald-200">
              Slide {current.number} • {current.tag}
            </span>
            <h3 className="text-xl md:text-2xl font-black text-slate-900 mt-2">
              {current.title}
            </h3>
            <p className="text-xs text-slate-500 mt-1">{current.subtitle}</p>
          </div>

          <div className="mt-4">{current.content}</div>
        </div>

        {/* Footer Navigation */}
        <div className="px-6 py-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
          <div className="flex items-center space-x-1.5">
            {SLIDES.map((_, idx) => (
              <button
                key={idx}
                onClick={() => setCurrentSlide(idx)}
                className={`w-7 h-2 rounded-full transition-all ${
                  currentSlide === idx ? 'bg-emerald-700 w-9' : 'bg-slate-300 hover:bg-slate-400'
                }`}
                title={`Go to slide ${idx + 1}`}
              />
            ))}
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setCurrentSlide(Math.max(0, currentSlide - 1))}
              disabled={currentSlide === 0}
              className="px-3 py-1.5 border border-slate-300 rounded-md text-xs font-semibold text-slate-700 hover:bg-slate-100 disabled:opacity-30 disabled:cursor-not-allowed flex items-center gap-1"
            >
              <ChevronLeft className="w-4 h-4" />
              <span>Previous</span>
            </button>

            <button
              onClick={() => setCurrentSlide(Math.min(SLIDES.length - 1, currentSlide + 1))}
              disabled={currentSlide === SLIDES.length - 1}
              className="px-4 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-md text-xs font-bold disabled:opacity-30 disabled:cursor-not-allowed flex items-center gap-1 shadow-sm"
            >
              <span>Next Slide</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
