/**
 * Client Type Definitions for CivicBridge Jharkhand
 * Mirrors and extends server types for the React frontend
 */

export type UserRole =
  | 'Citizen'
  | 'Community Organization'
  | 'Panchayati Raj Institution'
  | 'Urban Local Body'
  | 'Government Department'
  | 'University Admin'
  | 'Faculty Mentor'
  | 'Student'
  | 'Industry Partner'
  | 'Startup/MSME'
  | 'CSR Organization'
  | 'Research Laboratory'
  | 'Innovation Hub'
  | 'Platform Administrator';

export type ChallengeDomain =
  | 'Education'
  | 'Agriculture'
  | 'Healthcare'
  | 'Water Resources'
  | 'Environment'
  | 'Energy'
  | 'Urban Development'
  | 'Accessibility'
  | 'Public Administration'
  | 'Rural Livelihoods'
  | 'Sanitation'
  | 'Infrastructure';

export type PriorityLevel = 'Critical' | 'High' | 'Medium' | 'Low';

export type ChallengeStatus =
  | 'Submitted'
  | 'Under AI Analysis'
  | 'Under Validation'
  | 'Validated'
  | 'Assigned'
  | 'Proposal Under Review'
  | 'Project Started'
  | 'Pilot Active'
  | 'Completed'
  | 'Rejected'
  | 'Needs Clarification';

export type ProjectStage =
  | 'Problem Definition'
  | 'Research'
  | 'Proposal'
  | 'Approval'
  | 'Team Formation'
  | 'Prototype'
  | 'Testing'
  | 'Pilot'
  | 'Validation'
  | 'Deployment'
  | 'Impact Measurement'
  | 'Completed';

export type MilestoneStatus =
  | 'Not Started'
  | 'In Progress'
  | 'Under Review'
  | 'Blocked'
  | 'Completed';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  avatarUrl?: string;
  organization?: string;
  district?: string;
  phone?: string;
  bio?: string;
  createdAt: string;
}

export interface ChallengeMedia {
  id: string;
  name: string;
  type: 'image' | 'video' | 'pdf' | 'document';
  url: string;
  sizeBytes: number;
  uploadedAt: string;
}

export interface ChallengeLocation {
  state: string;
  district: string;
  block: string;
  villageOrCity: string;
  pincode?: string;
  gpsCoordinates?: {
    latitude: number;
    longitude: number;
  };
}

export interface RecommendedUniversity {
  universityId: string;
  universityName: string;
  district: string;
  matchScore: number;
  matchReasons: string[];
  keyDepartments: string[];
  relevantFacilities: string[];
}

export interface ChallengeAIAnalysis {
  domain: ChallengeDomain;
  subDomain: string;
  priorityScore: number;
  priorityLevel: PriorityLevel;
  urgency: 'Immediate' | 'Short-Term' | 'Medium-Term' | 'Long-Term';
  priorityReasoning: string[];
  duplicateProbability: number;
  possibleDuplicateId?: string;
  duplicateTitle?: string;
  recommendedUniversities: RecommendedUniversity[];
  requiredSkills: string[];
  suggestedSDG: string;
  suggestedProjectType: 'IoT & Automation' | 'Civil Engineering' | 'Biotechnology' | 'Mobile & Web Application' | 'Field Hardware' | 'Process Reform';
  confidenceScore: number;
  analyzedAt: string;
  modelEngine: string;
}

export interface DuplicateCandidate {
  existingChallengeId: string;
  existingTitle: string;
  similarityScore: number;
  domain: ChallengeDomain;
  district: string;
  status: ChallengeStatus;
}

export interface Challenge {
  id: string;
  title: string;
  detailedDescription: string;
  domain: ChallengeDomain;
  location: ChallengeLocation;
  affectedPopulation: number;
  urgency: 'Low' | 'Medium' | 'High' | 'Emergency';
  expectedOutcome: string;
  availableResources: string;
  contactName: string;
  contactPhone: string;
  contactEmail: string;
  media: ChallengeMedia[];
  status: ChallengeStatus;
  submittedByUserId: string;
  submittedByName: string;
  submittedAt: string;
  aiAnalysis?: ChallengeAIAnalysis;
  duplicateCandidates: DuplicateCandidate[];
  isMerged?: boolean;
  mergedIntoId?: string;
  validatedBy?: string;
  validatedAt?: string;
  validationNotes?: string;
  assignedUniversityId?: string;
  assignedUniversityName?: string;
  assignedAt?: string;
  activeProjectId?: string;
  humanOverrides?: {
    originalDomain?: ChallengeDomain;
    originalPriority?: PriorityLevel;
    overrideReason: string;
    overriddenBy: string;
    overriddenAt: string;
  };
}

export interface University {
  id: string;
  name: string;
  shortName: string;
  district: string;
  address: string;
  type: 'Central University' | 'State University' | 'NIT/IIT' | 'Private/Deemed' | 'Polytechnic';
  departments: string[];
  facultyExpertise: string[];
  researchAreas: string[];
  innovationCenters: string[];
  incubationFacilities: string[];
  laboratories: string[];
  availableEquipment: string[];
  studentCount: number;
  facultyCount: number;
  activeProjectsCount: number;
  pastCompletedProjects: number;
  contactEmail: string;
  contactPhone: string;
  website: string;
}

export interface FacultyMentor {
  id: string;
  universityId: string;
  universityName: string;
  name: string;
  department: string;
  designation: string;
  specialization: string[];
  projectsMentored: number;
  email: string;
}

export interface StudentMember {
  id: string;
  name: string;
  universityId: string;
  universityName: string;
  department: string;
  yearOfStudy: string;
  skills: string[];
  roleInProject: string;
}

export interface IndustryPartner {
  id: string;
  companyName: string;
  industrySector: string;
  partnerType: 'Corporate/Industry' | 'Startup' | 'MSME' | 'CSR Foundation' | 'Research Lab' | 'Innovation Hub';
  district: string;
  expertise: string[];
  technologies: string[];
  csrFocusAreas: string[];
  fundingCapacity: string;
  mentorshipCapability: string[];
  labFacilities: string[];
  deploymentCapabilities: string[];
  contactPerson: string;
  email: string;
  phone: string;
  activePledgesCount: number;
}

export interface IndustryInterest {
  id: string;
  industryId: string;
  companyName: string;
  challengeId: string;
  projectId?: string;
  offeredSupport: string[];
  financialPledgeAmountInRupees?: number;
  equipmentDetails?: string;
  mentorNominated?: string;
  status: 'Expressed' | 'Approved' | 'Active' | 'Delivered';
  createdAt: string;
}

export interface ProjectMilestone {
  id: string;
  title: string;
  description: string;
  owner: string;
  startDate: string;
  dueDate: string;
  status: MilestoneStatus;
  progressPercent: number;
  evidenceNotes?: string;
  deliverables?: string[];
  completedAt?: string;
}

export type Milestone = ProjectMilestone;

export interface SolutionProposal {
  id: string;
  projectId: string;
  submittedByUniversityId: string;
  problemUnderstanding: string;
  proposedSolution: string;
  innovationHighlights: string[];
  technologyStack: string[];
  implementationPlan: string;
  estimatedBudgetInRupees: number;
  timelineMonths: number;
  expectedSocialImpact: string;
  scalabilityPlan: string;
  risksAndMitigation: string;
  sustainabilityStrategy: string;
  status: 'Draft' | 'Submitted' | 'Government Approved' | 'Revision Requested';
  submittedAt: string;
  reviewedAt?: string;
  reviewRemarks?: string;
}

export interface ProjectImpact {
  id: string;
  projectId: string;
  challengeId: string;
  householdsAffectedBefore: number;
  householdsBenefitedAfter: number;
  percentageImprovement: number;
  villagesCovered: number;
  costSavedPerAnnumInRupees: number;
  timeSavedMetric: string;
  environmentalImpact: string;
  educationOrHealthImprovement: string;
  livelihoodOrIncomeGenerated: string;
  technologyDeployedSummary: string;
  patentsFiledCount: number;
  researchPapersCount: number;
  startupsCreatedCount: number;
  recordedAt: string;
  verifiedByGovernmentDepartment: string;
}

export interface Project {
  id: string;
  challengeId: string;
  challengeTitle: string;
  title: string;
  domain: ChallengeDomain;
  district: string;
  stage: ProjectStage;
  currentMilestoneIndex: number;
  overallProgress: number;
  universityId: string;
  universityName: string;
  leadFaculty: FacultyMentor;
  studentTeam: StudentMember[];
  industryPartners: IndustryInterest[];
  governmentDepartment: string;
  budgetInRupees: number;
  timelineStartDate: string;
  targetCompletionDate: string;
  proposal?: SolutionProposal;
  milestones: ProjectMilestone[];
  impactRecord?: ProjectImpact;
  createdAt: string;
  updatedAt: string;
}

export interface DiscussionMessage {
  id: string;
  channelType: 'challenge' | 'project' | 'industry' | 'government';
  targetEntityId: string;
  senderId: string;
  senderName: string;
  senderRole: UserRole;
  content: string;
  attachments?: { name: string; url: string }[];
  timestamp: string;
}

export interface AppNotification {
  id: string;
  userId?: string;
  targetRole?: UserRole;
  title: string;
  message: string;
  type: 'challenge' | 'validation' | 'university' | 'proposal' | 'industry' | 'milestone' | 'impact' | 'system';
  relatedEntityId?: string;
  isRead: boolean;
  createdAt: string;
}

export interface AuditLog {
  id: string;
  userId: string;
  userName: string;
  userRole: UserRole;
  action: string;
  entityType: string;
  entityId: string;
  previousState?: string;
  newState: string;
  reason?: string;
  timestamp: string;
}

export interface OverviewStats {
  totalChallenges: number;
  validated: number;
  inProgress: number;
  completed: number;
  underReview: number;
  totalAffectedPopulation: number;
  totalPledgedInRupees: number;
  activeProjectsCount: number;
  participatingUniversitiesCount: number;
  participatingIndustryCount: number;
}

export interface DistrictStat {
  district: string;
  challengesCount: number;
  highPriorityCount: number;
  activeProjectsCount: number;
  completedCount: number;
  affectedPopulation: number;
}
