/**
 * CivicBridge Jharkhand (SIH 2026 - Problem ID: SIH26043)
 * State Platform for Crowdsourcing Local Challenges & Engaging Higher Education
 */

import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Header } from './components/Header';
import { GuidedDemoBanner } from './components/GuidedDemoBanner';
import { SubmitChallengeModal } from './components/SubmitChallengeModal';
import { ChallengeDetailModal } from './components/ChallengeDetailModal';
import { TeamBuilderModal } from './components/TeamBuilderModal';
import { ProposalModal } from './components/ProposalModal';
import { MilestoneModal } from './components/MilestoneModal';
import { ImpactModal } from './components/ImpactModal';
import { IndustryPledgeModal } from './components/IndustryPledgeModal';
import { JudgePresentationModal } from './components/JudgePresentationModal';

// Views
import { HomeView } from './views/HomeView';
import { ChallengesView } from './views/ChallengesView';
import { GovernmentView } from './views/GovernmentView';
import { UniversityView } from './views/UniversityView';
import { IndustryView } from './views/IndustryView';
import { ProjectsView } from './views/ProjectsView';
import { ImpactView } from './views/ImpactView';
import { AnalyticsView } from './views/AnalyticsView';
import { MapView } from './views/MapView';

import { ShieldCheck, Heart } from 'lucide-react';

const MainContent: React.FC = () => {
  const { activeTab, toastMessage } = useApp();

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col font-sans selection:bg-emerald-100 selection:text-emerald-900">
      {/* Top Navigation & Stakeholder Persona Bar */}
      <Header />

      {/* Guided Walkthrough Banner */}
      <GuidedDemoBanner />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {activeTab === 'home' && <HomeView />}
        {activeTab === 'challenges' && <ChallengesView />}
        {activeTab === 'government' && <GovernmentView />}
        {activeTab === 'universities' && <UniversityView />}
        {activeTab === 'industry' && <IndustryView />}
        {activeTab === 'projects' && <ProjectsView />}
        {activeTab === 'impact' && <ImpactView />}
        {activeTab === 'analytics' && <AnalyticsView />}
        {activeTab === 'map' && <MapView />}
      </main>

      {/* Footer */}
      <footer className="bg-slate-900 text-white border-t border-slate-800 py-8 mt-12 text-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-emerald-700 flex items-center justify-center font-black text-sm">
              JH
            </div>
            <div>
              <span className="font-bold text-white block">CivicBridge Jharkhand</span>
              <span className="text-[11px] text-slate-400">
                Department of Higher & Technical Education • Government of Jharkhand
              </span>
            </div>
          </div>

          <div className="text-center md:text-right text-[11px] text-slate-400 space-y-0.5">
            <p>Smart India Hackathon (SIH 2026) • Problem Statement ID: SIH26043</p>
            <p className="text-slate-500">
              Connecting 24 Districts, 10 Universities, 65,000+ Students & Industry Leaders
            </p>
          </div>
        </div>
      </footer>

      {/* Modals & Portals */}
      <SubmitChallengeModal />
      <ChallengeDetailModal />
      <TeamBuilderModal />
      <ProposalModal />
      <MilestoneModal />
      <ImpactModal />
      <IndustryPledgeModal />
      <JudgePresentationModal />

      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-5 right-5 z-50 bg-slate-900 text-white px-4 py-3 rounded-xl shadow-2xl border border-slate-700 flex items-center gap-2.5 text-xs font-semibold animate-in fade-in slide-in-from-bottom-3">
          <ShieldCheck className="w-4 h-4 text-emerald-400 flex-shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MainContent />
    </AppProvider>
  );
}
